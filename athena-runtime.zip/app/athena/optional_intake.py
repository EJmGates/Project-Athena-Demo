"""Bounded optional-file inspection and accounting; no analytical consumers or second upload store."""
import csv
from datetime import datetime
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
import math
from pathlib import Path
import re
import secrets
import sys
import threading
import time

from athena import dates
from athena import rules
from athena.schema_subset import Validator
from athena.upload_checks import check_file

ROOT = Path(__file__).resolve().parent.parent
REGISTRY = json.loads((ROOT / "config/optional_datasets.json").read_text(encoding="utf-8"))
LIMITS = json.loads((ROOT / "config/optional_intake_limits.json").read_text(encoding="utf-8"))
MODULES = {m["id"]: m for m in REGISTRY["modules"]}
VALIDATOR = Validator(ROOT / "contracts/local/optional")


class IntakeError(ValueError):
    def __init__(self, code, message, status=422):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def schema(module_id):
    if module_id not in MODULES:
        raise IntakeError("OPTIONAL-MODULE", "Choose a supported optional dataset.", 400)
    return VALIDATOR.schema(Path(MODULES[module_id]["schema"]).name)


def guides():
    out = []
    for m in MODULES.values():
        s = schema(m["id"])
        out.append({"id":m["id"],"label":m["label"],"description":m["description"],"template":"/"+m["template"],
                    "needs_one_of":[a["required"] for a in s.get("anyOf",[])],
                    "columns":[{"name":k,"meaning":v.get("description",k.replace("_"," ")),"optional":k not in s["required"],"type":v["type"]} for k,v in s["properties"].items()]})
    return out


def retained_size(value):
    """Cycle-safe retained-object estimate; deliberately not RSS or peak process memory."""
    seen = set()
    def walk(v):
        ident = id(v)
        if ident in seen: return 0
        seen.add(ident)
        size = sys.getsizeof(v)
        if isinstance(v, dict): return size + sum(walk(k)+walk(x) for k,x in v.items())
        if isinstance(v, (tuple,list,set,frozenset)): return size + sum(walk(x) for x in v)
        return size
    return walk(value)


def _typed(raw, spec):
    kind = spec["type"]
    if kind == "string": return raw
    if kind == "integer":
        if not re.fullmatch(r"[+-]?[0-9]+", raw): raise ValueError("Enter a whole number.")
        return int(raw)
    if kind == "number":
        if not re.fullmatch(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?",raw):
            raise ValueError("Enter a decimal or scientific number.")
        try: number = Decimal(raw)
        except InvalidOperation: raise ValueError("Enter a finite number.") from None
        if not number.is_finite(): raise ValueError("Enter a finite number.")
        value = float(number)
        if not math.isfinite(value) or (number != 0 and value == 0):
            raise ValueError("The number is outside the supported numeric range.")
        return value
    raise IntakeError("OPTIONAL-SCHEMA", "This dataset schema uses an unsupported field type.", 500)


def _with_canonical_times(record, s, date_format="mdy", zone=None):
    """Copy of the record with every date-time field read by the one date reader (UTC instant). An unreadable value stays as typed and fails the schema."""
    out = dict(record)
    for field, spec in s["properties"].items():
        if spec.get("format") == "date-time" and isinstance(out.get(field), str):
            reading = dates.read(out[field], date_format, zone)
            if reading.ok and reading.has_time: out[field] = reading.instant_utc
        elif spec.get("format") == "date" and isinstance(out.get(field), str):
            reading = dates.read(out[field], date_format, zone)
            if reading.ok and not reading.has_time: out[field] = reading.business_date
    return out


def inspect(module_id, name, data, limits=None, date_format="mdy", zone=None):
    limits = limits or LIMITS
    s = schema(module_id)
    unsafe = check_file(name, data, limits)
    if unsafe: raise IntakeError(unsafe[0]["reason_code"], unsafe[0]["message"], 413 if unsafe[0]["reason_code"]=="FILE-TOO-LARGE" else 422)
    # Remove physical trailing line separators only, never whitespace/field content.
    text = data.decode("utf-8-sig").rstrip("\r\n")
    reader = csv.reader(io.StringIO(text, newline=""), strict=True)
    try: header = next(reader, None)
    except csv.Error: raise IntakeError("CSV-SYNTAX", "The CSV quoting could not be read.") from None
    if not header or any(not h for h in header) or len(header)!=len(set(header)):
        raise IntakeError("CSV-HEADER", "Use one nonempty unique column name for each template column.")
    if any(k not in header for k in s["required"]):
        raise IntakeError("MISSING-COLUMN", "Required template columns are missing.")
    if s.get("anyOf") and not any(all(c in header for c in a["required"]) for a in s["anyOf"]):
        raise IntakeError("MISSING-COLUMN", "Add at least one of the metric columns in the template.")
    entries, diagnostics = [], []
    source_signatures = {}
    key_fields = s.get("x-identity", [s["required"][0]])
    identity = key_fields[0] if key_fields else None
    diagnostic_total = 0
    counts = {"source":0,"row_valid":0,"invalid":0,"identical_copies":0,"held_conflicts":0,"usable":0}
    rows_by_code, last_row = {}, {}
    def finding(row, field, code, message):
        nonlocal diagnostic_total
        diagnostic_total += 1
        if last_row.get(code) != row:                        # a row counts once per finding type
            last_row[code] = row
            rows_by_code[code] = rows_by_code.get(code, 0) + 1
        if len(diagnostics)<limits["max_examples"]:
            diagnostics.append({"source_row":row,"field":field,"code":code,"message":message})
    try:
        for index, cells in enumerate(reader, 2):
            counts["source"] += 1
            if counts["source"]>limits["max_rows"]:
                raise IntakeError("TOO-MANY-ROWS", "This optional file exceeds the supported record limit.", 413)
            if len(cells)!=len(header) or not cells:
                raise IntakeError("CSV-ROW-WIDTH", "Each CSV record must contain the same number of fields as the header.")
            if any(len(c.encode("utf-8"))>limits["max_cell_bytes"] for c in cells):
                raise IntakeError("CELL-TOO-LONG", "A CSV field is longer than the supported length.")
            record, reasons = {}, []
            for field, raw in zip(header, cells):
                if field not in s["properties"]: continue   # additional columns are loaded with the file, never typed or checked
                if raw=="" or (field in s["required"] and not raw.strip()):
                    if field in s["required"]: reasons.append((field,"MISSING-REQUIRED-VALUE","A required value is missing."))
                    continue
                try: record[field] = _typed(raw, s["properties"][field])
                except (ValueError, OverflowError): reasons.append((field,"VALUE-TYPE","Enter a value in the declared field type and supported numeric range."))
            checked = _with_canonical_times(record, s, date_format, zone)         # the record keeps the source text; validation sees canonical times
            for field, rule in VALIDATOR.errors(checked, Path(MODULES[module_id]["schema"]).name):
                key = field.removeprefix("$.")
                if rule=="anyOf":
                    metric_fields={c for alt in s.get("anyOf",[]) for c in alt["required"]}
                    if not any(reason[0] in metric_fields for reason in reasons):       # a metric value that was present but unreadable is reported on its own
                        reasons.append(("metric values","NO-METRIC-VALUE","This row has no metric value."))
                elif not any(reason[0]==key for reason in reasons):
                    reasons.append((key,"ROW-SCHEMA","A value does not match the dataset template ("+rule+")."))
            if not reasons:
                for start,end,same_ok in (("period_start","period_end",False),("effective_start","effective_end",False),("start_date","end_date",True)):
                    if start in record and end in record:
                        first=datetime.fromisoformat(checked[start])
                        last=datetime.fromisoformat(checked[end])
                        if last<first or (last==first and not same_ok): reasons.append((end,"INTERVAL-ORDER","The end must be after the start." if not same_ok else "The end date cannot be before the start date."))
            status = "invalid" if reasons else "valid"
            counts["invalid" if reasons else "row_valid"] += 1
            entry={"source_row":index,"status":status,"reasons":[{"field":f,"code":c} for f,c,_ in reasons]}
            supplied=dict(zip(header,cells))
            if key_fields and all(isinstance(supplied.get(k),str) and supplied[k].strip() for k in ("account_id",*key_fields)):
                entry["identity_key"]=(supplied["account_id"],*(supplied[k] for k in key_fields))
            if not reasons:
                entry["record"]=record
                if module_id == "D08":
                    flags = {field: value.strip() for field, value in supplied.items() if field not in s["properties"]}
                    entry["calendar_scope"] = {
                        "date": checked["event_date"],
                        "lines_of_business": [field for field, value in flags.items() if value == "1"],
                        "malformed_flags": [field for field, value in flags.items() if value not in ("0", "1")],
                    }
                # Duplicate identity requires exact source-number equality. Float
                # parsing remains the schema-facing representation, never the
                # authority for collapsing two source observations.
                # The whole row decides duplicates: columns outside the template count too (exact source text).
                source_signatures[index]=tuple(
                    (field, Decimal(supplied[field]) if s["properties"][field]["type"]=="number" else value)
                    for field,value in sorted(record.items())
                )+tuple((field,supplied[field]) for field in sorted(supplied) if field not in s["properties"])
            entries.append(entry)
            for field,code,message in reasons: finding(index,field,code,message)
    except csv.Error: raise IntakeError("CSV-SYNTAX", "The CSV quoting could not be read.") from None
    if not entries: raise IntakeError("EMPTY-FILE", "Add at least one data record below the template header.")
    groups = {}
    for entry in entries:
        key = entry.get("identity_key")
        if module_id == "D08" and entry["status"] == "valid" and not entry["record"].get("event_details", "").strip():
            # Without a title, only an exact source copy establishes identity.
            key = (source_signatures[entry["source_row"]],)
        if key is not None:
            groups.setdefault(key, []).append(entry)
    for group in groups.values():
        valid=[e for e in group if e["status"]=="valid"]
        signatures={source_signatures[e["source_row"]] for e in valid}
        if len(signatures)>1 or (valid and len(valid)!=len(group)):
            for entry in valid:
                entry["status"]="held"
                counts["held_conflicts"]+=1
                finding(entry["source_row"],identity,"CONFLICTING-ID","Conflicting records share an identity; each is held.")
        else:
            for entry in valid[1:]:
                entry["status"]="collapsed"
                entry["copy_of"]=valid[0]["source_row"]
                counts["identical_copies"]+=1
                finding(entry["source_row"],identity,"IDENTICAL-COPY","This identical typed record is counted once.")
    counts["usable"]=sum(e["status"]=="valid" for e in entries)
    accounts=sorted({e["record"]["account_id"] for e in entries if "record" in e})
    return {"role":"optional","module_id":module_id,"schema_id":s["$id"],"schema_sha256":MODULES[module_id]["schema_sha256"],"file_sha256":hashlib.sha256(data).hexdigest(),"raw":data,"records":entries,"ok":counts["usable"]>0,
            "summary":{"file":name,"rows":counts["source"],"columns":len(header),"accounts":accounts},"source_columns":header,"counts":counts,
            "findings":rules.findings(rows_by_code),"diagnostics":diagnostics,"diagnostic_count":diagnostic_total,"remaining_examples":max(0,diagnostic_total-len(diagnostics)),"issues":[] if counts["usable"] else [{"code":"NO-USABLE-ROWS","message":"No usable records remain. Review the file details and replace this file."}]}


def public_view(record):
    keys=("role","module_id","schema_id","schema_sha256","file_sha256","ok","upload_id","restore_token","summary","source_columns","counts","findings","date_settings","diagnostics","diagnostic_count","remaining_examples","issues")
    return {k:record[k] for k in keys if k in record}


class Resources:
    """Owner/reservation metadata around the server's existing UPLOADS dictionary."""
    def __init__(self, uploads, limits=None, clock=None):
        self.uploads=uploads
        self.limits=dict(limits or LIMITS)
        self.clock=clock or time.monotonic
        self.lock=threading.RLock()
        self.buckets={}
        self.reservations={}

    def _handles(self, owner=None):
        return [r for r in list(self.uploads.values()) if r.get("role")=="optional" and (owner is None or r["owner_id"]==owner)]

    def _cancel_owner(self, owner):
        for reservation in self.reservations.values():
            if reservation["owner"]==owner:
                reservation.update(cancelled=True,raw=0,rows=0)

    def _prune(self):
        now=self.clock()
        for owner,b in list(self.buckets.items()):
            if now-b["touched"]>=self.limits["idle_seconds"]:
                for key,r in list(self.uploads.items()):
                    if r.get("role")=="optional" and r["owner_id"]==owner: self.uploads.pop(key,None)
                self._cancel_owner(owner)
                self.buckets.pop(owner,None)

    def _owner(self, owner, token):
        self._prune()
        b=self.buckets.get(owner) if isinstance(owner,str) else None
        if not b or not isinstance(token,str) or not token.isascii() or not secrets.compare_digest(token,b["token"]):
            raise IntakeError("OPTIONAL-SESSION", "This optional-file session is no longer available. Upload the file again.",404)
        return b

    def create_owner(self):
        with self.lock:
            self._prune()
            if len(self.buckets)>=self.limits["max_buckets"]: raise IntakeError("OPTIONAL-CAPACITY","Optional-file capacity is busy. End an unused session or try again.",429)
            owner,token=secrets.token_hex(8),secrets.token_urlsafe(24)
            self.buckets[owner]={"token":token,"touched":self.clock()}
            return {"owner_id":owner,"owner_token":token}

    def _totals(self, owner=None, pending=True):
        handles=self._handles(owner)
        result={"raw":sum(len(r["raw"]) for r in handles),"rows":sum(r["counts"]["source"] for r in handles),"objects":sum(r["retained_object_bytes"] for r in handles),"handles":len(handles)}
        if pending:
            reservations=[r for r in self.reservations.values() if not r.get("cancelled") and (owner is None or r["owner"]==owner)]
            result["raw"]+=sum(r["raw"] for r in reservations)
            result["rows"]+=sum(r["rows"] for r in reservations)
            result["handles"]+=len(reservations)
        return result

    def reserve(self, owner, token, module_id, size):
        schema(module_id)
        with self.lock:
            self._owner(owner,token)
            if not isinstance(size,int) or size<0 or size>self.limits["max_upload_bytes"]:
                raise IntakeError("FILE-TOO-LARGE",f"This optional file exceeds the supported {self.limits['max_upload_bytes']//1048576} MiB size.",413)
            if len(self.reservations)>=self.limits["max_parses"]:
                raise IntakeError("OPTIONAL-BUSY","Optional files are being checked. Try again shortly.",429)
            if any(r["module_id"]==module_id for r in self._handles(owner)) or any(r["owner"]==owner and r["module"]==module_id for r in self.reservations.values()):
                raise IntakeError("OPTIONAL-SLOT","Replace or remove the current file in this dataset slot first.",409)
            tab,process=self._totals(owner),self._totals()
            if tab["handles"]>=self.limits["max_handles"] or tab["raw"]+size>self.limits["tab_raw_bytes"] or tab["rows"]+self.limits["max_rows"]>self.limits["tab_rows"] or process["raw"]+size>self.limits["process_raw_bytes"] or process["rows"]+self.limits["max_rows"]>self.limits["process_rows"]:
                raise IntakeError("OPTIONAL-CAPACITY","The optional files have reached this session's supported size or record capacity.",429)
            ticket=secrets.token_hex(16)
            self.reservations[ticket]={"owner":owner,"module":module_id,"raw":size,"rows":self.limits["max_rows"],"cancelled":False}
            return ticket

    def cancel(self, ticket):
        with self.lock: self.reservations.pop(ticket,None)

    def check_active(self, ticket):
        with self.lock:
            self._prune()
            r=self.reservations.get(ticket)
            if not r or r.get("cancelled"):
                raise IntakeError("OPTIONAL-SESSION","This optional-file session ended before checking finished.",404)

    def commit(self, ticket, candidate):
        with self.lock:
            self._prune()
            reservation=self.reservations.get(ticket)
            if not reservation or reservation.get("cancelled") or reservation["owner"] not in self.buckets:
                raise IntakeError("OPTIONAL-SESSION","This optional-file session ended before checking finished.",404)
            if candidate["module_id"]!=reservation["module"] or len(candidate["raw"])!=reservation["raw"] or candidate["counts"]["source"]>reservation["rows"]:
                raise IntakeError("OPTIONAL-RESERVATION","The file does not match its reserved capacity.",409)
            owner=reservation["owner"]
            candidate.update(owner_id=owner,upload_id=secrets.token_hex(8),restore_token=secrets.token_urlsafe(24))
            candidate["retained_object_bytes"]=0
            size=retained_size(candidate)
            candidate["retained_object_bytes"]=size
            size=retained_size(candidate)
            tab,process=self._totals(owner),self._totals()
            if size>self.limits["file_object_bytes"] or tab["objects"]+size>self.limits["tab_object_bytes"] or process["objects"]+size>self.limits["process_object_bytes"]:
                raise IntakeError("OPTIONAL-OBJECT-CAPACITY","This optional file exceeds the supported retained-file capacity. Use a smaller file.",413)
            candidate["retained_object_bytes"]=size
            self.uploads[candidate["upload_id"]]=candidate
            self.reservations.pop(ticket,None)
            self.buckets[owner]["touched"]=self.clock()
            return public_view(candidate)

    def restore(self, uid, token, owner, owner_token):
        with self.lock:
            b=self._owner(owner,owner_token)
            r=self.uploads.get(uid) if isinstance(uid,str) else None
            if not r or r.get("role")!="optional" or r["owner_id"]!=owner or not isinstance(token,str) or not token.isascii() or not secrets.compare_digest(token,r["restore_token"]):
                raise IntakeError("NOT-FOUND","That optional file is no longer available. Upload it again.",404)
            b["touched"]=self.clock()
            return public_view(r)

    def release(self, uid, token, owner, owner_token):
        with self.lock:
            self._owner(owner,owner_token)
            r=self.uploads.get(uid) if isinstance(uid,str) else None
            if not r: return
            if r.get("role")!="optional" or r["owner_id"]!=owner or not isinstance(token,str) or not token.isascii() or not secrets.compare_digest(token,r["restore_token"]):
                raise IntakeError("OPTIONAL-OWNER","That optional file belongs to a different session.",403)
            self.uploads.pop(uid,None)

    def close(self, owner, token):
        with self.lock:
            self._owner(owner,token)
            for uid,r in list(self.uploads.items()):
                if r.get("role")=="optional" and r["owner_id"]==owner: self.uploads.pop(uid,None)
            self._cancel_owner(owner)
            self.buckets.pop(owner,None)

    def accounting(self):
        with self.lock:
            self._prune()
            return {"retained":self._totals(pending=False),"admitted":self._totals(),"reservations":sum(not r.get("cancelled") for r in self.reservations.values()),"inflight":len(self.reservations),"buckets":len(self.buckets)}
