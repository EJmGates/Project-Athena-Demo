"""Turns the aggregate rows of a main file into the rows one metric is analysed on.

Every row keeps its group keys (Line of Business, contact type, date, agent). `count` is what the metric is divided by and `total` is
what is added up, so the existing weighted engines, target checks, cohorts and forecast work on any metric: AHT is handling seconds over
contacts. CSAT and QA use weighted score points for Scale scoring. Percent scoring reports either a weighted supplied fractional score
or pooled pass outcomes on a 0–100 scale.
Columns come from the registry (`columns`) and the scoring the Cockpit captured (docs/63). Nothing is guessed: a missing column or
unusable scoring is reported, not replaced.
"""
from athena import metrics as M

UNITS = {"aht": "seconds", ("csat", "scale"): "points", ("csat", "percent"): "percent", ("qa_score", "scale"): "points", ("qa_score", "percent"): "percent"}


def engine_unit(metric_id, scoring):
    """The unit the engine works in for this metric and scoring: seconds, points on the scale, or percent."""
    return UNITS["aht"] if metric_id == "aht" else UNITS.get((metric_id, (scoring or {}).get("scoring_type")))


def _columns(metric_id, grain):
    return (M.get(metric_id) or {}).get("columns", {}).get(grain, {})


def _measure_rows(aggregates, column, factor=1):
    out = []
    for row in aggregates:
        measure = row.get("measures", {}).get(column)
        if not measure:
            continue
        base = {k: v for k, v in row.items() if k not in ("count", "total", "measures", "invalid_pass_columns")}
        out.append({**base, "count": measure["weight"], "total": measure["weighted_sum"] * factor})
    return out


def score_rows(aggregates, metric_id, grain):
    """Weighted source points for callers that explicitly compare raw scores."""
    return _measure_rows(aggregates, _columns(metric_id, grain).get("score"))


def primary_peers(aggregates, metric_id, grain, formats):
    """Eligible primary-file peer scores in their supplied units."""
    for peer, label in (("aht", "Average handle time"), ("csat", "Supplied CSAT score"), ("qa_score", "Supplied QA score")):
        if peer == metric_id:
            continue
        rows = [row for row in (aggregates if peer == "aht" else score_rows(aggregates, peer, grain)) if row["count"] > 0]
        if rows:
            unit = "seconds" if peer == "aht" else "fraction" if formats.get(peer) == "fraction" else "points"
            yield {"id": peer, "label": label, "unit": unit}, rows


def rows(aggregates, metric_id, scoring, grain, *, score_format=None):
    """Returns (rows, problem). problem is None or a code: SCORING-INCOMPLETE or COLUMN-MISSING."""
    if metric_id == "aht":
        return aggregates, None
    cols = _columns(metric_id, grain)
    if not cols or M.check_scoring(scoring):
        return None, "SCORING-INCOMPLETE"
    percent = scoring["scoring_type"] == "percent"
    if score_format == "fraction":
        if not percent:
            return None, "SCORING-INCOMPATIBLE"
        out = [row for row in _measure_rows(aggregates, cols["score"], 100) if row["count"]]
    elif percent:
        column = cols.get("pass_flag" if grain == "contact" else "pass_rate_pct")
        if any(column in row.get("invalid_pass_columns", ()) for row in aggregates):
            return None, "INVALID-PASS-OUTCOME"
        out = [row for row in _measure_rows(aggregates, column, 100 if grain == "contact" else 1) if row["count"]]
    else:
        out = score_rows(aggregates, metric_id, grain)
    if not out and (percent or aggregates):
        return None, "COLUMN-MISSING"
    return out, None


def cutoff_share(aggregates, metric_id, scoring, grain, *, score_format=None):
    """Scale pass rate from score counts for contact data or binary scores.
    Other agent-day scores use the file's supplied pass rate and cutoff."""
    cols = _columns(metric_id, grain)
    if not cols or (scoring or {}).get("scoring_type") != "scale" or M.check_scoring(scoring):
        return None
    passes = scored = 0.0
    use_cutoff = grain == "contact" or score_format == "binary"
    for r in aggregates:
        if use_cutoff:
            m = (r.get("measures") or {}).get(cols["score"])
            if not m:
                continue
            if "levels" not in m:
                return None
            scored += m["weight"]; passes += sum(w for v, w in m["levels"].items() if v >= scoring["cutoff"])
        else:
            m = (r.get("measures") or {}).get(cols.get("pass_rate_pct") or "")
            if not m:
                continue
            scored += m["weight"]; passes += m["weighted_sum"] / 100.0
    return {"share": passes / scored, "scored": scored, "cutoff": scoring["cutoff"], "basis": "chosen_cutoff" if use_cutoff else "file_cutoff"} if scored else None
