"""Findings for the Insights report from the eligible aggregate rows (docs/59, EJ 6 Nov 2026).

First slice: average handle time (M025) by Line of Business and contact type, agent cohorts, change in mix between the two
halves of the analysis period, and the playbook cards the supported findings earn. Pure Python, nothing here admits a method,
chooses a statistical test for the user, or changes any official figure. Every rule below is deterministic and is reported with
its numbers so a reader can see why a finding was or was not supported.

Rows are the aggregate rows the intake produces: {"line_of_business_id", "contact_type", "date", "agent_id" or None, "count", "total"}.
Adjusted group gaps are descriptive. The calculation includes eligible rows without an agent ID.
"""
from bisect import bisect_right
from datetime import date, timedelta
from fractions import Fraction
from itertools import combinations
from urllib.parse import quote

from athena import cohorts as C
from athena import constraints as CO
from athena import decomposition as D
from athena import forecast as FC
from athena import playbook as P
from athena.pareto import within_priority_cutoff

MIN_CONTACTS = 30           # a group, and an agent in a cohort, needs at least this many contacts (EJ, 6 Nov 2026)
MIN_AGENTS = 5              # minimum agent coverage shown in group comparison checks
MATERIALITY = 0.05          # the standardised gap must be at least 5% of the overall figure
DEFAULT_GLIDEPATH_WEEKS = 8
DIMENSIONS = {"line_of_business": "line_of_business_id", "contact_type": "contact_type", "tenure_group": "tenure_group", "training_wave": "training_wave",
              "team_lead": "team_lead", "manager": "manager_name", "cell": "cell"}
OTHER = {"line_of_business": "contact_type", "contact_type": "line_of_business", "tenure_group": "cell", "training_wave": "cell", "team_lead": "cell", "manager": "cell"}
WORK_DIMENSIONS = ("line_of_business", "contact_type")
PEOPLE_DIMENSIONS = ("tenure_group", "training_wave", "team_lead", "manager")
TENURE_BLOCKS = ((30, "Under 30 days"), (61, "30 to 60 days"), (91, "61 to 90 days"), (121, "91 to 120 days"), (181, "121 to 180 days"), (361, "181 to 360 days"))
ASSUMPTIONS = {"min_contacts": MIN_CONTACTS, "min_agents": MIN_AGENTS, "materiality": MATERIALITY}
ADJUSTED_GAP_WITHHELD = "Confirmation requires a qualified test of the adjusted gap."


def tenure_group(days):
    """Tenure block at the day of the work (docs/57): under 30, 30-60, 61-90, 91-120, 121-180, 181-360, 361 and more days."""
    if days is None or days < 0:
        return None
    for limit, name in TENURE_BLOCKS:
        if days < limit:
            return name
    return "361 days or more"


def roster_lookup(records, fmt="mdy", account=None):
    """agent_id -> {hire date, training wave, manager, team lead} from the roster upload's valid records (dates read in the file's format)."""
    from athena import dates
    out = {}
    for rec in records:
        if rec.get("status") != "valid":
            continue
        r = rec["record"]
        if account is not None and r.get("account_id") != account:
            continue
        hire = dates.read(r.get("hire_date"), fmt)
        out[r["agent_id"]] = {"hire": hire.business_date if hire.ok else None, "training_wave": r.get("training_wave"),
                              "manager_name": r.get("manager_name"), "team_lead": r.get("team_lead")}
    return out


def enrich(rows, roster):
    """Rows with the agent's tenure group on the day of the work, training wave, manager and team lead, and the work cell.
    Also returns how well the roster covers the agents and contacts in the data (EJ: disclose the match, periods matter, not 100%)."""
    import datetime as dt
    out, agents, matched_agents, contacts, matched_contacts = [], set(), set(), 0, 0
    for r in rows:
        x = dict(r); x["cell"] = (r["line_of_business_id"], r["contact_type"])
        a = r.get("agent_id")
        if a:
            agents.add(a); contacts += r["count"]
            info = roster.get(a) if roster else None
            if info:
                matched_agents.add(a); matched_contacts += r["count"]
                days = (dt.date.fromisoformat(r["date"]) - dt.date.fromisoformat(info["hire"])).days if info["hire"] else None
                x["tenure_group"] = tenure_group(days); x["training_wave"] = info["training_wave"]; x["manager_name"] = info["manager_name"]; x["team_lead"] = info["team_lead"]
        out.append(x)
    match = {"agents_in_data": len(agents), "agents_in_roster": len(matched_agents), "contacts_with_agent": contacts, "contacts_matched": matched_contacts}
    return out, match


def _sum(rows):
    c = sum(r["count"] for r in rows); t = sum(r["total"] for r in rows)
    return c, t, (t / c if c else None)


def _by(rows, field):
    out = {}
    for r in rows: out.setdefault(r.get(field), []).append(r)
    return out


def _agent_values(rows):
    """AHT per agent over these rows, for agents with at least one contact."""
    per = {}
    for r in rows:
        if r.get("agent_id"):
            c, t = per.get(r["agent_id"], (0, 0)); per[r["agent_id"]] = (c + r["count"], t + r["total"])
    return {a: t / c for a, (c, t) in per.items() if c}


def _standardised(group_rows, rest_rows, other_field):
    """Gap between a group and the rest with the mix of the other dimension held constant.

    Weight both sides to the rest's mix across shared cells. Return the difference
    and the share of each side's observations in those cells."""
    g, r = _by(group_rows, other_field), _by(rest_rows, other_field)
    common = [k for k in g if k in r and _sum(g[k])[0] and _sum(r[k])[0]]
    total_g = _sum(group_rows)[0]
    held = sum(_sum(g[k])[0] for k in common) / total_g if total_g else 0.0
    weights = {k: _sum(r[k])[0] for k in common}
    w = sum(weights.values())
    if not common or not w:
        return None, held, 0.0
    std_g = sum(weights[k] * _sum(g[k])[2] for k in common) / w
    std_r = sum(weights[k] * _sum(r[k])[2] for k in common) / w
    return std_g - std_r, held, w / _sum(rest_rows)[0]


def _chk(name, outcome, detail):
    """One check a group went through: outcome is pass, fail or not run; detail says in plain words what was found."""
    return {"check": name, "outcome": outcome, "detail": detail}


def pairwise_gaps(rows, dimension):
    """Observed ratios for named pairs, with pooled mix weights on mutually observed cells."""
    field, other = DIMENSIONS[dimension], DIMENSIONS[OTHER[dimension]]
    groups = _by((row for row in rows if row.get(field) is not None), field)
    totals = {key: _sum(members) for key, members in groups.items()}
    eligible = sorted((key for key, (count, _, _) in totals.items() if count >= MIN_CONTACTS),
                      key=lambda key: (-totals[key][0], key))
    shown = sorted(eligible[:10])
    cells = {key: {name: _sum(members) for name, members in _by(groups[key], other).items() if name is not None}
             for key in shown}
    pairs = []
    for first, second in combinations(shown, 2):
        a, b = cells[first], cells[second]
        shared = sorted(name for name in a.keys() & b.keys() if a[name][0] and b[name][0])
        a_count, _, a_value = totals[first]
        b_count, _, b_value = totals[second]
        matched_a = sum(a[name][0] for name in shared)
        matched_b = sum(b[name][0] for name in shared)
        mix_gap = None
        if matched_a * 10 >= a_count * 9 and matched_b * 10 >= b_count * 9:
            mix_gap = sum((a[name][0] + b[name][0]) * (a[name][2] - b[name][2]) for name in shared) / (matched_a + matched_b)
        pairs.append({"first": first, "second": second, "observed_gap": a_value - b_value,
                      "mix_gap": mix_gap, "counts": [a_count, b_count], "shared_counts": [matched_a, matched_b]})
    return {"pairs": pairs, "groups": len(groups), "shown_groups": len(shown)}


def segment_gaps(rows, dim, direction="lower_is_better"):
    """Every group of one dimension compared with the rest. direction: lower_is_better (handle time) or higher_is_better."""
    field, other_field = DIMENSIONS[dim], DIMENSIONS[OTHER[dim]]
    c_all, t_all, overall = _sum(rows)
    out = []
    for key, grp in sorted(((k, g) for k, g in _by([r for r in rows if r.get(field) is not None], field).items()), key=lambda kv: str(kv[0])):
        rest = [r for r in rows if r.get(field) != key]
        c, t, aht = _sum(grp)
        item = {"dimension": dim, "key": key, "contacts": c, "value": aht, "gap": None, "held_constant_share": None,
                "rest_held_constant_share": None, "agents": None, "agents_rest": None,
                "supported": False, "adverse": False, "reason": None, "checks": []}
        ck = item["checks"]
        later = lambda *names: ck.extend(_chk(n, "not run", "An earlier check was not met.") for n in names)
        if c < MIN_CONTACTS or not rest:
            item["reason"] = "Too few contacts (%d; at least %d needed)." % (c, MIN_CONTACTS) if c < MIN_CONTACTS else "No other group to compare with."
            ck.append(_chk("Enough contacts", "fail", item["reason"])); later("Mix held constant", "Enough agents", "Gap large enough", "Adjusted-gap confirmation")
            out.append(item); continue
        ck.append(_chk("Enough contacts", "pass", "%d contacts; at least %d needed." % (c, MIN_CONTACTS)))
        gap, held, rest_held = _standardised(grp, rest, other_field)
        item["held_constant_share"] = held
        item["rest_held_constant_share"] = rest_held
        if gap is None:
            item["reason"] = "No overlap with the rest to hold the mix constant."
            ck.append(_chk("Mix held constant", "fail", item["reason"])); later("Enough agents", "Gap large enough", "Adjusted-gap confirmation")
            out.append(item); continue
        ck.append(_chk("Mix held constant", "pass" if held >= 0.9 else "fail", "%.0f%% of the group's contacts share a mix with the rest; at least 90%% needed to call it held." % (held * 100)))
        item["gap"] = gap
        item["adverse"] = gap > 0 if direction == "lower_is_better" else gap < 0
        a, b = list(_agent_values(grp).values()), list(_agent_values(rest).values())
        item["agents"], item["agents_rest"] = len(a), len(b)
        if len(a) < MIN_AGENTS or len(b) < MIN_AGENTS:
            item["reason"] = "Too few agents to test (%d and %d; at least %d each)." % (len(a), len(b), MIN_AGENTS)
            ck.append(_chk("Enough agents", "fail", item["reason"])); later("Gap large enough", "Adjusted-gap confirmation")
        else:
            ck.append(_chk("Enough agents", "pass", "%d agents in the group and %d in the rest; at least %d each." % (len(a), len(b), MIN_AGENTS)))
            material = overall and abs(gap) / overall >= MATERIALITY
            ck.append(_chk("Gap large enough", "pass" if material else "fail", "The gap is %.1f%% of the overall figure; at least %.0f%% needed." % (100 * abs(gap) / overall if overall else 0, MATERIALITY * 100)))
            ck.append(_chk("Adjusted-gap confirmation", "not run", ADJUSTED_GAP_WITHHELD))
            if not material: item["reason"] = "The gap is below %.0f%% of the overall figure." % (MATERIALITY * 100)
            else: item["reason"] = ADJUSTED_GAP_WITHHELD
        out.append(item)
    return out


def _agent_totals(rows):
    agents = {}
    for r in rows:
        if r.get("agent_id"):
            n, d = agents.get(r["agent_id"], (0, 0)); agents[r["agent_id"]] = (n + r["total"], d + r["count"])
    return agents


def agent_cohorts(rows, direction="lower_is_better", groups=4):
    """Quartiles (groups=4) or deciles (groups=10) of agents; an agent needs MIN_CONTACTS contacts to be ranked."""
    return C.build(_agent_totals(rows), direction, floor=MIN_CONTACTS, groups=groups)


def _agent_histogram(agents, cohorts, deciles):
    """All views count the same pooled agent values against the overall bin boundaries."""
    values = {agent: total / count for agent, (total, count) in agents.items() if count > 0}
    if not values:
        return None
    ordered = sorted(values.values())
    low, high = ordered[0], ordered[-1]
    edges = sorted({low + (high - low) * i / 10 for i in range(10)} | {high})
    if len(edges) == 1:
        edges.append(high)
    bins = len(edges) - 1
    memberships = {agent: min(bins - 1, bisect_right(edges, value) - 1) for agent, value in values.items()}

    def counts(members):
        totals = [0] * bins
        for agent in members:
            totals[memberships[agent]] += 1
        return totals

    views = [{"key": "overall", "label": "Overall", "counts": counts(values)}]
    for result in (cohorts, deciles):
        if result.get("ok"):
            for group in result["cohorts"]:
                if group["n_agents"] and not group["held_back"]:
                    label = f'{result["kind"].title()} {group["position"]}'
                    views.append({"key": label.lower().replace(" ", "-"), "label": label, "counts": counts(group["agents"])})
    return {"edges": edges, "views": views, "cohort_floor": MIN_CONTACTS,
            "median": C.percentile(ordered, 0.5),
            "quartile_cuts": cohorts["cut_points"] if cohorts.get("ok") else []}


def contact_driver_impact(groups, baseline, count, direction):
    """Descriptive volume-weighted deviations from the scoped KPI, with favorable impact positive."""
    if baseline is None or not count or direction not in ("lower_is_better", "higher_is_better"):
        return None
    eligible = [(g, Fraction(str(g["total"]))) for g in groups if g["count"]]
    if sum(g["count"] for g, _ in eligible) != count:
        return None
    total = sum(value for _, value in eligible)
    sign = -1 if direction == "lower_is_better" else 1
    # All deviations share the denominator count squared. Compare exact numerators
    # so a driver at the 80% boundary is classified before any rounding.
    ranked = [(g, sign * (value * count - total * g["count"])) for g, value in eligible]
    ranked.sort(key=lambda item: (-abs(item[1]), item[0]["key"]))
    magnitude = sum(abs(weighted_gap) for _, weighted_gap in ranked)
    if not magnitude:
        return None
    rows, cumulative = [], 0
    for g, weighted_gap in ranked:
        size = abs(weighted_gap)
        vital_few = within_priority_cutoff(cumulative, size, magnitude)
        cumulative += size
        rows.append({"key": g["key"], "count": g["count"], "value": g["value"],
                     "impact": float(weighted_gap / count**2), "share": float(size / magnitude),
                     "cumulative": float(cumulative / magnitude), "vital_few": vital_few})
    return {"baseline": baseline, "count": count, "direction": direction, "rows": rows,
            "adverse": [row for row in rows if row["impact"] < 0][:3]}


def mix_change(rows, period):
    """Rate and mix effects between the first and second half of the period, by Line of Business."""
    start, end = period
    days = sorted({r["date"] for r in rows})
    if len(days) < 14:
        return {"ok": False, "blocked": [{"code": "TOO-SHORT", "reason": "At least 14 days are needed to compare two halves."}]}
    mid = days[len(days) // 2]
    def side(sel):
        out = {}
        for r in sel:
            n, d = out.get(r["line_of_business_id"], (0, 0)); out[r["line_of_business_id"]] = (n + r["total"], d + r["count"])
        return out
    result = D.decompose(side([r for r in rows if r["date"] < mid]), side([r for r in rows if r["date"] >= mid]))
    if result["ok"]:
        result.update(baseline_dates=(days[0], days[len(days) // 2 - 1]), evaluated_dates=(mid, days[-1]))
    return result


def _fmt(x, unit):
    """A gap or change in the metric's own unit: seconds, percentage points (for a share) or points."""
    if unit == "fraction": return "%.1f percentage points" % abs(x * 100)
    if unit == "percent": return "%.1f percentage points" % abs(x)
    if unit == "points": return "%.1f points" % abs(x)
    return "%.0f seconds" % abs(x)


TREND_MIN_STEPS = 4            # consecutive weekly moves the wrong way before a trend card is considered (assumption to confirm with EJ)


def _adverse(x, direction):
    return x > 0 if direction == "lower_is_better" else x < 0


def cohort_finding(rows, cohorts, direction, metric, label, unit, overall, grain, contact_type_gap_supported):
    """The worst agent quartile against everyone. Consistent in a contact type when the cohort is worse than all agents there with enough contacts."""
    if not cohorts or not cohorts.get("ok") or cohorts.get("kind") != "quartile":
        return None
    worst = cohorts["cohorts"][-1]; members = set(worst["agents"])
    if worst["value"] is None or len(members) < 2 or not overall:
        return None
    gap = worst["value"] - overall
    if not _adverse(gap, direction) or abs(gap) / overall < MATERIALITY:
        return None
    consistent = 0
    for ct, grp in _by([r for r in rows if r.get("agent_id")], "contact_type").items():
        mine = [r for r in grp if r["agent_id"] in members]
        if _sum(mine)[0] >= MIN_CONTACTS and _sum(grp)[0] and _adverse(_sum(mine)[2] - _sum(grp)[2], direction):
            consistent += 1
    hours = abs(gap) * worst["observations"] / 3600.0 if unit == "seconds" else None
    return {"id": "cohort-worst-quartile", "pattern": "cohort_gap", "metric": metric, "direction": direction, "support": "supported",
            "impact": {"value": hours, "unit": "hours"} if hours is not None else None,
            "fields": {"cohort": "quartile 4 (worst)", "gap": _fmt(gap, unit), "direction_word": "above" if gap > 0 else "below", "categories": str(consistent), "metric_label": label},
            "categories_consistent": consistent, "grain": grain, "contact_type_gap_supported": bool(contact_type_gap_supported)}


def trend_finding(rows, period, direction, metric, label, unit, overall):
    """A run of consecutive complete weeks moving the wrong way up to the latest week, from the same weekly series the forecast uses."""
    weeks = FC.weekly_series(rows, period)
    if len(weeks) < FC.MIN_WEEKS or any(w["value"] is None for w in weeks) or not overall:
        return None
    vals = [w["value"] for w in weeks]; steps = 0
    while steps < len(vals) - 1 and _adverse(vals[-1 - steps] - vals[-2 - steps], direction):
        steps += 1
    change = vals[-1] - vals[-1 - steps] if steps else 0
    if steps < TREND_MIN_STEPS or abs(change) / overall < MATERIALITY:
        return None
    return {"id": "trend-wrong-way", "pattern": "trend_decline", "metric": metric, "direction": direction, "support": "supported", "impact": None,
            "fields": {"weeks": str(steps), "change": "%s%s" % ("+" if change > 0 else "-", _fmt(change, unit)), "metric_label": label}}


TENSION_MIN_CHANGE = 0.02      # a half-to-half move of at least 2% in each measure (assumption to confirm with EJ)


def tension_findings(rows, cv, direction, metric, label):
    """Where the analysed metric improved between the two halves of the period while its countervailing measure worsened, by Line of Business.
    cv: {"rows", "label", "metric", "direction"}. An association between two movements, not a cause."""
    days = sorted({r["date"] for r in rows})
    if len(days) < 14 or not cv or not cv.get("rows"):
        return []
    mid = days[len(days) // 2]
    def half(rs, lob, late):
        sel = [r for r in rs if r["line_of_business_id"] == lob and ((r["date"] >= mid) == late)]
        c, t, v = _sum(sel)
        return v if c >= MIN_CONTACTS else None
    out = []
    for lob in sorted({r["line_of_business_id"] for r in rows}):
        a0, a1, b0, b1 = half(rows, lob, False), half(rows, lob, True), half(cv["rows"], lob, False), half(cv["rows"], lob, True)
        if None in (a0, a1, b0, b1) or not a0 or not b0:
            continue
        da, db = (a1 - a0) / abs(a0), (b1 - b0) / abs(b0)
        improved = not _adverse(da, direction) and abs(da) >= TENSION_MIN_CHANGE
        worsened = _adverse(db, cv["direction"]) and abs(db) >= TENSION_MIN_CHANGE
        if improved and worsened:
            out.append({"id": "tension-%s" % lob, "pattern": "countervailing_tension", "metric": metric, "direction": direction, "support": "supported", "impact": None,
                        "fields": {"cv_label": cv["label"], "metric_label": label, "group": "Line of Business %s" % lob},
                        "cv_trends": [{"metric": cv["metric"], "label": cv["label"], "qualified": True}]})
    return out


def findings(rows, period, direction="lower_is_better", metric="aht", label="average handle time", roster=None, unit="seconds", grain="contact", extra=None, cv=None, action_direction=None):
    """Findings in the playbook's shape plus the full tables for the page."""
    rows, match = enrich(rows, roster)
    c_all, t_all, overall = _sum(rows)
    out = {"roster_match": match if roster is not None else None, "assumptions": ASSUMPTIONS, "overall": {"contacts": c_all, "value": overall}, "segments": {}, "cohorts": None, "deciles": None, "mix": None, "findings": []}
    if not c_all:
        return out
    for dim in WORK_DIMENSIONS + (PEOPLE_DIMENSIONS if roster else ()):
        out["segments"][dim] = segment_gaps(rows, dim, direction)
    agents = _agent_totals(rows)
    out["cohorts"] = C.build(agents, direction, floor=MIN_CONTACTS)
    out["deciles"] = C.build(agents, direction, floor=MIN_CONTACTS, groups=10)
    out["agent_histogram"] = _agent_histogram(agents, out["cohorts"], out["deciles"])
    for f in (cohort_finding(rows, out["cohorts"], direction, metric, label, unit, overall, grain, False), trend_finding(rows, period, direction, metric, label, unit, overall)):
        if f: out["findings"].append(f)
    out["findings"].extend(extra or [])
    out["findings"].extend(tension_findings(rows, cv, direction, metric, label))
    mix = mix_change(rows, period); out["mix"] = mix
    action_direction = action_direction or direction
    if (mix.get("ok") and action_direction in ("lower_is_better", "higher_is_better")
            and _adverse(mix["mix_effect"], action_direction) and abs(mix["mix_effect"]) >= MATERIALITY * overall * 0.2):
        top = next((g for g in D.top_groups(mix, "mix_effect", len(mix["groups"]))
                    if _adverse(g["mix_effect"], action_direction)), None)
        if top:
            out["findings"].append({"id": "mix-shift", "pattern": "mix_shift", "metric": metric, "direction": direction, "support": "supported",
                                    "impact": None, "fields": {"top_group": "Line of Business %s" % top["group"], "metric_label": label,
                                                         "change": "%s%s" % ("+" if mix["change"] > 0 else "-", _fmt(mix["change"], unit))}})
    return out


def cards(found, allow_draft=False):
    """Playbook selection for these findings. Drafts stay out until the owner approves entries; allow_draft is for the prototype."""
    return P.select(found["findings"], allow_draft=allow_draft)


def _status(card, book):
    entry = next((a for a in book["actions"] if a["id"] == card["action"]), None)
    return entry["status"] if entry else "draft"


def _action_id(*parts):
    return "_".join(quote(str(part), safe="").replace("_", "%5F") for part in parts)


def _report_action_context(metric, pairs):
    mapping = {"aht": ("qa_score", None), "csat": (None, "qa_score"), "qa_score": ("aht", None)}
    context = {}
    for role, peer, sign in zip(("CV", "NS"), mapping.get(metric, (None, None)), (1, -1)):
        pair = next((pair for pair in pairs if pair["id"] == peer), None)
        coefficient = pair.get("r") if pair and pair["status"] == "descriptive" else None
        context[role] = {"metric": peer, "coefficient": coefficient, "source": pair.get("source") if pair else None,
                         "weeks": len(pair.get("weeks", [])) if pair else 0, "mapping_version": "2026-11-14",
                         "expected_sign": "negative" if role == "CV" else "positive",
                         "points": int(coefficient is not None and sign * coefficient >= .30),
                         "status": pair["status"] if pair else "unavailable" if peer else "not_applicable",
                         "reason": ("No metric is mapped to this role." if not peer else
                                    "No eligible paired weekly result." if not pair else
                                    "The paired result is " + pair["status"].replace("_", " ") + "." if coefficient is None else None)}
    return context


def _action_opportunities(findings, rows, period, cohorts, direction, report_scope):
    """Bind currently supported single findings to stable opportunities and available comparison inputs."""
    left, right = map(date.fromisoformat, period)
    midpoint = (left + timedelta(days=((right - left).days + 1) // 2)).isoformat()
    opportunities = {}
    for finding in findings:
        if finding.get("support") != "supported":
            continue
        pattern, fields = finding["pattern"], finding["fields"]
        scoped = []
        binding = finding.get("opportunity_binding")
        if binding:
            question, analysis, variable = binding["question"], binding["analysis"], tuple(binding["variable"])
            evidence = binding["evidence"]
            if binding.get("row_scope"):
                scoped = [row for row in rows if all(row.get(key) == value for key, value in binding["row_scope"].items())]
        elif pattern == "constraint_pareto":
            constraint = finding["constraint"]
            question, analysis = "I1", "constraint_pareto"
            variable = ("constraint", constraint["level1"], constraint["level2"][0])
            evidence = "g-constraints-evidence"
        elif pattern == "cohort_gap":
            question, analysis, variable = "T2", "agent_cohorts", ("group", "agent_cohort", "quartile_4")
            members = set(cohorts["cohorts"][-1]["agents"])
            scoped = [row for row in rows if row.get("agent_id") in members]
            evidence = "g-cohort-evidence-quartiles"
        elif pattern == "mix_shift":
            question, analysis, variable = "D3", "mix_change", ("group", "work_mix", "line_of_business")
            scoped = rows
            evidence = "g-mix-evidence"
        elif pattern == "trend_decline":
            question, analysis, variable = "time-results", "trend_finding", ("metric", "", finding["metric"])
            scoped = rows
            evidence = "g-trend-evidence"
        elif pattern == "countervailing_tension":
            group = fields["group"].removeprefix("Line of Business ")
            question, analysis, variable = "relationships", "tension_findings", ("group", "line_of_business", group)
            scoped = [row for row in rows if row["line_of_business_id"] == group]
            evidence = "g-evidence-relationships"
        elif pattern == "component_gap":
            question, analysis = "points-lost", pattern
            variable = ("component", fields.get("source", ""), finding["id"])
            evidence = "g-shortfalls-evidence"
        else:
            continue
        first = _sum([row for row in scoped if period[0] <= row["date"] < midpoint])
        second = _sum([row for row in scoped if midpoint <= row["date"] <= period[1]])
        reason = ("No governed half-period KPI for this opportunity." if not scoped else
                  "The first or second half has no eligible observations." if not first[0] or not second[0] else
                  "The first-half KPI is zero." if first[2] == 0 else
                  "The metric has no favorable direction." if direction not in ("lower_is_better", "higher_is_better") else None)
        adverse = None if reason else (second[2] - first[2]) / abs(first[2])
        worsening = min(1.0, abs(adverse) / .05) if adverse is not None and _adverse(adverse, direction) else 0.0
        opportunities[finding["id"]] = {
            "opportunity_id": _action_id(question, analysis, *variable), "analysis_id": _action_id(question, analysis),
            "question": question, "analysis": analysis, "variable": variable, "evidence": evidence,
            "source_finding": finding["id"], "claim_status": finding.get("claim_status", "descriptive"),
            "checks": (binding or {}).get("checks", {}),
            "population": (binding or {}).get("population"), "report_scope": report_scope,
            "first_half": first[2], "second_half": second[2], "half_inputs": [first, second],
            "cutoff": midpoint, "worsening": worsening, "worsening_available": reason is None, "worsening_reason": reason,
        }
    analyses = {}
    for opportunity in opportunities.values():
        key = opportunity["variable"], opportunity["population"]
        analyses.setdefault(key, set()).add(opportunity["analysis_id"])
    for opportunity in opportunities.values():
        key = opportunity["variable"], opportunity["population"]
        opportunity["recurrence_analyses"] = sorted(analyses[key])
        opportunity["recurrence"] = min(1.0, .5 * (len(opportunity["recurrence_analyses"]) - 1))
    return opportunities


def _action_rank_key(card):
    score, lift = card["opportunity_score"], card.get("lift")
    return score is None, -(score or 0), -card["urgency"], -(lift or 0), card["title"], card["instance_id"]


def _action_score(urgency, lift, room):
    return None if lift is None or room is None else 100 * (urgency / 5) * (lift / room) if room > 0 else 0.0


def _rank_action_cards(cards, allocations, room, context, opportunities):
    shared = sum(role["points"] for role in context.values())
    for card in cards:
        opportunity = opportunities[card["finding"]]
        card.update(opportunity, urgency=1 + opportunity["recurrence"] + opportunity["worsening"] + shared)
        pool_allocations = (allocations or {}).get("matched_pools", {}).get(card["instance_id"], [])
        lift = allocations["card_lift"][card["instance_id"]] if pool_allocations else None
        if not pool_allocations and room is not None and card["sizing_pools"] and (room == 0 or allocations and not allocations["total_impact"]):
            lift = 0.0
        card.update(opportunity_score=_action_score(card["urgency"], lift, room), pool_allocations=pool_allocations)
        if lift is not None:
            card["lift"] = lift
        else:
            card["lift_reason"] = ("Improvement room is unavailable." if card["sizing_pools"] and room is None
                                   else "No compatible, eligible occurrence pool is bound to this action.")
    cards.sort(key=_action_rank_key)
    ranks, ties, selected, other = {}, {}, [], []
    for card in cards:
        category, score = card["category"], card["opportunity_score"]
        ranks[category] = ranks.get(category, 0) + 1
        card.update(rank=ranks[category], tied=False)
        if score is not None:
            key = (category, score)
            if key in ties:
                card["tied"] = ties[key]["tied"] = True
            ties[key] = card
        if card["rank"] <= P.PRIMARY_PER_CATEGORY:
            selected.append(card)
            card.update(overall_rank=len(selected), disposition="selected")
        else:
            card.update(disposition="overflow", covered_followups=card.pop("also_review", ()))
            other.append(card)
    score_counts = {}
    for card in selected:
        value = card["opportunity_score"]
        score_counts[value] = score_counts.get(value, 0) + 1
    for card in selected:
        value = card["opportunity_score"]
        card["overall_tied"] = value is not None and score_counts[value] > 1
    return selected, other


def _delivery_status(selected):
    """Preserve allocated shares while excluding incomplete selected bundles."""
    deliverable = {card["instance_id"]: card for card in selected}
    while True:
        incomplete = [
            card for card in deliverable.values()
            if any(not any(peer["action"] == template and peer["instance_id"] != card["instance_id"]
                           and peer["population"] is not None and peer["population"] == card["population"]
                           and peer["report_scope"] == card["report_scope"] for peer in deliverable.values())
                   for template in card.get("requires_templates", ()))
        ]
        if not incomplete:
            break
        for card in incomplete:
            del deliverable[card["instance_id"]]
            card["delivery_reason"] = "The selected recommendations omit a required action in the same verified scope."
    return deliverable


def _external_potential(lines, room, adoption, context):
    rows, total = CO.pools([{**row, "controllable": not row["controllable"]} for row in lines])
    urgency = 1 + sum(role["points"] for role in context.values())
    priorities = []
    for row in rows:
        if row["unclassified"] or not row["vital_few"]:
            continue
        potential = None if room is None else room * row["share"] * adoption
        priorities.append({"category": row["level1"], "title": row["level2"], "count": row["controllable"], "share": row["share"],
                           "urgency": urgency, "lift": potential, "opportunity_score": _action_score(urgency, potential, room),
                           "instance_id": _action_id("I1", "uncontrollable_constraint_pareto", "constraint", row["level1"], row["level2"])})
    priorities.sort(key=_action_rank_key)
    for rank, item in enumerate(priorities, start=1):
        item["rank"] = rank
    ledger = [{"category": row["level1"], "label": row["level2"], "count": row["controllable"], "share": row["share"],
               "priority": row["vital_few"], "unclassified": row["unclassified"]}
              for row in rows if row["controllable"] > 0]
    return {"priorities": priorities, "pool_ledger": ledger, "total_occurrences": total,
            "total_potential": None if room is None else sum(item["lift"] for item in priorities), "adoption": adoption}


def report(rows, period, direction="lower_is_better", metric="aht", label="average handle time", allow_draft=True, roster=None, unit="seconds", grain="contact", extra=None, constraints=None, components=None, cv=None, scenario_args=None, metric_relationships=(), action_scope=None):
    """The JSON-safe block the report page reads. Cards from draft playbook entries are marked draft (the owner approves entries)."""
    action_direction = (action_scope or {}).get("direction", direction)
    found = findings(rows, period, direction, metric, label, roster, unit, grain, extra, cv, action_direction=action_direction)
    book = P.load()
    context = _report_action_context(metric, metric_relationships)
    action_scope = {"metric": metric, "unit": unit, "direction": direction, "period": period,
                    "count": found["overall"]["contacts"], "grain": grain, **(action_scope or {})}
    opportunities = _action_opportunities(found["findings"], rows, period, found["cohorts"], action_direction, action_scope)
    picked = P.select([finding for finding in found["findings"] if finding["id"] in opportunities],
                      book=book, allow_draft=allow_draft, candidates_only=True)
    picked["withheld"].extend({"finding": finding["id"], "reason": "No eligible canonical opportunity binding."}
                              for finding in found["findings"] if finding["id"] not in opportunities)
    unique_cards = {}
    for card in sorted(picked["cards"], key=lambda item: item["finding"]):
        opportunity = opportunities[card["finding"]]
        card["instance_id"] = _action_id(action_scope.get("revision", action_scope.get("run_id", "")), card["action"], opportunity["opportunity_id"],
                                         opportunity["population"] or "")
        if card["instance_id"] in unique_cards:
            sources = unique_cards[card["instance_id"]]["source_findings"]
            if card["finding"] not in sources:
                sources.append(card["finding"])
            continue
        card["source_findings"] = [card["finding"]]
        unique_cards[card["instance_id"]] = card
        card["status"] = _status(card, book)
        card["sizing_pools"] = card["level2"] if opportunity["analysis_id"] == _action_id("I1", "constraint_pareto") else []
        if card["sizing_pools"]:
            card["title"] = "Review " + card["sizing_pools"][0]["level2"].lower()
        elif card["lever"] == "Handling flow review":
            card["title"] = "Review handling flow"
        else:
            card["title"] = "Review " + (card["lever"] or card["category"]).lower()
    candidates, trace, covered = P.combine_actions(list(unique_cards.values()), opportunities,
                                                   book.get("combination_recipes", ()), allow_draft)
    for card in candidates:
        if not card.get("rule"):
            card["member_ids"] = [opportunities[card["finding"]]["opportunity_id"]]
    scenario, res, external = None, None, None
    room = scenario_args.get("gap") if scenario_args else None
    if scenario_args and scenario_args.get("lines"):
        adoption = scenario_args["adoption"]
        external = _external_potential(scenario_args["lines"], room, adoption, context)
        if room is None:
            scenario = {"blocked": scenario_args.get("gap_reason") or "NO-LIFT"}
        else:
            lift_cards = [{"id": c["instance_id"], "level2": c["sizing_pools"]} for c in candidates if c["sizing_pools"]]
            res = CO.lift(scenario_args["lines"], room, lift_cards, adoption, True)
    out_cards, other = _rank_action_cards(candidates, res, room, context, opportunities)
    deliverable = _delivery_status(out_cards)
    incomplete = [card for card in out_cards if card["instance_id"] not in deliverable]
    category_lift = {}
    for card in deliverable.values():
        if "lift" in card:
            category_lift[card["category"]] = category_lift.get(card["category"], 0.0) + card["lift"]
    if res:
        if res["ok"]:
            sign = -1.0 if scenario_args["direction"] == "lower_is_better" else 1.0
            base, target = scenario_args["baseline"], scenario_args.get("target")
            total_lift = sum(category_lift.values())
            after = base + sign * total_lift
            addressed = sum(res["card_room"].get(key, 0.0) for key in deliverable)
            scenario = {"adoption": res["adoption"], "baseline": base, "total_lift": total_lift, "after": after, "room": room,
                        "unaddressed": max(0.0, room - total_lift), "label": res["label"], "target": target, "target_met": None,
                        "baseline_target_met": None, "adoption_to_meet_target": None, "target_beyond_modeled_lift": False}
            if incomplete:
                scenario.update(delivery_status="incomplete", withheld_lift=sum(card.get("lift", 0) for card in incomplete))
            if total_lift > 0:
                scenario["glidepath"] = CO.glidepath(base, total_lift, DEFAULT_GLIDEPATH_WEEKS, scenario_args["direction"])
            if target is not None and scenario_args["direction"] in ("lower_is_better", "higher_is_better"):
                scenario["baseline_target_met"] = sign * (base - target) >= 0
                if not incomplete:
                    scenario["target_met"] = sign * (after - target) >= 0
                if scenario["target_met"] is False and addressed > 0:
                    full_adoption_value = base + sign * addressed
                    scenario["target_beyond_modeled_lift"] = sign * (target - full_adoption_value) > 0
                    if not scenario["target_beyond_modeled_lift"]:
                        to_target = CO.gap(base, target, scenario_args["direction"])
                        scenario["adoption_to_meet_target"] = min(1.0, to_target / addressed)
        else:
            scenario = {"blocked": res["blocked"][0]["code"]}
    def view(co):
        if co.get("ok"):
            return {"kind": co["kind"], "n_ranked": co["n_ranked"], "n_unranked": len(co["unranked"]), "floor": MIN_CONTACTS, "cut_points": co["cut_points"],
                    "cohorts": [{k: c[k] for k in ("position", "label", "n_agents", "observations", "value", "held_back")} for c in co["cohorts"]]}
        return {"blocked": co.get("blocked"), "n_unranked": len(co.get("unranked", [])), "floor": MIN_CONTACTS} if co else None
    cohorts, deciles = view(found["cohorts"] or {}), view(found["deciles"] or {})
    mix = found["mix"] or {}
    return {"assumptions": ASSUMPTIONS, "overall": found["overall"], "direction": direction, "metric": metric, "metric_label": label,
            "roster_match": found["roster_match"], "segments": found["segments"], "cohorts": cohorts, "deciles": deciles,
            "pairwise": {dim: pairwise_gaps(rows, dim) for dim in WORK_DIMENSIONS},
            "agent_histogram": found.get("agent_histogram"),
            "mix": ({key: mix[key] for key in ("change", "rate_effect", "mix_effect", "value_baseline", "value_evaluated",
                                               "baseline_dates", "evaluated_dates", "contacts")}
                    if mix.get("ok") else {"blocked": mix.get("blocked")}),
            "cards": out_cards, "other_recommendations": other, "category_lift": category_lift,
            "action_context": context, "external_potential": external,
            "action_attribution": {"scope": action_scope, "opportunities": list(opportunities.values()),
                                   "room": room, "adoption": scenario_args["adoption"] if scenario_args else None,
                                   "routes": trace, "coverage": covered, "withheld": picked["withheld"],
                                   "observations": picked["observations"] + picked["honourable_mentions"]},
            "withheld": len(picked["withheld"]), "observations": len(picked["observations"]),
            "constraints": ({"pools": [{k: p[k] for k in ("level1", "level2", "count", "controllable", "share", "cumulative", "vital_few", "unclassified")} for p in constraints["pools"]],
                             "total_controllable": constraints["total_controllable"],
                             "methods": constraints["methods"], "problems": len(constraints["problems"])} if constraints else None),
            "components": components, "scenario": scenario}
