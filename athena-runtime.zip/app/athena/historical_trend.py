"""M009 v1.0.0. Descriptive daily AHT fits on the completed business-date grid."""

from datetime import date, timedelta
from math import ceil, frexp, isfinite, ldexp

import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit


METHOD = "M009"
MIN_DAYS = 14
REPORTING_CUTOFF = 0.50
FORMS = ("linear", "quadratic", "exponential", "pearl_reed")


def reporting(score):
    return {"qualifies": score is not None and isfinite(score) and score >= REPORTING_CUTOFF,
            "continuation": False}


def _nonlinear(x, y, form):
    """Fit in original units up to a common scale factor. Use fixed, bounded starts."""
    scale = float(np.max(y))
    actual = y / scale
    if form == "exponential":
        def curve(t, p):
            return p[0] * np.exp(t * p[1])

        log_slope, log_start = np.polyfit(x, np.log(actual), 1)
        starts = [(float(np.clip(np.exp(log_start), 1e-6, 1.9)), float(np.clip(log_slope, -9.9, 9.9)))]
        bounds = ([0, -10], [2, 10])
    else:
        def curve(t, p):
            # A / (1 + exp(-k*(t-m))), the identifiable three-parameter Pearl–Reed form.
            return p[0] * expit(p[1] * (t - p[2]))

        starts = [(amplitude, rate, midpoint) for amplitude in (1.05, 1.8)
                  for rate in (-12, -4, 4, 12) for midpoint in (.25, .5, .75)]
        bounds = ([0, -35, x[2]], [8, 35, x[-3]])
        starts = [start for start in starts if bounds[0][2] < start[2] < bounds[1][2]]
        if not starts:
            starts = [(1.5, rate, (x[2] + x[-3]) / 2) for rate in (-8, 8)]

    valid = []
    for start in starts:
        solved = least_squares(lambda p: curve(x, p) - actual, start, bounds=bounds, max_nfev=400)
        if not solved.success or np.any(solved.active_mask) or np.linalg.cond(solved.jac) > 1e7:
            continue
        if form == "pearl_reed" and (abs(solved.x[1]) < .1 or not x[2] < solved.x[2] < x[-3]):
            continue
        valid.append(solved)
    if not valid:
        return None
    params = min(valid, key=lambda run: run.cost).x
    return lambda t: scale * curve(t, params)


def _landmarks(form, values, dates, coefficients):
    details = {}
    if form == "quadratic" and coefficients[0] != 0:
        offset = -(coefficients[1] / (2 * coefficients[0])) * (len(dates) - 1)
        if 0 < offset < len(dates) - 1:
            details["turn"] = {"date": dates[int(offset + .5)], "value": float(np.polyval(
                coefficients, offset / (len(dates) - 1))), "kind": "valley" if coefficients[0] > 0 else "peak"}
    if form == "pearl_reed":
        steps = np.diff(values)
        fastest = int(np.argmax(np.abs(steps))) + 1
        direction = "rising" if steps[fastest - 1] > 0 else "falling"
        details["fastest"] = {"date": dates[fastest], "value": float(values[fastest]), "direction": direction}
        half = abs(steps[fastest - 1]) / 2
        if abs(steps[-1]) < half:
            point = next(i for i in range(fastest + 1, len(values)) if abs(steps[i - 1]) < half)
            details["leveling"] = {"date": dates[point], "value": float(values[point]), "until": dates[-1],
                                   "average": float(np.mean(values[point:]))}
    return details


def build(days, start, end):
    first, last = date.fromisoformat(start), date.fromisoformat(end)
    length = (last - first).days + 1
    observed = sorted((day["key"], day["value"]) for day in days
                      if start <= day["key"] <= end and day["count"] > 0
                      and day["value"] is not None and isfinite(day["value"]))
    count = len(observed)
    result = {"method_id": METHOD, "method_version": "1.0.0", "period": {"start": start, "end": end},
              "observed_days": count, "missing_days": length - count, "status": "unavailable",
              "reporting": reporting(None), "candidates": []}
    if count < max(MIN_DAYS, ceil(length / 2)):
        return result | {"reason": "Too few eligible business dates cover this period for a fitted trend."}
    if observed[0][0] != start or observed[-1][0] != end:
        return result | {"reason": "Both ends of the analysis period need an eligible reading for a full-period fit."}
    offsets = np.array([(date.fromisoformat(day) - first).days for day, _ in observed])
    readings = np.array([value for _, value in observed], dtype=float)
    largest = float(np.max(readings))
    # A binary scale avoids adding rounding to exact threshold fixtures.
    scale = ldexp(1.0, frexp(largest)[1] - 1) if largest else 1.0
    constant = bool(np.all(readings == readings[0]))
    y = readings / scale
    x = offsets / (length - 1)
    grid = np.linspace(0, 1, length)
    dates = [(first + timedelta(days=i)).isoformat() for i in range(length)]
    centered_y = y - np.mean(y)
    sst = 0 if constant else float(centered_y @ centered_y)
    fits = {}
    for order, form in enumerate(FORMS):
        coefficients = None
        if order < 2:
            if order and sst == 0:
                continue
            coefficients = np.array([0, y[0]]) if constant else np.polyfit(x, y, order + 1)
            values = np.polyval(coefficients, grid)
            if order and coefficients[0] > 0:
                turn = -coefficients[1] / (2 * coefficients[0])
                if 0 < turn < 1 and np.polyval(coefficients, turn) < 0:
                    continue
        else:
            if not sst or np.any(y <= 0):
                continue
            curve = _nonlinear(x, y, form)
            if curve is None:
                continue
            values = curve(grid)
        if not np.all(np.isfinite(values)) or np.min(values) < 0 or np.max(values) > np.finfo(float).max / max(scale, 1):
            continue
        residuals = y - values[offsets]
        mae = scale * float(np.mean(np.abs(residuals)))
        score = None
        if sst:
            score = 1 - float(residuals @ residuals) / sst
        if not isfinite(mae) or score is not None and not isfinite(score):
            continue
        fits[form] = (values, coefficients, residuals)
        result["candidates"].append({"form": form, "mae": mae, "r_squared": score, "selected": False})
    if not fits:
        return result | {"reason": "No candidate produced a valid historical AHT fit."}
    best = min(candidate["mae"] for candidate in result["candidates"])
    tolerance = max(1e-9, scale * 1e-10)
    winner = next(candidate for candidate in result["candidates"] if candidate["mae"] <= best + tolerance)
    winner["selected"] = True
    form, score = winner["form"], winner["r_squared"]
    values, coefficients, residuals = fits[form]
    delta = scale * float(values[-1] - values[-2])
    terminal = "level" if abs(delta) <= tolerance else "rising" if delta > 0 else "falling"
    adjacent = np.diff(offsets) == 1
    lagged, current = residuals[:-1][adjacent], residuals[1:][adjacent]
    lag_one = float(np.corrcoef(lagged, current)[0, 1]) if len(current) >= 3 and min(np.std(lagged), np.std(current)) > 1e-10 else None
    landmarks = _landmarks(form, values, dates, coefficients)
    for landmark in landmarks.values():
        landmark["value"] *= scale
        if "average" in landmark:
            landmark["average"] *= scale
    return result | {"status": "fit", "reporting": reporting(score),
                     "diagnostics": {"consecutive_pairs": len(current), "lag_one_residual_correlation": lag_one},
                     "fit": {"form": form, "r_squared": score,
                             "values": [{"date": day, "value": scale * float(value)} for day, value in zip(dates, values)],
                             "landmarks": landmarks,
                             "terminal_direction": terminal, "terminal_delta": delta}}
