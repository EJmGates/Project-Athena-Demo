"""Metric registry (config/metric_registry.json) and the agreed variation, capability and survey-pass rules.

Pure functions only; nothing here is wired into a page or admits a method (see config/capabilities.json).
Rules follow docs48 "COPC decision tree and Hermes review":
- VSF = 6 x population standard deviation / mean for ratio-scale metrics.
  Below 0.70 is low, 0.70 to below 1.00 indicates a potential variation issue,
  and 1.00 or higher indicates excessive variation.
- Yield = share of values meeting the target (or inside the band); sigma = Z(yield) + 1.5; 2.5 or higher is on target.
- Scored metrics (CSAT, QA) use a scale start, end and cut-off, or percent; a score at or above the cut-off passes, pooled as passes / responses, never as an average of rates.
"""
import json
import math
from pathlib import Path
from statistics import NormalDist, fmean, pstdev

REGISTRY = json.loads((Path(__file__).resolve().parent.parent / "config/metric_registry.json").read_text(encoding="utf-8"))
DIRECTIONS = REGISTRY["directions"]
METRICS = REGISTRY["metrics"]
_VAR = REGISTRY["variation"]
_CAP = REGISTRY["capability"]


def get(metric_id):
    return METRICS.get(metric_id)


def is_active(metric_id):
    """False only for a metric the registry marks inactive (backlog, for now). Unknown metrics are not active."""
    m = METRICS.get(metric_id)
    return bool(m) and m.get("active", True)


def active_ids():
    return [k for k in METRICS if is_active(k)]


def _number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


# ---- direction requirements -------------------------------------------------------------------------------------

def target_rule(direction):
    return DIRECTIONS[direction]["target_rule"]


def has_verdict(direction):
    return DIRECTIONS[direction]["verdict"]


def check_setup(direction, target, lower, upper):
    """Fault codes for a direction with its target and limits ([] means ready). Limits are always optional unless the direction requires them."""
    if direction not in DIRECTIONS:
        return ["UNKNOWN-DIRECTION"]
    rule = DIRECTIONS[direction]
    given = {"target": target, "lower_specification_limit": lower, "upper_specification_limit": upper}
    faults = []
    if any(v is not None and not _number(v) for v in given.values()):
        faults.append("NOT-A-NUMBER")
    for key in rule["forbids"]:
        if given[key] is not None:
            faults.append("TARGET-NOT-ALLOWED")
    missing = [k for k in rule["requires"] if given[k] is None]
    if missing:
        faults.append("TARGET-REQUIRED" if missing == ["target"] else "BOUNDS-REQUIRED")
    if _number(lower) and _number(upper) and lower > upper:
        faults.append("LOWER-ABOVE-UPPER")
    return faults


# ---- variation ----------------------------------------------------------------------------------------------------

def vsf_rating(value):
    """Classify variation, with ``acceptable`` denoting the potential-issue band."""
    if value < _VAR["goal"]:
        return "low"
    return "acceptable" if value < _VAR["acceptable"] else "high"


def vsf(values, min_n=None):
    """6 x population SD / mean. Withheld with a reason rather than guessed."""
    min_n = _VAR["default_min_observations"] if min_n is None else min_n
    values = list(values)
    if any(not _number(v) for v in values):
        return {"value": None, "rating": None, "n": len(values), "reason": "NOT-A-NUMBER"}
    if len(values) < max(min_n, 2):
        return {"value": None, "rating": None, "n": len(values), "reason": "TOO-FEW"}
    mean = fmean(values)
    if mean <= 0:
        return {"value": None, "rating": None, "n": len(values), "reason": "NON-POSITIVE-MEAN"}
    v = 6 * pstdev(values) / mean
    return {"value": v, "rating": vsf_rating(v), "n": len(values), "reason": None}


def vsf_for_metric(metric_id, values, min_n=None):
    m = METRICS.get(metric_id)
    if m is None:
        return {"value": None, "rating": None, "n": len(list(values)), "reason": "UNKNOWN-METRIC"}
    if not m["vsf_applies"]:
        return {"value": None, "rating": None, "n": len(list(values)), "reason": "NOT-RATIO-SCALE"}
    return vsf(values, min_n)


# ---- capability ---------------------------------------------------------------------------------------------------

def yield_share(values, direction, target=None, lower=None, upper=None):
    """Share of values that meet the target (or sit inside the band, bounds included). None for monitor-only or no values."""
    if direction == "monitor_only":
        return None
    problems = check_setup(direction, target, lower, upper)
    if problems:
        raise ValueError(",".join(problems))
    values = list(values)
    if not values:
        return None
    if direction == "lower_is_better":
        ok = sum(1 for v in values if v <= target)
    elif direction == "higher_is_better":
        ok = sum(1 for v in values if v >= target)
    else:
        ok = sum(1 for v in values if lower <= v <= upper)
    return ok / len(values)


def sigma(share):
    """Z(yield) + 1.5. All or none meeting the target gives no finite sigma, so none is invented."""
    if share is None:
        return {"sigma": None, "on_target": None, "reason": "NO-YIELD"}
    if not 0 <= share <= 1:
        raise ValueError("yield must be between 0 and 1")
    if share >= 1:
        return {"sigma": None, "on_target": True, "reason": "ALL-MEET"}
    if share <= 0:
        return {"sigma": None, "on_target": False, "reason": "NONE-MEET"}
    s = NormalDist().inv_cdf(share) + _CAP["shift"]
    return {"sigma": s, "on_target": s >= _CAP["on_target_sigma"] - 1e-9, "reason": None}   # tolerance for float error at the exact edge


# ---- scored metrics: scale or percent (docs/63) -----------------------------------------------------------------------

def check_scoring(config):
    """Scoring type is Scale or Percent. Scale needs a start, an end above it and a cut-off on the scale (the score that counts as satisfied
    or passing). Percent runs from 0 to 100 and has no cut-off. Nothing is assumed."""
    config = config or {}
    kind = config.get("scoring_type")
    if kind == "percent":
        return []
    if kind != "scale":
        return ["SCORING-TYPE-REQUIRED"]
    start, end, cut = config.get("scale_start"), config.get("scale_end"), config.get("cutoff")
    if not (_number(start) and _number(end)) or start >= end:
        return ["SCALE-REQUIRED"]
    if not _number(cut):
        return ["CUTOFF-REQUIRED"]
    if not start <= cut <= end:
        return ["CUTOFF-OUT-OF-SCALE"]
    return []


def pooled_pass_rate(rows, config):
    """rows: (period, score). Per period and in total: scores at or above the cut-off / scored rows, pooled, never an average of rates.
    Blank means not scored; a score off the scale is counted, not passed."""
    problems = check_scoring(config)
    if problems or config.get("scoring_type") != "scale":
        raise ValueError(",".join(problems or ["SCALE-REQUIRED"]))
    periods, not_scored, off_scale = {}, 0, 0
    for period, value in rows:
        if value is None or (isinstance(value, str) and not value.strip()):
            not_scored += 1
            continue
        if not _number(value) or not config["scale_start"] <= value <= config["scale_end"]:
            off_scale += 1
            continue
        p = periods.setdefault(period, [0, 0])
        p[0] += value >= config["cutoff"]
        p[1] += 1
    out = {k: {"passes": a, "responses": b, "rate": a / b} for k, (a, b) in periods.items()}
    passes = sum(a for a, _ in periods.values())
    responses = sum(b for _, b in periods.values())
    return {"periods": out, "total": {"passes": passes, "responses": responses, "rate": passes / responses if responses else None},
            "not_scored": not_scored, "off_scale": off_scale}


def apply_floor(periods, floor):
    """Keep periods (or agents) with at least `floor` responses; return them and how many were left out."""
    kept = {k: v for k, v in periods.items() if v["responses"] >= floor}
    return kept, len(periods) - len(kept)


# ---- metric configuration -----------------------------------------------------------------------------------------

def setup_gaps(metric_id, config):
    """What the Cockpit still needs before the metric can be analysed (docs/63): AHT nothing; CSAT and QA a scoring type with its scale and
    cut-off; FCR a measure type (survey scoring, or a repeat-contact lookback window); workforce measures a free-text description."""
    m = METRICS.get(metric_id)
    if m is None:
        return ["UNKNOWN-METRIC"]
    config, setup = config or {}, m.get("setup") or {}
    if "scoring_types" in setup:
        return check_scoring(config)
    if "measure_types" in setup:
        kind = config.get("measure_type")
        if kind == "customer_survey":
            return check_scoring(config)
        if kind == "repeat_contact":
            win, unit = config.get("lookback_window"), config.get("lookback_unit")
            if not (_number(win) and win > 0):
                return ["LOOKBACK-REQUIRED"]
            return [] if unit in setup["repeat_contact"]["lookback_units"] else ["LOOKBACK-UNIT-REQUIRED"]
        return ["MEASURE-TYPE-REQUIRED"] if kind is None else ["MEASURE-TYPE-UNKNOWN"]
    if setup.get("description"):
        text = config.get("description")
        return [] if isinstance(text, str) and text.strip() else ["DESCRIPTION-REQUIRED"]
    return []


# ---- roles, default north-star and countervailing measures (docs/55) -----------------------------------------------

PERFORMANCE_QA = "qa_score"


def role(metric_id):
    """'performance' or 'workforce' (None for an unknown metric)."""
    m = METRICS.get(metric_id)
    return m["role"] if m else None


def role_defaults(metric_id, direction=None, available=None):
    """Default north-star (NS) and countervailing (CV) measures for the analysis Y. They cannot be unselected here.
    AHT: talk, hold and after-call work are NS, QA is CV. Other higher-is-better performance metrics: QA is NS.
    Other lower-is-better performance metrics: QA is CV. Workforce metrics and anything else: none.
    `available` limits the result to measures the data actually has (a measure never defaults to itself)."""
    m = METRICS.get(metric_id)
    if m is None:
        raise ValueError("unknown metric: %r" % (metric_id,))
    direction = direction or m["default_direction"]
    ns, cv = [], []
    if m["role"] == "performance":
        ns = list(m.get("default_north_star", []))
        if direction == "higher_is_better":
            ns.append(PERFORMANCE_QA)
        elif direction == "lower_is_better":
            cv.append(PERFORMANCE_QA)
    keep = lambda xs: [x for x in xs if x != metric_id and (available is None or x in available)]
    return {"north_star": keep(ns), "countervailing": keep(cv)}


# ---- ceiling for the constraint-impact gap --------------------------------------------------------------------------

def ceiling(metric_id, direction, target=None, bounded_max=None):
    """The best the metric can reach, used for the gap (ceiling minus baseline). Returns (value, reason); value is None with a reason
    when there is none. Higher is better: use the supplied maximum in the result's units, or the registry's fraction default.
    Lower is better: the target. Band and monitor-only metrics have no lift."""
    m = METRICS.get(metric_id)
    if m is None:
        return None, "UNKNOWN-METRIC"
    if direction in ("within_bounds", "monitor_only"):
        return None, "NO-LIFT"
    if direction == "lower_is_better":
        return (float(target), None) if _number(target) else (None, "TARGET-REQUIRED")
    if direction != "higher_is_better":
        return None, "UNKNOWN-DIRECTION"
    if _number(bounded_max):
        return float(bounded_max), None
    if m["kind"] == "ordinal_score" or m["unit"] == "fraction":
        return 1.0, None
    return None, "MAXIMUM-REQUIRED"
