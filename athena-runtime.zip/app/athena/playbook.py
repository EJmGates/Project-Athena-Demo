"""Action cards from supported findings (the deterministic part of recommendations; docs/55, EJ 6 Nov 2026).

Python picks which actions the evidence supports, rates and ranks them. A later wording step may only rephrase a card; it never
chooses an action or changes a number. Entries come from config/playbook.json and are used only when approved (EJ alone approves).
Nothing here reaches a page or admits a method.

A finding is a plain dict:
  {"id", "pattern", "metric", "direction", "support": "supported" | other, "impact": {"value", "unit"} or None,
   "fields": {...values for the entry's wording...},
   "cv_trends": [{"metric", "label", "qualified"}],      selected countervailing measures trending the wrong way
   "associations": [{"metric", "qualified"}],            measures qualified as related (including north stars)
   "missing_links": [{"metric", "qualified"}],           north-star or countervailing measures that should relate but do not
   group_gap:   "dimension": the kind of group, "mix_held_constant": bool
   cohort_gap:  "categories_consistent": int, "grain": "contact" | "agent_day", "contact_type_gap_supported": bool}

Rating (hidden, 0-100, compared within a category; users see only rank and lift):
  size of the opportunity  50 x impact / sum of impacts of the cards in the same category and unit; no impact gives 0
  quality risk             15 per qualified adverse countervailing trend, up to 30
  connected measures        5 per qualified association, up to 10
  expected link missing     5 per qualified missing link, up to 10
Only qualified evidence earns points, a measure counts once, and the analysis Y itself earns nothing.
"""
import hashlib
import json
import string
from pathlib import Path

CONFIG = Path(__file__).resolve().parent.parent / "config"
PATH = CONFIG / "playbook.json"
CATEGORIES_PATH = CONFIG / "constraint_categories.json"
STATUSES = ("draft", "approved")
ACTION_KINDS = ("directional", "investigate")
DIRECTIONS = ("lower_is_better", "higher_is_better", "within_bounds", "any")
REQUIRED = ("id", "status", "entry_version", "text_sha256", "metrics", "pattern", "direction", "category", "action_kind", "lever",
            "text", "before_you_act", "athena_checks", "limitations", "monitoring", "level2")
FROM_CONSTRAINT = "from_constraint"           # the card takes its category and Level 2 links from the leading constraint
NO_CARD_LEVEL1 = ("Client constraints", "Customer constraints")      # outside the account's control: no card
LIMITS = {"text_words": 35, "long_words": 60, "before_count": 3, "before_words": 20}      # EJ, 6 Nov 2026
GROUP_DIMENSIONS = ("line_of_business", "contact_type", "channel", "tenure_group", "training_wave", "team_lead", "manager", "evaluator")
CONSISTENT_CATEGORIES_MIN = 3        # "several" categories for a cohort gap to be a top finding (assumption to confirm with EJ)
PRIMARY_PER_CATEGORY = 3
POINTS = {"size": 50.0, "risk_each": 15.0, "risk_cap": 30.0, "link_each": 5.0, "link_cap": 10.0}


def text_hash(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _fields(template):
    return {name for _, name, _, _ in string.Formatter().parse(template) if name}


def load(path=PATH):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def load_categories(path=CATEGORIES_PATH):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def validate(book, categories=None):
    """Problems with the playbook itself (an empty list means it is well formed)."""
    cats = categories or load_categories()
    level2 = {(x["level1"], l2) for x in cats["levels"] for l2 in x["level2"]}
    problems, seen = [], set()
    patterns = book.get("patterns", {})
    for entry in book.get("actions", []):
        name = entry.get("id", "?")
        for key in REQUIRED:
            if key not in entry:
                problems.append(f"{name}: missing {key}")
        if name in seen:
            problems.append(f"{name}: duplicate id")
        seen.add(name)
        if entry.get("status") not in STATUSES:
            problems.append(f"{name}: status must be one of {STATUSES}")
        if entry.get("pattern") not in patterns:
            problems.append(f"{name}: unknown pattern {entry.get('pattern')!r}")
        if entry.get("action_kind") not in ACTION_KINDS:
            problems.append(f"{name}: action_kind must be one of {ACTION_KINDS}")
        if entry.get("direction") not in DIRECTIONS:
            problems.append(f"{name}: direction must be one of {DIRECTIONS}")
        if entry.get("category") != FROM_CONSTRAINT and entry.get("category") not in cats["card_categories"]:
            problems.append(f"{name}: category must be one of the card categories or {FROM_CONSTRAINT}")
        words = lambda x: len(str(x).split())
        if "text" in entry and words(entry["text"]) > LIMITS["text_words"]:
            problems.append(f"{name}: card text is over {LIMITS['text_words']} words")
        if entry.get("long_description") is not None and words(entry["long_description"]) > LIMITS["long_words"]:
            problems.append(f"{name}: long description is over {LIMITS['long_words']} words")
        b = entry.get("before_you_act")
        if not isinstance(b, list) or len(b) > LIMITS["before_count"] or any(not isinstance(x, str) or words(x) > LIMITS["before_words"] for x in b):
            problems.append(f"{name}: before_you_act is at most {LIMITS['before_count']} suggestions of {LIMITS['before_words']} words")
        if not isinstance(entry.get("athena_checks"), list) or not entry.get("athena_checks"):
            problems.append(f"{name}: athena_checks needs at least one check")
        if not isinstance(entry.get("limitations"), list) or any(x not in book.get("limitations", {}) for x in entry.get("limitations", [])):
            problems.append(f"{name}: limitations must name lines in the playbook's limitations")
        if "dimensions" in entry and (entry.get("pattern") != "group_gap" or not entry["dimensions"] or any(d not in GROUP_DIMENSIONS for d in entry["dimensions"])):
            problems.append(f"{name}: dimensions belong to group_gap entries and must be known group kinds")
        if entry.get("pattern") == "group_gap" and not entry.get("dimensions"):
            problems.append(f"{name}: a group_gap entry names its dimensions")
        if "withheld_until" in entry and not isinstance(entry["withheld_until"], str):
            problems.append(f"{name}: withheld_until must say what is missing")
        m = entry.get("monitoring", {})
        if not isinstance(m, dict) or isinstance(m.get("review_after_weeks"), bool) or not isinstance(m.get("review_after_weeks"), int) or m["review_after_weeks"] < 1:
            problems.append(f"{name}: monitoring needs review_after_weeks of at least 1")
        if not isinstance(entry.get("entry_version"), int) or isinstance(entry.get("entry_version"), bool) or entry["entry_version"] < 1:
            problems.append(f"{name}: entry_version must be a whole number of at least 1")
        if "text" in entry and entry.get("text_sha256") != text_hash(entry["text"]):
            problems.append(f"{name}: text changed since its hash was recorded; it must be re-approved")
        links = entry.get("level2")
        if entry.get("category") == FROM_CONSTRAINT:
            if links != []:
                problems.append(f"{name}: a card that takes its category from the constraint has no fixed level2 links")
        elif not isinstance(links, list) or not links:
            problems.append(f"{name}: level2 needs at least one link")
        else:
            for link in links:
                if (link.get("level1"), link.get("level2")) not in level2:
                    problems.append(f"{name}: unknown Level 2 {link!r}")
    return problems


def _fill(text, fields):
    """Fill the placeholders a suggestion uses; a placeholder the finding does not supply is left as written."""
    try:
        return text.format(**fields)
    except (KeyError, IndexError, ValueError):
        return text


def _render(entry, fields):
    """Fill the wording; returns (text, missing field names)."""
    values = {**fields, "review_weeks": entry["monitoring"]["review_after_weeks"]}
    missing = sorted(n for n in _fields(entry["text"]) if n not in values)
    if missing:
        return None, missing
    return entry["text"].format(**values), []


def _impact(f):
    i = f.get("impact")
    if isinstance(i, dict) and isinstance(i.get("value"), (int, float)) and not isinstance(i["value"], bool) and i["value"] > 0:
        return {"value": float(i["value"]), "unit": i.get("unit")}
    return None


def _qualified(items, exclude, seen):
    """Distinct qualified measures not yet counted and not the analysis Y; marks them counted."""
    out = []
    for it in items or []:
        m = it.get("metric")
        if it.get("qualified") is True and m and m != exclude and m not in seen:
            seen.add(m)
            out.append(it)
    return out


def _pattern_gate(f, entry):
    """Returns (bucket, kind). bucket is None for a normal card, or 'observation' / 'mention' for findings that get no card."""
    kind = entry["action_kind"]
    if f.get("pattern") == "group_gap" and f.get("mix_held_constant") is not True:
        return "observation", kind
    if f.get("pattern") == "cohort_gap":
        if not isinstance(f.get("categories_consistent"), int) or f["categories_consistent"] < CONSISTENT_CATEGORIES_MIN:
            return "mention", kind
        if f.get("grain") != "contact" or f.get("contact_type_gap_supported") is not True:
            kind = "investigate"                      # agent-day data, or no corroborating contact-type gap: an investigation note
    return None, kind


HELD_COMBINATIONS = {
    "CR02": "A qualified Billing AHT gap and a hold-time finding for that exact population are required.",
    "CR03": "The Billing and hold-time findings plus verified same-contact system-issue coverage are required.",
    "CR04": "An eligible QA group finding and procedure shortfall verified in the same audited work are required.",
    "CR05": "A qualified tenure or training finding and constraint coverage for that population are required.",
}


def _binding_check(repeated, name):
    missing = {"status": "unavailable", "reason": "Required linkage check is missing."}
    checks = [fact["checks"].get(name, missing) for fact in repeated]
    sources = sorted({fact["source_finding"] for fact in repeated})
    if any({k: v for k, v in item.items() if k != "reason"} !=
           {k: v for k, v in checks[0].items() if k != "reason"} for item in checks[1:]):
        return {"status": "fail", "reason": "Repeated evidence disagrees on this required check.", "sources": sources,
                "contradiction": any(item["status"] == "fail" and item.get("contradiction") is True for item in checks)}
    return {**checks[0], "sources": sources}


def combine_actions(candidates, opportunities, recipes, allow_draft):
    """Apply explicitly bound recipes to eligible results before allocation.

    A population key must come from an existing producer's exact scope or
    verified linkage. Matching display labels cannot supply this key.
    """
    singles = {card["instance_id"]: card for card in candidates}
    bound = {recipe["id"] for recipe in recipes}
    trace = [{"rule": rule, "status": "unavailable", "reason": reason}
             for rule, reason in HELD_COMBINATIONS.items() if rule not in bound]
    combined, blocked = [], set()
    for recipe in recipes:
        template = recipe["template"]
        roles = recipe["support"]
        if (recipe["id"] not in HELD_COMBINATIONS or len(roles) != (2 if recipe["id"] == "CR03" else 1)
                or template["status"] not in ("approved", "draft")
                or template["status"] == "draft" and not allow_draft
                or template["text_sha256"] != text_hash(template["text"])):
            trace.append({"rule": recipe["id"], "status": "unavailable", "reason": "Recipe or template is not permitted."})
            continue
        primaries = [card for card in singles.values() if card["action"] == recipe["primary_action"]
                     and opportunities[card["finding"]]["analysis_id"] == recipe["primary_analysis"]]
        if not primaries:
            trace.append({"rule": recipe["id"], "status": "unavailable", "reason": "Required primary opportunity is unavailable."})
        for primary in primaries:
            origin = opportunities[primary["finding"]]
            entry = {"rule": recipe["id"], "primary": origin["opportunity_id"], "roles": []}
            trace.append(entry)
            repeated = [fact for fact in opportunities.values() if fact["opportunity_id"] == origin["opportunity_id"]
                        and fact["population"] == origin["population"] and fact["report_scope"] == origin["report_scope"]]
            primary_check = _binding_check(repeated, recipe.get("primary_check"))
            entry["primary_check"] = primary_check
            if (not origin["population"] or origin["claim_status"] not in recipe["primary_claims"]
                    or primary_check.get("status") != "pass"):
                entry.update(status=primary_check["status"] if primary_check["status"] != "pass" else "unavailable",
                             reason="The required primary claim, population or eligibility check did not pass.")
                if primary_check.get("contradiction") and recipe.get("contradiction") == "block_primary":
                    blocked.add(primary["instance_id"])
                continue
            supporting = {}
            for role in roles:
                matches = {}
                for fact in opportunities.values():
                    if (fact["analysis_id"] == role["analysis_id"] and fact["opportunity_id"] != origin["opportunity_id"]
                            and fact["population"] == origin["population"] and fact["report_scope"] == origin["report_scope"]):
                        matches.setdefault(fact["opportunity_id"], []).append(fact)
                if len(matches) != 1:
                    entry["roles"].append({"role": role["name"], "status": "unavailable",
                                           "reason": "No unique eligible result with the required verified population."})
                    continue
                repeated = next(iter(matches.values()))
                fact = repeated[0]
                check = _binding_check(repeated, role["check"])
                if check["status"] == "pass" and any(item["claim_status"] not in role["claims"] for item in repeated):
                    check.update(status="unavailable", reason="An applicable claim level is unavailable.")
                entry["roles"].append({"role": role["name"], "opportunity": fact["opportunity_id"], "check": role["check"], **check})
                if check["status"] == "pass":
                    supporting[fact["opportunity_id"]] = fact
                elif check.get("contradiction") is True and check["status"] == "fail" and recipe.get("contradiction") == "block_primary":
                    blocked.add(primary["instance_id"])
            if len(supporting) != len(roles):
                failed = any(role["status"] == "fail" for role in entry["roles"])
                entry.update(status="fail" if failed else "unavailable", reason="One or more required support checks did not pass.")
                continue
            members = {origin["opportunity_id"], *supporting}
            fields = ("action", "title", "text", "entry_version", "text_sha256", "status", "category")
            candidate = {**primary, **{field: template[field] for field in fields}, "rule": recipe["id"], "member_ids": sorted(members),
                         "instance_id": primary["instance_id"] + "/" + recipe["id"], "primary_instance_id": primary["instance_id"],
                         "requires_templates": recipe.get("requires_templates", ()), "also_review": []}
            combined.append((candidate, recipe, entry))
    active = {key: card for key, card in singles.items() if key not in blocked}
    dispositions = [{"instance_id": key, "status": "withheld", "reason": "A verified contradiction requires reassessing the primary action."}
                    for key in sorted(blocked)]
    for card, recipe, entry in sorted(combined, key=lambda item: (-len(item[0]["member_ids"]), item[0]["instance_id"])):
        if card["primary_instance_id"] in blocked:
            entry.update(status="fail", reason="The primary opportunity has a verified contradiction.")
            continue
        origin = opportunities[card["finding"]]
        covering = None
        for other in active.values():
            if (other.get("rule") and card["action"] in other["covers_templates"]
                    and card["primary_instance_id"] == other["primary_instance_id"]
                    and set(card["member_ids"]) <= set(other["member_ids"])):
                covering = other
                break
        if covering:
            entry.update(status="covered", covering=covering["instance_id"])
            continue
        card["covers_templates"] = recipe.get("covers", ())
        for key, single in list(active.items()):
            if single.get("rule") or single["action"] not in card["covers_templates"]:
                continue
            fact = opportunities[single["finding"]]
            if fact["opportunity_id"] in card["member_ids"] and fact["population"] == origin["population"]:
                del active[key]
                dispositions.append({"instance_id": key, "opportunity": fact["opportunity_id"], "status": "covered",
                                     "covering": card["instance_id"], "title": single["title"], "evidence": fact["evidence"]})
                wording = recipe.get("followups", {}).get(single["action"])
                if wording and fact["opportunity_id"] != origin["opportunity_id"] and not any(
                        review["opportunity"] == fact["opportunity_id"] for review in card["also_review"]):
                    card["also_review"].append({"opportunity": fact["opportunity_id"], "text": wording, "evidence": fact["evidence"]})
        active[card["instance_id"]] = card
        entry.update(status="pass", candidate=card["instance_id"])
    return list(active.values()), trace, dispositions


def select(findings, book=None, allow_draft=False, *, candidates_only=False):
    """Returns {"cards", "other_recommendations", "observations", "honourable_mentions", "withheld", "ratings"}.
    cards holds at most 3 primary cards per category, in category order; the rest are other recommendations (Evidence).
    A card needs an approved entry (drafts only when allow_draft, for tests), a supported finding and complete wording.
    Impact is optional: a card with none follows the cards that have it."""
    book = book or load()
    built, withheld, observations, mentions = [], [], [], []
    for f in findings:
        entries = [a for a in book["actions"] if a["pattern"] == f.get("pattern") and f.get("metric") in a["metrics"]
                   and a["direction"] in ("any", f.get("direction")) and ("dimensions" not in a or f.get("dimension") in a["dimensions"])]
        if not entries:
            withheld.append({"finding": f.get("id"), "action": None, "reason": "No playbook entry covers this finding."})
            continue
        for a in entries:
            why = None
            category, level2 = a["category"], [dict(x) for x in a["level2"]]
            if a["category"] == FROM_CONSTRAINT:
                lead = f.get("constraint") or {}
                category, level2 = lead.get("level1"), [{"level1": lead.get("level1"), "level2": x} for x in lead.get("level2", [])]
            if "withheld_until" in a and f.get("component_data") is not True:
                why = "Withheld until " + a["withheld_until"] + "."
            elif a["category"] == FROM_CONSTRAINT and (not category or not level2):
                why = "No leading constraint with a category was found."
            elif a["category"] == FROM_CONSTRAINT and category in NO_CARD_LEVEL1:
                why = "The leading constraint is outside the account's control, so there is no card."
            elif a["status"] != "approved" and not allow_draft:
                why = "The playbook entry is not approved."
            elif f.get("support") != "supported":
                why = "The finding is not supported by the evidence."
            if why is None:
                bucket, kind = _pattern_gate(f, a)
                if bucket == "observation":
                    observations.append({"finding": f.get("id"), "action": a["id"],
                                         "reason": "Mix could not be held constant, so this is an observation only."})
                    continue
                if bucket == "mention":
                    mentions.append({"finding": f.get("id"), "action": a["id"],
                                     "reason": "Not consistent across several categories, so not a top finding."})
                    continue
                text, missing = _render(a, f.get("fields", {}))
                if missing:
                    why = "The wording needs: " + ", ".join(missing) + "."
            if why:
                withheld.append({"finding": f.get("id"), "action": a["id"], "reason": why})
                continue
            seen = set()
            trends = _qualified(f.get("cv_trends"), f.get("metric"), seen)
            related = _qualified(f.get("associations"), f.get("metric"), seen)
            missing_links = _qualified(f.get("missing_links"), f.get("metric"), seen)
            note = None
            if trends and kind == "directional":
                kind = "investigate"
                names = ", ".join(str(t.get("label") or t["metric"]) for t in trends)
                note = f"{names} is moving the wrong way. Investigate and validate before acting."
            built.append({"entry": a, "finding": f, "kind": kind, "text": text, "impact": _impact(f), "note": note, "category": category, "level2": level2,
                          "risk": min(POINTS["risk_each"] * len(trends), POINTS["risk_cap"]),
                          "connected": min(POINTS["link_each"] * len(related), POINTS["link_cap"]),
                          "missing": min(POINTS["link_each"] * len(missing_links), POINTS["link_cap"]),
                          "trends": [t.get("label") or t["metric"] for t in trends]})
    def render_card(b):
        a, f = b["entry"], b["finding"]
        return {"action": a["id"], "finding": f.get("id"), "category": b["category"], "action_kind": b["kind"], "text": b["text"],
                "lever": a["lever"], "before_you_act": [_fill(x, f.get("fields", {})) for x in a["before_you_act"]],
                "limitations": [book["limitations"][x] for x in a["limitations"]], "long_description": a.get("long_description"),
                "monitoring": {"review_after_weeks": a["monitoring"]["review_after_weeks"]}, "level2": b["level2"],
                "impact": b["impact"], "investigate_note": b["note"], "adverse_trends": b["trends"],
                "entry_version": a["entry_version"], "text_sha256": a["text_sha256"]}

    ledger = {"observations": observations, "honourable_mentions": mentions, "withheld": withheld}
    if candidates_only:
        return {"cards": [render_card(b) for b in built], **ledger}
    totals = {}
    for b in built:
        if b["impact"]:
            key = (b["category"], b["impact"]["unit"])
            totals[key] = totals.get(key, 0.0) + b["impact"]["value"]
    ratings = []
    for b in built:
        size = POINTS["size"] * b["impact"]["value"] / totals[(b["category"], b["impact"]["unit"])] if b["impact"] else 0.0
        b["rating"] = size + b["risk"] + b["connected"] + b["missing"]
        ratings.append({"action": b["entry"]["id"], "finding": b["finding"].get("id"), "category": b["category"],
                        "rating": b["rating"], "parts": {"size": size, "quality_risk": b["risk"], "connected": b["connected"],
                                                         "expected_link_missing": b["missing"]}})
    order = {c: i for i, c in enumerate(load_categories()["card_categories"])}
    built.sort(key=lambda b: (order[b["category"]], b["impact"] is None, -b["rating"], b["entry"]["id"], str(b["finding"].get("id"))))
    cards, other, rank, last = [], [], {}, {}
    for b in built:
        cat = b["category"]
        rank[cat] = rank.get(cat, 0) + 1
        card = render_card(b) | {"rank": rank[cat]}
        key = (cat, b["impact"] is None, round(b["rating"], 9))        # the tie group within a category
        card["tied"] = False
        if last.get(cat, (None, None))[0] == key:                       # same group as the previous card: show the tie, keep alphabetical order
            card["tied"] = True
            last[cat][1]["tied"] = True
        last[cat] = (key, card)
        (cards if rank[cat] <= PRIMARY_PER_CATEGORY else other).append(card)
    return {"cards": cards, "other_recommendations": other, "ratings": ratings, **ledger}
