"""One date and time reader for every dataset.

Accepted: ISO (YYYY-MM-DD, optional time after T or a space, optional seconds, fraction and offset, Z)
and slash dates with an optional 24-hour or AM/PM time. Slash dates are month-first (M/D/YYYY) by default;
fmt="dmy" reads them day-first. ISO dates never depend on the choice.
A time with no offset is taken as written in the account's operating time zone (default Asia/Manila, a fixed +08:00
that needs no time zone database). An explicit offset is honoured, and the business date is the account zone's calendar day.
Nothing is guessed: anything else is unreadable.
"""
import re
from datetime import datetime, timedelta, timezone, tzinfo
from typing import NamedTuple, Optional
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

PHILIPPINES = timezone(timedelta(hours=8), "Asia/Manila")
FORMATS = ("mdy", "dmy")
FORMAT_NAMES = {"month_first": "mdy", "day_first": "dmy"}       # names used in the configuration and requests
UNREADABLE = "UNREADABLE-DATE"
EMPTY = "EMPTY"

_ISO = re.compile(r"^(\d{4})-(\d{2})-(\d{2})(?:[Tt ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,6}))?)?\s*(Z|z|[+-]\d{2}(?::?\d{2})?)?)?$", re.ASCII)
_SLASH = re.compile(r"^(\d{1,2})/(\d{1,2})/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\s*([AaPp])[Mm])?)?$", re.ASCII)


class Reading(NamedTuple):
    ok: bool
    reason: Optional[str]            # None when ok; EMPTY or UNREADABLE-DATE otherwise
    business_date: Optional[str]     # YYYY-MM-DD, the account zone's day
    instant_utc: Optional[str]       # ISO UTC, None for a date without a time
    has_time: bool
    offset_given: bool


def _bad(reason=UNREADABLE):
    return Reading(False, reason, None, None, False, False)


def _offset(text):
    if text in ("Z", "z"):
        return timezone.utc
    sign = -1 if text[0] == "-" else 1
    digits = text[1:].replace(":", "")
    hours, minutes = int(digits[:2]), int(digits[2:4] or 0)
    if hours > 23 or minutes > 59:
        raise ValueError("offset")
    return timezone(sign * timedelta(hours=hours, minutes=minutes))


def zone_for(zone):
    """A tzinfo for an IANA name (or the tzinfo itself). Manila is fixed so it never needs the time zone database."""
    if zone is None or zone == "Asia/Manila":
        return PHILIPPINES
    if isinstance(zone, tzinfo):
        return zone
    try:
        return ZoneInfo(zone)
    except (ZoneInfoNotFoundError, ValueError, TypeError, OSError):
        raise ValueError("unknown time zone: %r" % (zone,)) from None


def read(value, fmt="mdy", zone=None):
    """Read one cell. Never raises on the value; an unknown fmt or zone is a programming error and raises ValueError."""
    if fmt not in FORMATS:
        raise ValueError("unknown date format: %r" % (fmt,))
    account = zone_for(zone)
    if value is None or not str(value).strip():
        return _bad(EMPTY)
    s = str(value).strip()
    try:
        m = _ISO.match(s)
        if m:
            y, mo, d, hh, mi, ss, frac, off = m.groups()
            if hh is None:                              # date only
                day = datetime(int(y), int(mo), int(d))
                return Reading(True, None, day.date().isoformat(), None, False, False)
            micro = int((frac or "0").ljust(6, "0"))
            naive = datetime(int(y), int(mo), int(d), int(hh), int(mi), int(ss or 0), micro)
            return _done(naive.replace(tzinfo=_offset(off) if off else account), bool(off), account)
        m = _SLASH.match(s)
        if m:
            first, second, y, hh, mi, ss, ap = m.groups()
            mo, d = (first, second) if fmt == "mdy" else (second, first)
            if hh is None:
                day = datetime(int(y), int(mo), int(d))
                return Reading(True, None, day.date().isoformat(), None, False, False)
            hour = int(hh)
            if ap:
                if not 1 <= hour <= 12:
                    return _bad()
                hour = hour % 12 + (12 if ap in "pP" else 0)
            naive = datetime(int(y), int(mo), int(d), hour, int(mi), int(ss or 0))
            return _done(naive.replace(tzinfo=account), False, account)
    except (ValueError, OverflowError):
        return _bad()
    return _bad()


def _done(aware, offset_given, account):
    return Reading(True, None, aware.astimezone(account).date().isoformat(),
                   aware.astimezone(timezone.utc).isoformat(), True, offset_given)
