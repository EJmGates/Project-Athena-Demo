"""Descriptive relationships between independently pooled weekly measures."""
import csv
import io
import math
from datetime import date, timedelta
from fractions import Fraction

import numpy as np

from athena import components, forecast, metric_view, metrics
from athena.pareto import within_priority_cutoff


PEERS = (
    ("aht", "Average handle time", "seconds", None),
    ("csat", "Supplied CSAT score", "supplied score", "D03"),
    ("qa_score", "Supplied QA score", "supplied score", "D04"),
    ("handled", "Handled contacts", "contacts", None),
    ("surveys", "Survey count on matched agent-days", "surveys", "D03"),
)


def _key(row):
    return row["agent_id"], row["date"], row["line_of_business_id"], row["contact_type"]


def _sample_pairs(upload, module, outcome, scope, zone, measure):
    """Intersect agent, business date and work scope without multiplying records."""
    cells = {_key(row) for row in outcome if row.get("agent_id") and row["count"]}
    sample = [row for row in scoped_sample_measure(upload, module, scope, zone, measure) if _key(row) in cells]
    matched = {_key(row) for row in sample}
    return [row for row in outcome if _key(row) in matched], sample


def scoped_sample_measure(upload, module, scope, zone, measure):
    """Eligible sample values at their account-local date and declared work scope."""
    reader = csv.DictReader(io.StringIO(upload["raw"].decode("utf-8-sig"), newline=""))
    column = None if measure == "surveys" else metrics.get(measure)["columns"]["contact"]["score"]
    for raw, record, day in components.scoped_sample_rows(reader, upload, module, scope, zone):
        value = 1 if column is None else record.get(column)
        if day and record["agent_id"] and value is not None:
            yield {"agent_id": record["agent_id"], "date": day,
                   "line_of_business_id": (raw.get("line_of_business_id") or "").strip(),
                   "contact_type": (raw.get("contact_type") or "").strip(), "count": 1, "total": value}


def _linear_summary(rows, preferred_increment=None):
    """Calculate Pearson correlation and either a fitted line or a slope scaled to a supported increment."""
    x, y = np.asarray([(row["measure"], row["outcome"]) for row in rows]).T
    if np.ptp(x) == 0 or np.ptp(y) == 0:
        return None
    scales = np.max(np.abs([x, y]), axis=1)
    xn, yn = x / scales[0], y / scales[1]
    xc, yc = xn - xn.mean(), yn - yn.mean()
    cross = float(xc @ yc)
    r = float(np.clip(cross / (np.linalg.norm(xc) * np.linalg.norm(yc)), -1, 1))
    slope = cross / float(xc @ xc)
    if preferred_increment is not None:
        increment = min(preferred_increment, float(x.max()) - float(x.min()))
        estimate = slope * (increment / float(scales[0])) * float(scales[1])
        effect = {"increment": increment, "estimate": estimate} if math.isfinite(estimate) else None
        return {"r": r, "effect": effect}
    ends = [int(x.argmin()), int(x.argmax())]
    fit = [[float(x[i]), float((yn.mean() + slope * xc[i]) * scales[1])] for i in ends]
    return {"r": r, "fit": fit}


def _describe(pair, outcome, measure, period, count_measure):
    weeks = []
    for y, x in zip(forecast.weekly_series(outcome, period), forecast.weekly_series(measure, period)):
        if x["count"] and y["count"]:
            weeks.append({"start": x["start"], "measure": x["count"] if count_measure else x["value"],
                          "outcome": y["value"], "measure_count": x["count"], "outcome_count": y["count"]})
    pair["weeks"] = weeks
    pair["changes"] = [
        {"from_week": previous["start"], "to_week": current["start"],
         "measure": current["measure"] - previous["measure"],
         "outcome": current["outcome"] - previous["outcome"]}
        for previous, current in zip(weeks, weeks[1:])
        if date.fromisoformat(current["start"]) - date.fromisoformat(previous["start"]) == timedelta(days=7)
    ]
    preferred_increment = 1000 if pair.get("id") == "handled" else 1
    change_fit = (_linear_summary(pair["changes"], preferred_increment)
                  if len(pair["changes"]) >= components.MIN_COMMON_WEEKS else None)
    pair["change_r"] = change_fit["r"] if change_fit is not None else None
    pair["change_effect"] = change_fit["effect"] if change_fit is not None else None
    if not measure:
        pair["status"] = "no_overlap" if pair["matched"] else "unavailable"
    elif len(weeks) < components.MIN_COMMON_WEEKS:
        pair["status"] = "insufficient_weeks"
    else:
        summary = _linear_summary(weeks)
        if summary is None:
            pair["status"] = "constant"
        else:
            pair.update(summary)
            pair["status"] = "descriptive"
    return pair


def _rank_by_strength(pairs):
    """Compute the 80% cutoff across all comparable observed magnitudes."""
    scores = {
        pair["id"]: Fraction(str(abs(pair["r"])))
        for pair in pairs
        if "r" in pair and math.isfinite(pair["r"])
    }
    ranked = sorted(pairs, key=lambda pair: (-scores.get(pair["id"], -1), pair["label"], pair["id"]))
    total = sum(scores.values())
    if not total:
        return ranked

    cumulative = Fraction(0)
    for pair in ranked:
        score = scores.get(pair["id"])
        if score is None:
            continue
        within_cutoff = within_priority_cutoff(cumulative, score, total)
        cumulative += score
        pair["strength_priority"] = {
            "share": float(score / total),
            "cumulative": float(cumulative / total),
            "within_cutoff": within_cutoff,
        }
    return ranked


def build(primary, outcome, metric_id, grain, filename, optionals, scope, zone):
    code = "D01" if grain == "contact" else "D02"
    period = (scope["start"], scope["end"])
    pairs = []
    for measure, label, unit, fallback in PEERS:
        if measure == metric_id:
            continue
        if measure in ("aht", "handled"):
            rows = primary
        elif measure == "surveys":
            rows = []
        else:
            rows = metric_view.score_rows(primary, measure, grain)
        pair = {"id": measure, "label": label, "unit": unit, "outcome_source": code,
                "outcome_file": filename, "source": code if rows else None,
                "file": filename if rows else None, "matched": False}
        compared = outcome
        if not rows and fallback in optionals:
            upload = optionals[fallback]
            compared, rows = _sample_pairs(upload, fallback, outcome, scope, zone, measure)
            pair.update(source=fallback, file=upload["summary"]["file"], matched=True)
        pairs.append(_describe(pair, compared, rows, period, measure in ("handled", "surveys")))
    return _rank_by_strength(pairs)
