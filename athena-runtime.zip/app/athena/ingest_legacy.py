"""Inspect an uploaded CSV: safety gate, grain detection, row validation, fault dispositions, aggregates.

Faults are classified by config/exclusion_policy.json. A fault whose disposition is "hard_reject" blocks
the whole file. A fault whose disposition is "exclude_with_ledger" drops only its rows, records them in an
exclusion ledger and marks the result as limited. Every fault blocks until EJ admits otherwise.

Cell values are data: never evaluated, and never echoed on screen. Row numbers and keys go to the screen;
the values go only into the remediation manifest the user downloads of their own file.
"""
import csv, hashlib, io, json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from athena.upload_checks import REQUIRED, check_upload

ROOT = Path(__file__).resolve().parent.parent
NUM = {"contact": ["handling_seconds", "talk_seconds", "hold_seconds", "after_call_work_seconds"],
       "agent_day": ["handled_contacts", "total_handling_seconds"]}
SCHEMA = {"contact": "contact_record.schema.json", "agent_day": "agent_day_record.schema.json"}
DUR = {"contact": "handling_seconds", "agent_day": "total_handling_seconds"}
SAFETY_TEXT = {
    "FILE-TYPE": ("Only CSV files can be used.", "Athena cannot read other formats safely.", "Upload a CSV from the template."),
    "FILE-TOO-LARGE": ("The file is larger than the supported size.", "Athena cannot process it in one run.", "Split the export into smaller periods."),
    "FILE-NOT-TEXT": ("The file is not a text CSV.", "Athena cannot read it safely.", "Re-export as CSV and upload again."),
    "FILE-ENCODING": ("The file is not UTF-8 text.", "Characters could be read incorrectly.", "Re-export as UTF-8 CSV."),
    "LINE-TOO-LONG": ("A line in the file is too long.", "Athena cannot read it safely.", "Re-export from the template."),
    "TOO-MANY-ROWS": ("The file has more rows than can be processed.", "Athena cannot process it in one run.", "Split the export into smaller periods."),
}


def policy(path=None):
    return json.loads((Path(path) if path else ROOT / "config/exclusion_policy.json").read_text(encoding="utf-8"))


def _num(s):
    s = (s or "").strip()
    if s == "": return None
    try: return int(s)
    except ValueError:
        try: return float(s)
        except ValueError: return s


def _detect(header):
    c, a = "contact_id" in header, "handled_contacts" in header
    return "contact" if c and not a else "agent_day" if a and not c else None


def _issue(code, pol, rows=None, extra=None):
    f = pol["faults"][code]
    i = {"code": code, "problem": f["problem"], "why": f["why"], "remedy": f["remedy"], "disposition": f["disposition"]}
    if rows: i["rows"] = sorted(rows)[:10]; i["row_count"] = len(rows)
    if extra: i.update(extra)
    return i


def inspect(name, data, limits, validator, pol=None):
    pol = pol or policy()
    out = {"ok": False, "upload_id": hashlib.sha256(data).hexdigest()[:16], "grain": None, "issues": [],
           "summary": None, "aggregates": None, "exclusions": None, "faults": {}}
    probe = "contact" if b"contact_id" in data[:2000] else "agent_day"
    unsafe = [i for i in check_upload(name, data, probe, limits) if i["reason_code"] != "MISSING-COLUMN"]
    if unsafe:
        c = unsafe[0]["reason_code"]; p, w, r = SAFETY_TEXT[c]
        out["issues"] = [{"code": c, "problem": p, "why": w, "remedy": r, "disposition": "hard_reject"}]
        return out
    rd = csv.reader(io.StringIO(data.decode("utf-8-sig"), newline=""))
    header = next(rd, []); grain = _detect(header)
    if grain is None:
        out["issues"] = [{"code": "UNKNOWN-LAYOUT", "problem": "The columns do not match either template.",
                          "why": "Athena needs the template columns to know what each value means.",
                          "remedy": "Start from one of the templates and upload again.", "disposition": "hard_reject"}]
        return out
    out["grain"] = grain
    missing = [c for c in REQUIRED[grain] if c not in header]
    if missing:
        out["issues"] = [{"code": "MISSING-COLUMN", "problem": "Required columns are missing: " + ", ".join(missing) + ".",
                          "why": "Without them Athena cannot calculate handle time.",
                          "remedy": "Add the columns from the template and upload again.", "disposition": "hard_reject"}]
        return out
    idx = {h: i for i, h in enumerate(header)}
    faults = defaultdict(dict)          # code -> {row: {key, detail}}
    rows, seen = [], {}
    for n, raw in enumerate(rd, start=2):
        rec = {}
        for h, i in idx.items():
            v = raw[i] if i < len(raw) else ""
            if h in NUM[grain]:
                x = _num(v)
                if x is not None: rec[h] = x
            elif v != "" or h in REQUIRED[grain]:
                rec[h] = v
        rid = rec.get("contact_id") or rec.get("agent_id") or ""
        dur_raw = (raw[idx[DUR[grain]]] if idx[DUR[grain]] < len(raw) else "").strip()
        core = {k: v for k, v in rec.items() if k in set(REQUIRED[grain]) | set(NUM[grain])}
        errs = validator.errors(core, SCHEMA[grain])
        if errs:
            bad = {p.split(".")[-1].split("[")[0] for p, _ in errs}
            cnt = rec.get("handled_contacts")
            if grain == "agent_day" and cnt == 0 and isinstance(_num(dur_raw), (int, float)) and _num(dur_raw) > 0:
                faults["ZERO-CONTACT-POSITIVE-DURATION"][n] = {"key": rid, "detail": f"{DUR[grain]}={dur_raw}, handled_contacts=0"}
            elif "agent_id" in bad:
                faults["MISSING-AGENT"][n] = {"key": rid, "detail": "agent_id is empty"}
            elif dur_raw == "" and DUR[grain] in bad:
                faults["BLANK-DURATION"][n] = {"key": rid, "detail": f"{DUR[grain]} is empty"}
            elif bad & {DUR[grain], "handled_contacts"}:
                faults["INVALID-DURATION"][n] = {"key": rid, "detail": ", ".join(f"{b}={rec.get(b, '')}" for b in sorted(bad & {DUR[grain], 'handled_contacts'}))}
            else:
                faults["INVALID-ROW"][n] = {"key": rid, "detail": ", ".join(f"{b}={rec.get(b, '')}" for b in sorted(bad))}
            continue
        key = rec["contact_id"] if grain == "contact" else (rec["account_id"], rec["line_of_business_id"], rec["agent_id"], rec["work_date"], rec["contact_type"])
        if key in seen:
            prev_n, prev = seen[key]
            code = "IDENTICAL-DUPLICATE" if prev == rec else "CONFLICTING-DUPLICATE"
            faults[code][n] = {"key": rid, "detail": f"same key as row {prev_n}"}
            continue
        seen[key] = (n, rec); rows.append(rec)

    accounts = sorted({r["account_id"] for r in rows})
    if len(accounts) > 1:
        faults["MULTIPLE-ACCOUNTS"][0] = {"key": ", ".join(accounts), "detail": "more than one account in one file"}
    out["faults"] = {c: len(v) for c, v in faults.items()}
    blocking = [c for c in faults if pol["faults"][c]["disposition"] == "hard_reject"]
    excluded = {c: v for c, v in faults.items() if c not in blocking}
    out["issues"] = [_issue(c, pol, list(faults[c])) for c in sorted(blocking)]
    if blocking:
        out["manifest_rows"] = sorted(((n, c, d["key"], d["detail"]) for c, v in faults.items() for n, d in v.items()))
        return out

    count = len(rows) if grain == "contact" else sum(r["handled_contacts"] for r in rows)
    if not count:
        out["issues"] = [{"code": "NO-HANDLED-CONTACTS", "problem": "There are no handled contacts in the file.",
                          "why": "Average handle time cannot be calculated without contacts.",
                          "remedy": "Upload a file that includes handled contacts.", "disposition": "hard_reject"}]
        return out
    day = (lambda r: datetime.fromisoformat(r["occurred_at"].replace("Z", "+00:00")).astimezone(timezone.utc).date().isoformat()) if grain == "contact" else (lambda r: r["work_date"])
    dates = sorted({day(r) for r in rows})
    n_excluded = sum(len(v) for v in excluded.values())
    out["summary"] = {"file": name, "grain": grain, "rows": len(rows) + n_excluded, "accounts": accounts,
                      "agents": len({r["agent_id"] for r in rows}), "date_min": dates[0], "date_max": dates[-1], "unit": "seconds",
                      "distinct": {"line_of_business_id": sorted({r["line_of_business_id"] for r in rows}), "contact_type": sorted({r["contact_type"] for r in rows})},
                      "longest_contact_seconds": max(r["handling_seconds"] for r in rows) if grain == "contact" else None,
                      "fingerprint": hashlib.sha256(data).hexdigest()[:12]}
    out["exclusions"] = {"policy_version": pol["policy_version"], "excluded_row_count": n_excluded,
                         "entries": [_issue(c, pol, list(v)) for c, v in sorted(excluded.items())]} if n_excluded else None
    agg = defaultdict(lambda: [0, 0])
    for r in rows:
        k = (r["line_of_business_id"], r["contact_type"], day(r), r["agent_id"]); c = agg[k]
        c[0] += 1 if grain == "contact" else r["handled_contacts"]
        c[1] += r["handling_seconds"] if grain == "contact" else r["total_handling_seconds"]
    out["aggregates"] = [{"line_of_business_id": q, "contact_type": t, "date": d, "agent_id": a, "count": c, "total": s}
                         for (q, t, d, a), (c, s) in sorted(agg.items())]
    out["manifest_rows"] = sorted(((n, c, d["key"], d["detail"]) for c, v in faults.items() for n, d in v.items()))
    out["ok"] = True
    return out


def manifest_csv(res):
    """The user's own failing rows, for forwarding to whoever owns the source extract."""
    buf = io.StringIO(newline="")
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(["csv_row", "fault", "record_key", "reported_values", "what_to_do"])
    pol = policy()
    for n, code, key, detail in res.get("manifest_rows", []):
        w.writerow([n, code, key, detail, pol["faults"][code]["remedy"]])
    return buf.getvalue().encode("utf-8")
