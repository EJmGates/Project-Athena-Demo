"""Quartile and decile cohorts of agents (docs48, "Quartiles and comparison rules"; deciles added by EJ, 6 Nov 2026).

Agent values are pooled by the metric's own rule (numerator total over observation total). Quartile 1 is always the best for the
chosen direction and quartile 4 the worst (EJ, 6 Nov 2026): lower is better, higher is better, or distance from the band for
within-bounds. Cut points are the 25th, 50th and 75th percentiles on that best-first scale (linear interpolation), reported in the
metric's own units, so for higher-is-better the first cut is the value at the 75th percentile of the raw values. A value exactly on a
cut goes to the better quartile. Tied values always stay together. Monitor-only has no cohorts. Agents with fewer than the floor of observations are listed with their count and result
but are not ranked and do not move the cut points. Outliers (Tukey fences) are flagged as relative to the cohort, never as invalid.
Nothing here names an agent outward: callers send cohort summaries only, and a one-agent cohort is marked as held back.
Nothing here reaches a page or admits a method.
"""
import math

AGENT_FLOOR = 30          # an agent needs at least this many observations to be ranked (EJ, 6 Nov 2026: one minimum for every group)
MIN_RANKED = 4            # agents needed for quartiles
MIN_RANKED_DECILES = 20   # agents needed for deciles (EJ, 6 Nov 2026: fewer than 20 agents means no decile ranking)
GROUPS = (4, 10)          # quartiles or deciles
MILD, EXTREME = 1.5, 3.0


def percentile(sorted_values, p):
    """Linear interpolation between closest ranks (the usual default)."""
    n = len(sorted_values)
    pos = (n - 1) * p
    lo = math.floor(pos)
    hi = min(lo + 1, n - 1)
    return sorted_values[lo] + (sorted_values[hi] - sorted_values[lo]) * (pos - lo)


def _number(v, what):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
        raise ValueError(f"{what} must be a finite number of zero or more")
    return float(v)


def _score(value, direction, lower, upper):
    """The value on the scale where a smaller number is better, for within-bounds only; others use the raw value."""
    if direction == "within_bounds":
        return max(lower - value, value - upper, 0.0)
    return value


def build(agents, direction, lower=None, upper=None, floor=AGENT_FLOOR, groups=4):
    """agents: {agent: (numerator, observations)}. groups is 4 (quartiles) or 10 (deciles); position 1 is always the best.
    Returns {"ok": True, ...} or {"ok": False, "blocked": [...]}."""
    if groups not in GROUPS:
        raise ValueError("groups must be 4 or 10")
    min_ranked = MIN_RANKED if groups == 4 else MIN_RANKED_DECILES
    if direction == "monitor_only":
        return {"ok": False, "blocked": [{"code": "NO-COHORTS", "reason": "A monitor-only metric has no better or worse, so no cohorts."}]}
    if direction not in ("lower_is_better", "higher_is_better", "within_bounds"):
        raise ValueError("unknown direction: %r" % (direction,))
    if direction == "within_bounds":
        if lower is None or upper is None or lower > upper:
            raise ValueError("within_bounds needs a lower and an upper limit, lower not above upper")
    rows = {}
    for agent, (num, obs) in dict(agents).items():
        num, obs = _number(num, "numerator"), _number(obs, "observations")
        if obs > 0:
            rows[agent] = (num, obs, num / obs)
    ranked = {a: r for a, r in rows.items() if r[1] >= floor}
    unranked = [{"agent": a, "observations": r[1], "value": r[2]} for a, r in sorted(rows.items(), key=lambda kv: str(kv[0])) if r[1] < floor]
    if len(ranked) < min_ranked:
        return {"ok": False, "unranked": unranked, "blocked": [{"code": "TOO-FEW-AGENTS",
                "reason": f"At least {min_ranked} agents with {floor} or more observations are needed; {len(ranked)} qualify."}]}
    sign = -1.0 if direction == "higher_is_better" else 1.0      # on this scale a smaller number is always better
    scores = {a: sign * _score(r[2], direction, lower, upper) for a, r in ranked.items()}
    ordered = sorted(scores.values())
    cuts_best_first = [percentile(ordered, k / groups) for k in range(1, groups)]
    c1, c3 = percentile(ordered, 0.25), percentile(ordered, 0.75)
    iqr = c3 - c1
    fences = {"mild": (c1 - MILD * iqr, c3 + MILD * iqr), "extreme": (c1 - EXTREME * iqr, c3 + EXTREME * iqr)}

    def bucket(s):                                        # ties together, a value on a cut goes to the better group
        for i, cut in enumerate(cuts_best_first):
            if s <= cut:
                return i
        return groups - 1
    members_by = {i: [] for i in range(groups)}
    for a, s in scores.items():
        members_by[bucket(s)].append(a)
    cohorts = []
    for pos in range(groups):                             # pos 0 holds the best scores
        members = sorted(members_by[pos], key=str)
        num, obs = sum(ranked[a][0] for a in members), sum(ranked[a][1] for a in members)
        cohorts.append({"position": pos + 1, "agents": members, "n_agents": len(members), "numerator": num, "observations": obs,
                        "value": num / obs if obs else None, "held_back": len(members) == 1})
    for rank, c in enumerate(cohorts, 1):
        c["rank"] = rank
        c["label"] = ({1: "best", 2: "better", 3: "worse", 4: "worst"}[rank] if groups == 4 else "best" if rank == 1 else "worst" if rank == groups else f"decile {rank}")
    outliers = []
    for a, s in sorted(scores.items(), key=lambda kv: str(kv[0])):
        for kind in ("extreme", "mild"):
            lo, hi = fences[kind]
            if s < lo or s > hi:
                low = (s < lo) == (sign > 0)              # low in the metric's own units
                outliers.append({"agent": a, "value": ranked[a][2], "kind": kind, "side": "low" if low else "high"})
                break
    cuts = [sign * c for c in cuts_best_first]
    out_fences = {k: tuple(sorted(sign * f for f in v)) for k, v in fences.items()}
    return {"ok": True, "direction": direction, "kind": "quartile" if groups == 4 else "decile", "groups": groups, "cut_points": cuts, "fences": out_fences,
            "cohorts": sorted(cohorts, key=lambda c: c["rank"]), "unranked": unranked, "outliers": outliers, "n_ranked": len(ranked)}


def unranked_note(result, floor=AGENT_FLOOR):
    """Plain-language disclaimer for the population analyses that keep every agent as recorded (EJ, 5 Nov 2026).
    Agents under the floor are left out of cohort assignment only; they stay in totals and other population figures."""
    n = len(result.get("unranked", []))
    if not n:
        return None
    who = "1 agent has" if n == 1 else f"{n} agents have"
    return (f"{who} fewer than {floor} observations. {'This agent is' if n == 1 else 'These agents are'} not placed in a cohort, "
            "and are included as recorded in totals and other population figures.")


def llm_view(result):
    """What may leave Athena: cohort pooled figures only. No agent names, no unranked rows, no one-agent cohorts."""
    if not result.get("ok"):
        raise ValueError("no cohorts to describe")
    return [{"cohort": c["label"], "agents": c["n_agents"], "observations": c["observations"], "value": c["value"]}
            for c in result["cohorts"] if not c["held_back"] and c["observations"]]
