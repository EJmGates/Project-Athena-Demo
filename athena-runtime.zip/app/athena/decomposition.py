"""Mix versus rate decomposition of a change in a pooled ratio such as AHT (method proposal M035, docs/05).

Symmetric (Kitagawa) form, so the two effects add exactly to the total change:
    rate effect = sum( (w_E + w_B) / 2 * (mu_E - mu_B) )     how the metric changed inside each group
    mix effect  = sum( (mu_E + mu_B) / 2 * (w_E - w_B) )     how the share of work moved between groups
w is a group's share of the denominator (handled contacts), mu its numerator over denominator (seconds per contact).
This is arithmetic on totals, not a test: no chance claim, no cause, no attribution to a person. Nothing here admits a method
(see config/capabilities.json). Groups missing or empty in either period block the result (naming the groups) rather than guess.
"""
import math

DOMINANCE = 0.5          # an effect leads when it carries more than half of the combined size of the two effects


def _clean(period, name):
    out = {}
    for group, pair in dict(period).items():
        num, den = pair
        for v in (num, den):
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
                raise ValueError(f"{name}: totals must be finite numbers of zero or more (group {group!r})")
        out[group] = (float(num), float(den))
    return out


def check_periods(baseline, evaluated):
    """Each period is (start, end), start inclusive, end exclusive. Returns a list of problems; empty means usable."""
    problems = []
    for label, (start, end) in (("baseline", baseline), ("evaluated", evaluated)):
        if not start < end:
            problems.append(f"The {label} period must end after it starts.")
    if not problems and baseline[0] < evaluated[1] and evaluated[0] < baseline[1]:
        problems.append("The baseline and evaluated periods overlap.")
    return problems


def decompose(baseline, evaluated):
    """baseline and evaluated map group -> (numerator total, denominator total) for one period each.
    Returns {"ok": True, ...} with both effects and per-group contributions, or {"ok": False, "blocked": [...]}."""
    b, e = _clean(baseline, "baseline"), _clean(evaluated, "evaluated")
    blocked = []
    if not b or not e:
        blocked.append({"code": "NO-GROUPS", "reason": "Both periods need at least one group with contacts."})
    only_one = sorted(set(b) ^ set(e), key=str)
    if only_one:
        blocked.append({"code": "GROUP-IN-ONE-PERIOD", "groups": only_one,
                        "reason": "These groups appear in only one of the periods, so the change cannot be split without guessing: " + ", ".join(map(str, only_one)) + "."})
    empty = sorted({g for p in (b, e) for g, (_, d) in p.items() if d == 0}, key=str)
    if empty:
        blocked.append({"code": "EMPTY-GROUP", "groups": empty,
                        "reason": "These groups have no contacts in a period: " + ", ".join(map(str, empty)) + "."})
    if blocked:
        return {"ok": False, "blocked": blocked}
    tb, te = sum(d for _, d in b.values()), sum(d for _, d in e.values())
    value_b, value_e = sum(n for n, _ in b.values()) / tb, sum(n for n, _ in e.values()) / te
    groups, rate_total, mix_total = [], 0.0, 0.0
    for g in sorted(b, key=str):
        wb, we = b[g][1] / tb, e[g][1] / te
        mb, me = b[g][0] / b[g][1], e[g][0] / e[g][1]
        rate, mix = (wb + we) / 2 * (me - mb), (mb + me) / 2 * (we - wb)
        rate_total += rate
        mix_total += mix
        groups.append({"group": g, "share_baseline": wb, "share_evaluated": we, "value_baseline": mb, "value_evaluated": me,
                       "rate_effect": rate, "mix_effect": mix, "total_effect": rate + mix})
    level = (value_b + value_e) / 2                    # a group's mix share is judged against the average level, so the shifts add to the mix effect
    for g in groups:
        g["mix_effect_centered"] = ((g["value_baseline"] + g["value_evaluated"]) / 2 - level) * (g["share_evaluated"] - g["share_baseline"])
    size = abs(rate_total) + abs(mix_total)
    if size == 0:
        dominant = "none"
    elif abs(mix_total) / size > DOMINANCE:
        dominant = "mix"
    elif abs(rate_total) / size > DOMINANCE:
        dominant = "rate"
    else:
        dominant = "both"
    return {"ok": True, "value_baseline": value_b, "value_evaluated": value_e, "change": value_e - value_b,
            "rate_effect": rate_total, "mix_effect": mix_total, "dominant": dominant,
            "groups": groups, "n_groups": len(groups), "contacts": {"baseline": tb, "evaluated": te}}


def top_groups(result, effect="mix_effect", n=3):
    """The groups that moved the chosen effect most, by absolute size, largest first."""
    if not result.get("ok"):
        raise ValueError("no result to rank")
    return sorted(result["groups"], key=lambda g: (-abs(g[effect]), str(g["group"])))[:n]


def adverse_groups(result, effect="rate_effect", direction="lower_is_better", lower=None, upper=None, n=3):
    """Groups whose contribution moved the metric the wrong way for its direction, worst first (docs55).
    Lower is better: a positive contribution is adverse. Higher is better: a negative one. Within bounds: adverse means further from the
    band, judged by which side the evaluated figure sits on; an evaluated figure inside the band has no adverse groups.
    A mix contribution is each group's share change times how far its level sits from the average level, so the groups add to the mix effect.
    Monitor-only has no better or worse and is refused. Groups whose contribution helped or is zero are never returned."""
    if not result.get("ok"):
        raise ValueError("no result to rank")
    if effect not in ("rate_effect", "mix_effect", "total_effect"):
        raise ValueError("unknown effect: %r" % (effect,))
    if direction == "lower_is_better":
        sign = 1.0
    elif direction == "higher_is_better":
        sign = -1.0
    elif direction == "within_bounds":
        if lower is None or upper is None or lower > upper:
            raise ValueError("within_bounds needs a lower and an upper limit, lower not above upper")
        v = result["value_evaluated"]
        if v > upper:
            sign = 1.0
        elif v < lower:
            sign = -1.0
        else:
            return []
    else:
        raise ValueError("no adverse ranking for direction: %r" % (direction,))
    key = "mix_effect_centered" if effect == "mix_effect" else effect      # raw mix shares are not centred, so a gain of a good group looks bad
    adverse = [dict(g, adverse_size=sign * g[key]) for g in result["groups"] if sign * g[key] > 0]
    return sorted(adverse, key=lambda g: (-g["adverse_size"], str(g["group"])))[:n]
