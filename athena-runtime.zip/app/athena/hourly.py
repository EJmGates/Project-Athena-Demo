"""Descriptive account-local hourly cells on the report's eligible primary contacts."""
import math
from collections import defaultdict
from datetime import date, timedelta

from athena import metric_view, metrics


def _minute(value):
    hour, minute = map(int, value.split(":"))
    return hour * 60 + minute


def _in_shift(weekday, minute, shift):
    days, start, end, overnight = shift
    if overnight:
        return (weekday in days and minute >= start) or ((weekday - 1) % 7 in days and minute < end)
    return weekday in days and start <= minute < end


def build(contact_data, metric, scoring, score_format, scope, zone, roster, shifts, selection=None):
    if not contact_data:
        return None
    if selection is None:
        selection = {"start": scope["start"], "end": scope["end"]}
    if not isinstance(selection, dict):
        raise ValueError("Choose a valid heatmap scope.")
    start, end = selection.get("start"), selection.get("end")
    try:
        first, last = date.fromisoformat(start), date.fromisoformat(end)
    except (ValueError, TypeError):
        raise ValueError("Choose a start date within the report.") from None
    if first.isoformat() != start or last.isoformat() != end or not scope["start"] <= start <= end <= scope["end"]:
        raise ValueError("Choose ordered dates within the report.")
    # Show one calendar week of columns at a time. Keep the actual observed date on overnight work.
    last = first + timedelta(days=min(6, (last - first).days))
    days = [(first + timedelta(days=i)).isoformat() for i in range((last - first).days + 1)]
    weekdays = {day: date.fromisoformat(day).weekday() for day in days}
    line, driver, lead, shift = (selection.get(key, "") for key in ("line", "driver", "lead", "shift"))
    if not all(isinstance(value, str) for value in (line, driver, lead, shift)):
        raise ValueError("Choose filters from the report.")
    lines = set(scope["lines_of_business"])
    drivers = None if scope.get("contact_types") is None else set(scope["contact_types"])
    if (line and line not in lines) or (driver and drivers is not None and driver not in drivers):
        raise ValueError("Choose a work group within the report scope.")
    shifts = {item["name"]: (set(item["days"]), _minute(item["start"]), _minute(item["end"]), item["ends_next_day"])
              for item in shifts}
    if shift and shift not in shifts:
        raise ValueError("Choose a configured shift window.")

    registry = metrics.get(metric).get("columns", {}).get("contact", {})
    percent = (scoring or {}).get("scoring_type") == "percent"
    column = registry.get("pass_flag" if percent and score_format != "fraction" else "score")
    columns = contact_data["columns"]
    index = columns.index(column) if column in columns else None
    roster = roster or {}
    leads = set()
    cells = defaultdict(lambda: [0, 0.0])
    maximum = None
    for day, minute, row_line, row_driver, agent, seconds, scores in contact_data["rows"]:
        value = seconds if metric == "aht" else scores[index] if index is not None else None
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            continue
        if percent and score_format != "fraction" and value not in (0, 1):
            continue
        maximum = value if maximum is None else max(maximum, value)
        if not scope["start"] <= day <= scope["end"] or row_line not in lines or (drivers is not None and row_driver not in drivers):
            continue
        team_lead = roster.get(agent, {}).get("team_lead")
        if team_lead:
            leads.add(team_lead)
        if (day not in weekdays or (line and line != row_line) or (driver and driver != row_driver)
                or (lead and lead != team_lead) or (shift and not _in_shift(weekdays[day], minute, shifts[shift]))):
            continue
        cell = cells[day, minute // 60]
        cell[0] += 1
        cell[1] += value
    if lead and lead not in leads:
        raise ValueError("Choose a team lead within the report scope.")

    aggregates, unavailable = [], []
    for (day, hour), (count, total) in sorted(cells.items()):
        if math.isfinite(total):
            aggregates.append({"date": day, "hour": hour, "count": count, "total": total,
                               "measures": {column: {"weight": count, "weighted_sum": total}} if column else {}})
        else:
            unavailable.append({"date": day, "hour": hour, "count": count, "value": None})
    scored, _ = metric_view.rows(aggregates, metric, scoring, "contact", score_format=score_format)
    displayed = [{"date": row["date"], "hour": row["hour"], "count": row["count"],
                  "value": row["total"] / row["count"] if math.isfinite(row["total"]) else None}
                 for row in scored or () if row["count"]]
    if maximum is not None and percent:
        maximum *= 100
    return {"days": days, "zone": zone, "leads": sorted(leads), "shifts": list(shifts),
            "selection": {"start": start, "end": end, "line": line, "driver": driver, "lead": lead, "shift": shift},
            "maximum": maximum if maximum is None or math.isfinite(maximum) else None,
            "cells": sorted(displayed + unavailable, key=lambda cell: (cell["date"], cell["hour"]))}
