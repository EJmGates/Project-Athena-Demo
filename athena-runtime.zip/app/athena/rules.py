"""One registry of finding types (config/data_rules.json) and one findings builder shared by both intakes.

A finding is {code, label, layer, rows_affected}. A row can appear under more than one type, so counts may overlap.
Types with no affected rows are never listed. Counts only: no cell values, so the result is safe to send to the page.
"""
import json
from pathlib import Path

REGISTRY = json.loads((Path(__file__).resolve().parent.parent / "config/data_rules.json").read_text(encoding="utf-8"))
RULES = REGISTRY["rules"]
LAYERS = REGISTRY["layers"]


def findings(row_counts):
    """row_counts: {code: number of rows affected}. Unknown codes are kept under a neutral label so nothing is hidden."""
    out = []
    for code, n in row_counts.items():
        if not n:
            continue
        rule = RULES.get(code)
        out.append({"code": code, "label": rule["label"] if rule else "Other issue", "layer": rule["layer"] if rule else "row", "rows_affected": int(n)})
    return sorted(out, key=lambda f: (LAYERS.index(f["layer"]), -f["rows_affected"], f["code"]))
