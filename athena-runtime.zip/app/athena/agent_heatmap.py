"""Observed KPI and component averages by agent or governed group."""
import math
from collections import defaultdict

from athena import metric_view, metrics

GROUPS = {"agent": "Agent", "line": "Line of Business", "team_lead": "Team lead", "manager_name": "Manager"}


def build(metric, grain, primary, selected, unit, formats, component_population, roster):
    source = "D01" if grain == "contact" else "D02"
    columns = [{"id": metric, "label": metrics.get(metric)["label"], "unit": unit, "source": source, "kind": "selected"}]
    tables = {key: defaultdict(dict) for key in GROUPS}
    totals = defaultdict(int)
    roster = roster or {}

    def add(key, agent, line, count, total):
        if not count:
            return
        totals[key] += count
        profile = roster.get(agent, {})
        groups = {"agent": agent, "line": line, "team_lead": profile.get("team_lead"), "manager_name": profile.get("manager_name")}
        for dimension, name in groups.items():
            if name:
                cell = tables[dimension][name].setdefault(key, [0, 0.0])
                cell[0] += count
                cell[1] += total

    for row in selected:
        add(metric, row.get("agent_id"), row.get("line_of_business_id"), row["count"], row["total"])

    for peer, rows in metric_view.primary_peers(primary, metric, grain, formats):
        columns.append({**peer, "source": source, "kind": "peer"})
        for row in rows:
            add(peer["id"], row.get("agent_id"), row.get("line_of_business_id"), row["count"], row["total"])

    parts, part_source, observations = component_population
    part_unit = {"D01": "seconds", "D03": "rating", "D04": "points"}.get(part_source)
    parts = {"component:" + key: label for key, label in parts.items()}
    for _, agent, line, count, values in observations:
        if values is not None:
            for key, total in zip(parts, values[1:], strict=True):
                add(key, agent, line, count, total)
    columns.extend({"id": key, "label": label, "unit": part_unit, "source": part_source, "kind": "component"}
                   for key, label in parts.items() if totals[key])

    groupings = []
    for dimension, table in tables.items():
        if not table:
            continue
        coverage = defaultdict(int)
        rows = []
        for group, values in sorted(table.items()):
            cells = {}
            for key, (count, total) in values.items():
                coverage[key] += count
                cells[key] = {"count": count, "value": total / count if math.isfinite(total) else None}
            rows.append({"group": group, "cells": cells})
        groupings.append({"id": dimension, "label": GROUPS[dimension], "rows": rows, "coverage": dict(coverage)})
    return {"columns": columns, "groupings": groupings, "totals": dict(totals)}
