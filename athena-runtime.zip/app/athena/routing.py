"""Assumption-based routing of comparisons into families (docs48, "COPC decision tree and Hermes review", item 5).

Families: parametric (Welch family), rank_based, exact_count; dependence_aware when observations are not independent.
Nothing here runs a comparison or admits a method (see config/capabilities.json). It only decides which family applies
and says why in plain words. The route is never an operator setting. Valid extremes are never removed: inputs are only read.

Rules, from docs48:
- Welch is always the parametric choice (no equal-variance branch).
- Normality is judged on the values the test relies on: each group's values, the paired differences, or the regression
  residuals for a correlation. Never on proportions.
- Shapiro-Wilk is used only for about 8 to 200 values per sample. Below 8 the route is rank-based without a normality test.
  Above 200 the shape (skewness and excess kurtosis) decides, and Welch is kept unless the shape is extreme.
- Time-ordered data is checked for lag-one autocorrelation first.
- For proportions, 5 successes and 5 failures in every group pick between the usual test and the exact test; it never disqualifies.

Provisional choices not fixed by docs48, kept here in one place for review: alpha 0.05 for the Shapiro-Wilk screen, shape limits
|skewness| 2 and |excess kurtosis| 7 (after Kim, 2013), and a lag-one limit of 1.96 / sqrt(n) for samples of 10 or more.
"""
import math
from functools import lru_cache
from statistics import NormalDist, fmean

_ND = NormalDist()
ALPHA = 0.05
SHAPIRO_MIN, SHAPIRO_MAX = 8, 200
SHAPE_SKEW_LIMIT, SHAPE_KURTOSIS_LIMIT = 2.0, 7.0
LAG_MIN_N, LAG_Z = 10, 1.96
EXACT_MIN = 5


def _poly(coefficients, x):
    result = 0.0
    for c in reversed(coefficients):
        result = result * x + c
    return result


@lru_cache(maxsize=None)
def _coefficients(n):
    """Royston (1995, AS R94) coefficients a_1..a_(n//2), applied to (x_(n+1-i) - x_(i))."""
    half = n // 2
    m = [_ND.inv_cdf((i - 0.375) / (n + 0.25)) for i in range(1, half + 1)]       # lower half, negative
    total = 2 * sum(v * v for v in m)
    root_total = math.sqrt(total)
    u = 1 / math.sqrt(n)
    a1 = _poly((0, 0.221157, -0.147981, -2.071190, 4.434685, -2.706056), u) - m[0] / root_total
    a = [a1]
    if n > 5:
        a2 = _poly((0, 0.042981, -0.293762, -1.752461, 5.682633, -3.582633), u) - m[1] / root_total
        factor = math.sqrt((total - 2 * m[0] ** 2 - 2 * m[1] ** 2) / (1 - 2 * a1 ** 2 - 2 * a2 ** 2))
        a.append(a2)
        start = 2
    else:
        factor = math.sqrt((total - 2 * m[0] ** 2) / (1 - 2 * a1 ** 2))
        start = 1
    a += [-m[i] / factor for i in range(start, half)]
    return tuple(a)


def _finite(values):
    values = list(values)
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in values):
        raise ValueError("values must be finite numbers")
    return [float(v) for v in values]


def shapiro_wilk(values):
    """(W, p) for 4 to 5000 values, or None when the values have no spread. Raises ValueError otherwise."""
    x = sorted(_finite(values))
    n = len(x)
    if not 4 <= n <= 5000:
        raise ValueError("Shapiro-Wilk needs 4 to 5000 values")
    mean = fmean(x)
    ssd = sum((v - mean) ** 2 for v in x)
    if ssd <= 0 or (x[-1] - x[0]) <= 0:
        return None
    a = _coefficients(n)
    b = sum(a[i] * (x[n - 1 - i] - x[i]) for i in range(n // 2))
    w = min(b * b / ssd, 1.0)
    if w >= 1.0:
        return 1.0, 1.0
    y = math.log(1 - w)
    if n <= 11:
        gamma = -2.273 + 0.459 * n
        if y >= gamma:
            return w, 1e-99
        z = -math.log(gamma - y)
        mu = _poly((0.5440, -0.39978, 0.025054, -6.714e-4), n)
        sigma = math.exp(_poly((1.3822, -0.77857, 0.062767, -0.0020322), n))
    else:
        z = y
        ln = math.log(n)
        mu = _poly((-1.5861, -0.31082, -0.083751, 0.0038915), ln)
        sigma = math.exp(_poly((-0.4803, -0.082676, 0.0030302), ln))
    return w, 1 - _ND.cdf((z - mu) / sigma)


def shape(values):
    """(skewness, excess kurtosis) from population moments; None when there is no spread."""
    x = _finite(values)
    n = len(x)
    if n < 3:
        raise ValueError("shape needs at least 3 values")
    mean = fmean(x)
    m2 = sum((v - mean) ** 2 for v in x) / n
    if m2 <= 0:
        return None
    m3 = sum((v - mean) ** 3 for v in x) / n
    m4 = sum((v - mean) ** 4 for v in x) / n
    return m3 / m2 ** 1.5, m4 / m2 ** 2 - 3


def lag1(values):
    """Lag-one autocorrelation of a series in time order; None when there is no spread."""
    x = _finite(values)
    if len(x) < 3:
        raise ValueError("autocorrelation needs at least 3 values")
    mean = fmean(x)
    den = sum((v - mean) ** 2 for v in x)
    if den <= 0:
        return None
    return sum((x[i] - mean) * (x[i + 1] - mean) for i in range(len(x) - 1)) / den


# ---- routing ------------------------------------------------------------------------------------------------------

def _result(family, test, reason, checks):
    return {"family": family, "test": test, "reason": reason, "checks": checks}


def _sizes(samples):
    ns = [len(s) for s in samples]
    return ns[0] if len(ns) == 1 else ", ".join(map(str, ns[:-1])) + " and " + str(ns[-1])


def _dependence(samples, label):
    """Checks that come first for time-ordered data. Returns (checks, dependent sample number or None)."""
    checks, dependent = [], None
    for i, s in enumerate(samples, 1):
        if len(s) < LAG_MIN_N:
            continue
        r, limit = lag1(s), LAG_Z / math.sqrt(len(s))
        if r is None:
            continue
        ok = abs(r) <= limit
        checks.append({"name": "lag1_autocorrelation", "sample": i, "n": len(s), "value": r, "limit": limit, "independent": ok})
        if not ok and dependent is None:
            dependent = i
    return checks, dependent


def _screen(samples):
    """Normality screen of the values the test relies on. Returns (checks, verdict, why) with verdict parametric or rank_based."""
    checks = []
    for i, s in enumerate(samples, 1):                       # size and spread first, so no normality test is run when the answer is already rank-based
        n = len(s)
        if n < SHAPIRO_MIN:
            checks.append({"name": "sample_size", "sample": i, "n": n, "enough_for_normality_check": False})
            return checks, "rank_based", f"One sample has only {n} values, too few to check for a normal shape, so a rank-based comparison is used."
        if min(s) == max(s):
            checks.append({"name": "spread", "sample": i, "n": n, "has_spread": False})
            return checks, "rank_based", "One sample has no spread (every value is the same), so a rank-based comparison is used."
    for i, s in enumerate(samples, 1):
        n = len(s)
        if n <= SHAPIRO_MAX:
            w, p = shapiro_wilk(s)
            ok = p >= ALPHA
            checks.append({"name": "shapiro_wilk", "sample": i, "n": n, "statistic": w, "p": p, "normal": ok})
            if not ok:
                return checks, "rank_based", f"A sample of {n} values departs from a normal shape (Shapiro-Wilk p {p:.3f}), so a rank-based comparison is used."
        else:
            skew, kurt = shape(s)
            ok = abs(skew) <= SHAPE_SKEW_LIMIT and abs(kurt) <= SHAPE_KURTOSIS_LIMIT
            checks.append({"name": "shape", "sample": i, "n": n, "skewness": skew, "excess_kurtosis": kurt, "normal": ok})
            if not ok:
                return checks, "rank_based", f"A sample of {n} values is strongly skewed or heavy-tailed, so a rank-based comparison is used."
    return checks, "parametric", None


def _proportions(cells):
    cells = [(int(s), int(n)) for s, n in cells]
    if len(cells) < 2 or any(n < 1 or s < 0 or s > n for s, n in cells):
        raise ValueError("each group needs 0 <= successes <= total and a total of at least 1")
    smallest = min(min(s, n - s) for s, n in cells)
    small = smallest < EXACT_MIN
    checks = [{"name": "observed_counts", "smallest_count": smallest, "needed": EXACT_MIN, "enough": not small}]
    if small:
        return _result("exact_count", "exact_conditional",
                       f"At least one group has fewer than {EXACT_MIN} successes or {EXACT_MIN} failures, so the exact test is used.", checks)
    return _result("exact_count", "chi_square", f"Every group has at least {EXACT_MIN} successes and {EXACT_MIN} failures, so the usual counts test is used.", checks)


_TESTS = {"two_groups": ("welch_t", "mann_whitney", "Welch's t-test, which does not assume equal spread"),
          "many_groups": ("welch_anova", "kruskal_wallis", "Welch's ANOVA, which does not assume equal spread"),
          "paired": ("paired_t", "wilcoxon_signed_rank", "a paired t-test on the differences"),
          "correlation": ("pearson", "spearman", "Pearson correlation")}


def route(design, data, time_ordered=False):
    """design: two_groups, many_groups, paired, correlation or proportions.
    data: the samples (two_groups, many_groups), the two paired columns, x and y (correlation), or (successes, total) cells (proportions)."""
    if design == "proportions":
        return _proportions(data)
    if design not in _TESTS:
        raise ValueError("unknown design: %r" % (design,))
    samples = [_finite(s) for s in data]
    if design == "two_groups" and len(samples) != 2 or design == "many_groups" and len(samples) < 3 or design in ("paired", "correlation") and len(samples) != 2:
        raise ValueError("wrong number of samples for " + design)
    if any(len(s) < 2 for s in samples):
        raise ValueError("each sample needs at least 2 values")
    if design in ("paired", "correlation") and len(samples[0]) != len(samples[1]):
        raise ValueError("the two columns must have the same length")
    parametric, rank, label = _TESTS[design]
    if design == "paired":
        relied = [[a - b for a, b in zip(*samples)]]
        about = "the paired differences"
    elif design == "correlation":
        x, y = samples
        if min(x) == max(x) or min(y) == max(y):
            return _result("rank_based", rank, "One variable has no spread (every value is the same), so a rank-based association is used.",
                           [{"name": "spread", "has_spread": False}])
        mx, my = fmean(x), fmean(y)
        slope = sum((a - mx) * (b - my) for a, b in zip(x, y)) / sum((a - mx) ** 2 for a in x)
        relied = [[b - (my + slope * (a - mx)) for a, b in zip(x, y)]]
        about = "the residuals around the fitted line"
    else:
        relied, about = samples, "each group"
    checks = []
    if time_ordered:
        checks, dependent = _dependence(relied, about)
        if dependent is not None:
            return _result("dependence_aware", None,
                           "Neighbouring values in time order are related, so the observations are not independent. This comparison needs a method that allows for that.", checks)
    screen, verdict, why = _screen(relied)
    checks += screen
    sizes = _sizes(relied)
    if verdict == "rank_based":
        return _result("rank_based", rank, why, checks)
    if relied[0] and len(relied[0]) > SHAPIRO_MAX:
        how = f"With {sizes} values the shape of {about} is not extreme, so"
    else:
        how = f"{about[0].upper() + about[1:]} ({sizes} values) look close to a normal shape, so"
    return _result("parametric", parametric, f"{how} the comparison uses {label}.", checks)
