"""Two-group comparison tests, pure Python (docs48 item 5). Each takes the family chosen by athena.routing.

Nothing here admits a method (see config/capabilities.json); these are the calculations only. Inputs are never trimmed:
every valid value is used. Two-sided p-values only; 95% intervals where the test has a natural one.
"""
import math
from statistics import NormalDist, fmean, variance

_ND = NormalDist()
CONFIDENCE = 0.95


def _finite(values, minimum=2):
    values = list(values)
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in values):
        raise ValueError("values must be finite numbers")
    if len(values) < minimum:
        raise ValueError(f"each sample needs at least {minimum} values")
    return [float(v) for v in values]


def _betacf(a, b, x):
    """Continued fraction for the incomplete beta function (modified Lentz)."""
    tiny = 1e-300
    qab, qap, qam = a + b, a + 1, a - 1
    c, d = 1.0, 1 - qab * x / qap
    d = 1 / (d if abs(d) > tiny else tiny)
    h = d
    for m in range(1, 500):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1 + aa * d
        d = 1 / (d if abs(d) > tiny else tiny)
        c = 1 + aa / c
        c = c if abs(c) > tiny else tiny
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1 + aa * d
        d = 1 / (d if abs(d) > tiny else tiny)
        c = 1 + aa / c
        c = c if abs(c) > tiny else tiny
        delta = d * c
        h *= delta
        if abs(delta - 1) < 1e-15:
            break
    return h


def _betainc(a, b, x):
    """Regularised incomplete beta function I_x(a, b)."""
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    front = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log1p(-x))
    if x < (a + 1) / (a + b + 2):
        return front * _betacf(a, b, x) / a
    return 1 - front * _betacf(b, a, 1 - x) / b


def t_two_sided_p(t, df):
    return _betainc(df / 2, 0.5, df / (df + t * t))


def t_quantile(p, df):
    """Value t with P(T <= t) = p, by bisection on the exact distribution function."""
    def cdf(t):
        tail = 0.5 * t_two_sided_p(t, df)
        return 1 - tail if t > 0 else tail
    lo, hi = -1e6, 1e6
    for _ in range(200):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if cdf(mid) < p else (lo, mid)
    return (lo + hi) / 2


def welch_t(a, b):
    """Welch t-test (no equal-variance assumption). Returns the mean difference (a minus b), its 95% interval, t, df and p.
    When both samples have no spread the standard error is zero: the result is marked degenerate and t is None."""
    a, b = _finite(a), _finite(b)
    na, nb = len(a), len(b)
    ma, mb = fmean(a), fmean(b)
    va, vb = variance(a) / na, variance(b) / nb
    diff = ma - mb
    out = {"test": "welch_t", "n": [na, nb], "means": [ma, mb], "difference": diff}
    if va + vb == 0:
        return {**out, "statistic": None, "df": None, "p": 1.0 if diff == 0 else 0.0, "ci": [diff, diff], "degenerate": True}
    se = math.sqrt(va + vb)
    df = (va + vb) ** 2 / ((va ** 2 / (na - 1) if va else 0) + (vb ** 2 / (nb - 1) if vb else 0))
    t = diff / se
    q = t_quantile(1 - (1 - CONFIDENCE) / 2, df)
    return {**out, "statistic": t, "df": df, "p": t_two_sided_p(t, df), "ci": [diff - q * se, diff + q * se], "degenerate": False}


def _ranks(values):
    order = sorted(range(len(values)), key=values.__getitem__)
    ranks, ties, i = [0.0] * len(values), [], 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        for k in range(i, j + 1):
            ranks[order[k]] = (i + j) / 2 + 1
        ties.append(j - i + 1)
        i = j + 1
    return ranks, ties


def mann_whitney(a, b):
    """Mann-Whitney U with the normal approximation, tie correction and continuity correction (scipy's asymptotic method).
    Also reports the probability that a value from a exceeds one from b (ties count half)."""
    a, b = _finite(a, 1), _finite(b, 1)
    na, nb = len(a), len(b)
    ranks, ties = _ranks(a + b)
    u1 = sum(ranks[:na]) - na * (na + 1) / 2
    n = na + nb
    mu = na * nb / 2
    tie_term = sum(t ** 3 - t for t in ties) / (n * (n - 1))
    sigma2 = na * nb / 12 * ((n + 1) - tie_term)
    out = {"test": "mann_whitney", "n": [na, nb], "u": u1, "probability_a_exceeds_b": u1 / (na * nb)}
    if sigma2 <= 0:
        return {**out, "p": 1.0, "degenerate": True}
    z = (abs(u1 - mu) - 0.5) / math.sqrt(sigma2)
    return {**out, "z": z, "p": min(1.0, 2 * (1 - _ND.cdf(max(z, 0.0)))), "degenerate": False}


def _counts(cells):
    cells = list(cells)
    if len(cells) != 2:
        raise ValueError("two groups are needed")
    (s1, n1), (s2, n2) = [(int(s), int(n)) for s, n in cells]
    if min(n1, n2) < 1 or not (0 <= s1 <= n1 and 0 <= s2 <= n2):
        raise ValueError("each group needs 0 <= successes <= total and a total of at least 1")
    return s1, n1, s2, n2


def chi_square_2x2(cells):
    """Pearson chi-square for two groups, no continuity correction (df 1). Returns the two rates and their difference."""
    s1, n1, s2, n2 = _counts(cells)
    total, succ = n1 + n2, s1 + s2
    out = {"test": "chi_square", "n": [n1, n2], "rates": [s1 / n1, s2 / n2], "difference": s1 / n1 - s2 / n2}
    if succ in (0, total):
        return {**out, "statistic": None, "p": 1.0, "degenerate": True}
    chi = 0.0
    for s, n in ((s1, n1), (s2, n2)):
        for obs, exp in ((s, n * succ / total), (n - s, n * (total - succ) / total)):
            chi += (obs - exp) ** 2 / exp
    return {**out, "statistic": chi, "df": 1, "p": math.erfc(math.sqrt(chi / 2)), "degenerate": False}


def fisher_exact_2x2(cells):
    """Exact conditional test for two groups: sum of the probabilities of every table no more likely than the one seen."""
    s1, n1, s2, n2 = _counts(cells)
    succ, total = s1 + s2, n1 + n2

    def logp(k):
        return (math.lgamma(n1 + 1) - math.lgamma(k + 1) - math.lgamma(n1 - k + 1)
                + math.lgamma(n2 + 1) - math.lgamma(succ - k + 1) - math.lgamma(n2 - succ + k + 1)
                - (math.lgamma(total + 1) - math.lgamma(succ + 1) - math.lgamma(total - succ + 1)))
    lo, hi = max(0, succ - n2), min(n1, succ)
    seen = logp(s1)
    p = sum(math.exp(logp(k)) for k in range(lo, hi + 1) if logp(k) <= seen + 1e-7)
    return {"test": "exact_conditional", "n": [n1, n2], "rates": [s1 / n1, s2 / n2], "difference": s1 / n1 - s2 / n2, "p": min(1.0, p)}


RUNNERS = {"welch_t": welch_t, "mann_whitney": mann_whitney, "chi_square": chi_square_2x2, "exact_conditional": fisher_exact_2x2}


def run(test, data):
    """Run the test the router named. data is two samples, or two (successes, total) cells for the counts tests."""
    if test not in RUNNERS:
        raise ValueError("test not available: %r" % (test,))
    return RUNNERS[test](*data) if test in ("welch_t", "mann_whitney") else RUNNERS[test](data)
