"""Local-only server for the Athena journey: page, templates, account configuration, upload, plan, result.

Binds to 127.0.0.1. Uploads are held in memory for the life of the process. This is a local proof of
concept host, not an approved hosting route.
"""
import csv, io, json, re, secrets, sys, hashlib, math, time
from datetime import date
from urllib.parse import urlsplit, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from athena import agent_heatmap, cart_profiles, metric_engine, components, constraints, dates, match, dq, dq_contracts, forecast, hourly, ingest, insights, metric_view, metrics, optional_intake, profiles, questionnaire, relationships, run_identity, session_config, stability, targets, tokens
from athena.schema_subset import Validator
from athena.upload_checks import load_limits

ROOT = Path(__file__).resolve().parent.parent
LIMITS = load_limits(ROOT / "config/limits.json")
VALIDATOR = Validator(ROOT / "vendor/handoff/contracts")
TEMPLATES = {"contact_template.csv", "agent_day_template.csv"}
UPLOADS = {}
OPTIONAL_RESOURCES = optional_intake.Resources(UPLOADS)
OPTIONAL_BODY_DEADLINE_SECONDS = 15
UI_SHELL = None           # None uses shell from config/active_ui.json; tests may select a shell explicitly
CONFIG_STORAGE = None      # None uses configuration_storage from config/active_policy.json; tests may select a mode explicitly
POLICY_FILE = None      # None uses the policy named in config/active_policy.json; tests may point it at a specific policy file
ID = re.compile(r"^[0-9a-f]{16}$")
REGISTRY_SHA = hashlib.sha256((ROOT / "vendor/handoff/catalogs/analysis_registry.json").read_bytes()).hexdigest()[:12]


SHELLS = {"sidebar", "classic"}
FULL_DETAIL_SECTIONS = ("happened", "factors", "ahead", "help")


def ui_shell():
    """'sidebar' (approved) or 'classic' (temporary, for regression and rollback). An unknown value is refused."""
    if UI_SHELL: return UI_SHELL
    v = json.loads((ROOT / "config" / "active_ui.json").read_text(encoding="utf-8")).get("shell")
    if v not in SHELLS: raise ValueError(f"active_ui.json shell must be one of {sorted(SHELLS)}, not {v!r}")
    return v


def _datasets_analyzed(primary, optionals, result, sections):
    """Snapshot the file references and visible uses of this result."""
    primary_code = "D01" if primary["grain"] == "contact" else "D02"
    uses = {primary_code: [result["metric"]["label"], "Daily and group comparisons"]}
    insight = result["insights"]
    factors, help_ = "factors" in sections, "help" in sections
    for disclosure in result["match_disclosure"]:
        uses[disclosure["module"]] = ["Survey and audit coverage"]
    if factors:
        related_sources = set()
        for pair in insight.get("metric_relationships", ()):
            if pair["weeks"]:
                related_sources.update((primary_code, pair["source"]))
        for code in sorted(related_sources):
            uses.setdefault(code, []).append("Weekly metric relationships")
        cart = insight.get("cart_profiles")
        if cart and cart["paths"]:
            for code in sorted({primary_code, *(item["source"] for item in cart["features"])}):
                uses.setdefault(code, []).append("Historical CART profiles")
        if insight.get("contact_driver_impact"):
            uses[primary_code].append("Contact driver impact")
        links = insight.get("component_links")
        if links:
            uses.setdefault(links["source"], []).append("Weekly component relationships")
        movement = insight.get("component_movement")
        if movement:
            uses.setdefault(movement["source"], []).append("Before and After component comparison")
            if movement["groups"]:
                uses.setdefault("D06", []).append("Component comparison by team lead")
        shortfall = insight.get("components")
        if shortfall:
            code = "D04" if shortfall["kind"] == "qa" else "D03"
            uses.setdefault(code, []).append("Component shortfalls")
        if insight.get("constraints"):
            uses.setdefault("D09", []).append("Constraint analysis")
    if (factors or help_) and insight.get("roster_match") is not None:
        uses.setdefault("D06", []).append("Roster coverage")
        if factors and insight["roster_match"]["agents_in_roster"]:
            uses["D06"].append("Agent group comparisons")
    scenario = insight.get("scenario")
    if help_ and scenario and not scenario.get("blocked"):
        uses.setdefault("D09", []).append("Improvement scenario")
    if "ahead" in sections and result["forecast"].get("status") == "published":
        uses[primary_code].append("Forecast")
    if result.get("calendar_events"):
        uses["D08"] = ["Historical events in What Happened"]
    if "current_actions" in result:
        uses["D07"] = ["Recorded actions in scope at the report cutoff"]
    if result.get("hourly_heatmap"):
        uses[primary_code].append("Calendar day and hour heatmap")
        if result["hourly_heatmap"]["leads"]:
            uses.setdefault("D06", []).append("Hourly comparison by team lead")
    if result.get("agent_heatmap"):
        for code in sorted({column["source"] for column in result["agent_heatmap"]["columns"]}):
            uses.setdefault(code, []).append("Agent and group metric heatmap")
        if any(group["id"] in ("team_lead", "manager_name") for group in result["agent_heatmap"]["groupings"]):
            uses.setdefault("D06", []).append("Agent heatmap roster groups")
    if any(any(dimension in insights.PEOPLE_DIMENSIONS for dimension in measure["groups"])
           for measure in result.get("group_comparison", ())):
        uses.setdefault("D06", []).append("Group box plots by roster")
    return [{"code": code, "file": upload["summary"]["file"], "rows": upload["summary"]["rows"],
             "primary": code == primary_code, "uses": uses.get(code, [])}
            for code, upload in [(primary_code, primary), *optionals.items()]]


def _view_run_key(fingerprint, optionals, *sources):
    """Bind view requests to the primary run and relevant resolved optional uploads."""
    source_ids = [optionals.get(code, {}).get("upload_id") for code in sources]
    return hashlib.sha256(json.dumps([fingerprint, sources, *source_ids]).encode()).hexdigest()


def _calendar_events(upload, scope, known_lines, *, include_recorded_scope=False):
    lines = set(scope["lines_of_business"])
    known_lines = set(known_lines)
    events = []
    examples = []
    withheld = 0
    for entry in upload["records"]:
        if entry["status"] != "valid":
            continue
        record, event_scope = entry["record"], entry["calendar_scope"]
        day = event_scope["date"]
        if record["account_id"] != scope["account"] or not scope["start"] <= day <= scope["end"]:
            continue
        malformed = sorted(known_lines.intersection(event_scope["malformed_flags"]))
        if malformed:
            withheld += 1
            remaining = optional_intake.LIMITS["max_examples"] - len(examples)
            examples.extend({"source_row": entry["source_row"], "field": field,
                             "code": "INVALID-CALENDAR-SCOPE-FLAG", "message": "Enter 0 or 1 for this Line of Business."}
                            for field in malformed[:remaining])
            continue
        recorded = known_lines.intersection(event_scope["lines_of_business"])
        applies_to = sorted(lines.intersection(recorded))
        if applies_to:
            event = {"date": day, "type": record["event_type"], "details": record.get("event_details"),
                     "lines_of_business": applies_to}
            if include_recorded_scope:
                event["recorded_lines_of_business"] = sorted(recorded)
            events.append(event)
    return sorted(events, key=lambda event: event["date"]), {"withheld_rows": withheld, "examples": examples}


DAILY_EVENT_BANDS = tuple(
    {"band": band, "cutoff": 10 - 3 * quantile / 1.959963984540054, "wording": wording}
    for band, quantile, wording in (
        ("98%", 2.3263478740408408, "may be associated"),
        ("90%", 1.6448536269514722, "appear to be associated"),
        ("80%", 1.2815515655446004, "were found to be associated"),
    )
)


def _daily_event_tier(mean):
    return next((band["band"] for band in reversed(DAILY_EVENT_BANDS) if abs(mean) >= band["cutoff"]), None)


def _daily_selection(result, scope, window):
    start, end = scope["start"], scope["end"]
    lines, drivers = scope["lines_of_business"], scope["contact_types"]
    if window is None:
        return dict(start=start, end=end, line="", driver="", lines_of_business=lines, contact_types=drivers), result["by_day"]
    if not isinstance(window, dict):
        raise ValueError("Choose dates and work scope within the completed analysis.")
    first, last = window.get("start"), window.get("end")
    if (not isinstance(first, str) or not isinstance(last, str) or not start <= first <= last <= end
            or date.fromisoformat(first).isoformat() != first or date.fromisoformat(last).isoformat() != last):
        raise ValueError("Choose an ordered date range within the analysis window.")
    def selected_ids(key, single_key, available):
        if key in window:
            values = window[key]
            if not isinstance(values, list) or not values:
                raise ValueError("Select at least one Line of Business and contact driver.")
        else:
            single = window.get(single_key, "")
            values = [single] if single != "" else available
        if any(not isinstance(value, str) or value not in available for value in values):
            raise ValueError("Choose Lines of Business and contact drivers within the analysis scope.")
        chosen = set(values)
        return None if chosen == set(available) else chosen

    selected_lines = selected_ids("lines_of_business", "line", lines)
    selected_drivers = selected_ids("contact_types", "driver", drivers)
    if selected_lines is not None or selected_drivers is not None:
        groups = [group for group in result["combined_daily"]
                  if (selected_lines is None or group["line_of_business"] in selected_lines)
                  and (selected_drivers is None or group["contact_type"] in selected_drivers)
                  and any(row["count"] > 0 for row in group["by_day"])]
        if not groups:
            raise ValueError("Choose Lines of Business and contact drivers that occur together.")
        lines = sorted({group["line_of_business"] for group in groups})
        drivers = sorted({group["contact_type"] for group in groups})
        daily = {}
        for group in groups:
            for row in group["by_day"]:
                if first <= row["key"] <= last:
                    day = daily.setdefault(row["key"], {"key": row["key"], "total": 0, "count": 0})
                    day["total"] += row["total"]
                    day["count"] += row["count"]
        readings = [day | {"value": day["total"] / day["count"]} for _, day in sorted(daily.items()) if day["count"]]
    else:
        readings = [row for row in result["by_day"] if first <= row["key"] <= last]
    return dict(start=first, end=last, line=next(iter(selected_lines)) if selected_lines and len(selected_lines) == 1 else "",
                driver=next(iter(selected_drivers)) if selected_drivers and len(selected_drivers) == 1 else "",
                lines_of_business=lines, contact_types=drivers), readings


def _daily_type_comparison(kind, exposed, readings, weekdays, weekday_readings, date_titles):
    benchmarks, gaps, omitted, titles = {}, [], [], {}
    for day in sorted(exposed):
        row, weekday = readings.get(day), weekdays[day]
        if weekday not in benchmarks and row is not None:
            controls = [ref for ref in weekday_readings[weekday] if ref["key"] not in exposed]
            benchmarks[weekday] = {"value": sum(ref["value"] for ref in controls) / len(controls), "count": len(controls)} if controls else None
        benchmark_row = benchmarks.get(weekday)
        if row is None or benchmark_row is None:
            omitted.append({"date": day, "reason": "no_eligible_aht" if row is None else "no_weekday_reference"})
            continue
        benchmark = benchmark_row["value"]
        difference = row["value"] - benchmark
        hours = difference * row["count"] / 3600
        title, attribution = date_titles[day]
        gaps.append(row | {"benchmark": benchmark, "difference": difference, "hours": hours,
                           "attribution": attribution})
        if title:
            record = titles.setdefault(title, {"title": title, "hours": 0, "contacts": 0, "dates": 0})
            record["hours"] += hours
            record["contacts"] += row["count"]
            record["dates"] += 1
    mean = sum(gap["difference"] for gap in gaps) / len(gaps) if gaps else None
    ranked = sorted((title for title in titles.values() if mean and title["hours"] * mean > 0),
                    key=lambda title: -abs(title["hours"]))
    leader = ranked[0] if ranked and (len(ranked) == 1 or ranked[0]["hours"] != ranked[1]["hours"]) else None
    counts = {"higher": sum(gap["difference"] > 0 for gap in gaps), "lower": sum(gap["difference"] < 0 for gap in gaps),
              "unchanged": sum(gap["difference"] == 0 for gap in gaps)}
    return {"type": kind, "mean": mean, "tier": _daily_event_tier(mean) if gaps else None, "direction_counts": counts,
            "gaps": gaps, "benchmarks": {str(day): value for day, value in benchmarks.items() if value is not None}, "omitted": omitted,
            "titles": list(titles.values()), "leader": leader}


def _daily_event_comparison(result, scope, known_lines, calendar, run, window):
    selection, rows = _daily_selection(result, scope, window)
    source, applicable = None, {}
    if calendar:
        account_scope = scope | {"lines_of_business": known_lines, "start": date.min.isoformat(), "end": date.max.isoformat()}
        events, diagnostics = _calendar_events(calendar, account_scope, known_lines, include_recorded_scope=True)
        source = {"upload_id": calendar["upload_id"], "sha256": calendar["file_sha256"], "date_format": calendar["date_settings"]["date_format"],
                  "first_date": events[0]["date"] if events else None, "last_date": events[-1]["date"] if events else None,
                  "lines_of_business": sorted({line for event in events for line in event["lines_of_business"]}),
                  "diagnostics": diagnostics}
        lines = set(selection["lines_of_business"])
        for event in events:
            matched = sorted(lines.intersection(event["lines_of_business"]))
            if matched and selection["start"] <= event["date"] <= selection["end"]:
                applicable.setdefault(event["date"], []).append(event | {"lines_of_business": matched})
    readings = {row["key"]: {field: row[field] for field in ("key", "value", "total", "count")}
                for row in rows if row["count"] and row["value"] is not None}
    weekdays = {day: date.fromisoformat(day).weekday() for day in readings.keys() | applicable.keys()}
    weekday_readings, exposures, date_titles = {}, {}, {}
    for day, row in readings.items():
        weekday_readings.setdefault(weekdays[day], []).append(row)
    for day, events in applicable.items():
        identities = {(event["type"], event["details"]) for event in events}
        title = events[0]["details"] if len(identities) == 1 else None
        date_titles[day] = (title, "individual_title" if title else "shared_date" if len(identities) > 1 else "title_unavailable")
        for kind, _ in identities:
            exposures.setdefault(kind, set()).add(day)
    types = [_daily_type_comparison(kind, exposures[kind], readings, weekdays, weekday_readings, date_titles)
             for kind in sorted(exposures, key=lambda kind: (kind.casefold(), kind))]
    types.sort(key=lambda item: -abs(item["mean"]) if item["mean"] is not None else 1)
    reason = (None if any(item["gaps"] for item in types) else "no_weekday_comparison" if types
              else "no_matching_events" if source and source["first_date"] else "no_usable_source")
    return {"method": "aht-recorded-event-comparison-v1", "run": run, "source": source, "selection": selection,
            "reason": reason, "bands": DAILY_EVENT_BANDS, "types": types, "interval_status": "unavailable",
            "events_by_date": applicable, "weekdays": {str(day): rows for day, rows in weekday_readings.items()}}


def _report_actions(upload, scope):
    """Project the minimum registry fields for actions relevant to this report."""
    settings = upload["date_settings"]
    date_format = dates.FORMAT_NAMES[settings["date_format"]]
    zone = settings["time_zone"]
    actions = []
    for entry in upload["records"]:
        if entry["status"] != "valid":
            continue
        record = entry["record"]
        if record["account_id"] != scope["account"]:
            continue
        start = dates.read(record["start_date"], date_format, zone).business_date
        end = dates.read(record["end_date"], date_format, zone).business_date if record.get("end_date") else None
        if not start or start > scope["end"] or (end and end < scope["start"]):
            continue
        action = {"id": record["action_id"], "title": record["action_title"], "start": start, "end": end,
                  "status": "ended" if end and end < scope["end"] else "open"}
        if record.get("action_owner"):
            action["owner"] = record["action_owner"]
        actions.append(action)
    return sorted(actions, key=lambda action: (action["start"], action["id"]))


def settings_dataset_templates(layouts, optional):
    """Join synthetic field examples to the accepted CSV layouts."""
    examples = json.loads((ROOT / "config/dataset_template_examples.json").read_text(encoding="utf-8"))
    primary_details = {
        "contact": ("D01", "Handling time for each individual contact."),
        "agent_day": ("D02", "Daily handled contact counts and handling time totals for each agent."),
    }
    templates = []
    for layout in layouts:
        code, description = primary_details[layout["grain"]]
        templates.append({**layout, "id": code, "description": description, "needs_one_of": []})
    for layout in optional:
        with (ROOT / layout["template"].lstrip("/")).open(encoding="utf-8", newline="") as source:
            names = next(csv.reader(source))
        columns = {column["name"]: column for column in layout["columns"]}
        templates.append({**layout, "columns": [columns[name] for name in names]})
    for template in templates:
        support = examples[template["id"]]
        template["columns"] = [{**column, **support[column["name"]]} for column in template["columns"]]
    return templates


def guides():
    """Plain facts for the dataset and classic guide destinations."""
    from athena.upload_checks import REQUIRED
    q = questionnaire.load(); base = q["dataset_requests"]["duration_data"]; pol = dq_contracts.load_policy()
    help_ = json.loads((ROOT / "config" / "column_help.json").read_text(encoding="utf-8"))
    cols = {"contact": REQUIRED["contact"] + ["talk_seconds", "hold_seconds", "after_call_work_seconds"], "agent_day": REQUIRED["agent_day"]}
    kinds = {"quarantine": "Set aside", "hold": "Held", "valid": "Counted once", "flag": "Counted with a note", "block": "Stops the analysis"}
    effects = {"quarantine": "Set aside and not counted.", "hold": "Held out of every calculation until the conflict is resolved.", "valid": "Counted once, and every occurrence stays traceable.",
               "flag": "Counted in account and Line of Business results; not used where the agent matters.", "block": "The analysis cannot continue."}
    problems = [{"kind": kinds[f["disposition"]], "problem": f["problem"], "why": f["why"], "remedy": f["remedy"], "effect": effects[f["disposition"]]}
                for sec in ("record_faults", "group_faults", "flags", "group_resolutions", "run_blocks") for f in pol[sec].values()]
    layouts = [{"grain": g, "label": base["grain_labels"][g], "template": "/templates/" + base["templates"][g],
                "columns": [{"name": c, "meaning": help_[c], "optional": c not in REQUIRED[g]} for c in cols[g]]} for g in base["accepted_grains"]]
    optional = optional_intake.guides()
    return {"layouts": layouts, "problems": problems, "optional": optional,
            "settings_templates": settings_dataset_templates(layouts, optional),
            "optional_max_bytes": optional_intake.LIMITS["max_upload_bytes"]}


def storage_mode():
    return CONFIG_STORAGE or ingest.configured_storage_mode()


def active_configuration(req):
    """(configuration, issues). In session mode the client sends its active configuration and it is revalidated every time."""
    cfg = req.get("configuration")
    if storage_mode() != "session" or cfg is None: return None, []
    issues, _ = session_config.validate_config(cfg)
    return (None, issues) if issues else (cfg, [])


def neutralize_csv(b):
    """Cells that a spreadsheet could read as a formula are prefixed with an apostrophe. Idempotent."""
    out = io.StringIO(newline=""); w = csv.writer(out, lineterminator="\r\n")
    for row in csv.reader(io.StringIO(b.decode("utf-8"), newline="")): w.writerow([dq._safe_cell(c) if c else c for c in row])
    return out.getvalue().encode("utf-8")


def run_fingerprint(up, plan_answers, scope, prof, configuration=None):
    """Run identity pins the file, the data-quality policy and rules, the engine and the registry, so a changed policy
    cannot reuse an earlier result."""
    prov = up.get("provenance")
    rules = (prov["policy_sha256"][:16] + "+" + prov["identity_rules_sha256"][:16]) if prov else "strict_legacy+" + dq_contracts.sha256_of(ingest.policy(POLICY_FILE))[:16]
    pins = {"source_sha256": up.get("file_sha256") or up.get("source_upload_id") or up["upload_id"], "mapping_version": f"layout:{up['grain']}@0.1.0",
            "profile_id": configuration["configuration_id"] if configuration else (prof["profile_id"] if prof else "NONE"),
            "profile_version": (configuration["configuration_version"] + "+" + session_config.sha(configuration)[:12]) if configuration else (prof["profile_version"] if prof else "NONE"),
            "engine_version": metric_engine.ENGINE_VERSION, "registry_version": REGISTRY_SHA, "rules_version": rules, "baseline_version": "NONE"}
    run_inputs = {"answers": plan_answers, "scope": scope}
    if up.get("dates_basis") == "account_business_dates":
        run_inputs["primary_date_settings"] = up["date_settings"]
    return run_identity.fingerprint(run_inputs, pins), pins


def date_settings(get):
    """(settings, format token, zone) from the request headers X-Date-Format and X-Business-Timezone; absent means month-first and Asia/Manila.
    Anything else is refused rather than ignored, so a typo cannot silently change which day a date is."""
    name = get("X-Date-Format") or "month_first"
    zone = get("X-Business-Timezone") or "Asia/Manila"
    try:
        if name not in dates.FORMAT_NAMES or len(zone) > 64: raise ValueError()
        dates.zone_for(zone)
    except ValueError:
        raise optional_intake.IntakeError("INVALID-DATE-SETTING", "The date format or time zone for this file was not recognised.", 400) from None
    return {"date_format": name, "time_zone": zone}, dates.FORMAT_NAMES[name], zone


def inspect_response(res):
    if res.get("role")=="optional": return optional_intake.public_view(res)
    base = {"restore_token": res.get("restore_token"), "ok": res["ok"], "upload_id": res["upload_id"], "grain": res["grain"], "issues": res["issues"], "summary": res["summary"],
            "exclusions": res.get("exclusions"), "profile": res.get("profile"), "policy_mode": res.get("policy_mode", "strict_legacy"),
            "manifest_available": bool(res.get("manifest_rows")), "manifest_url": None, "notices": [], "reconciliation": None, "groups": [], "quality": None,
            "findings": res.get("findings", []), "date_settings": res.get("date_settings")}
    base.update(source_columns=res.get("source_columns"), source_column_count=res.get("source_column_count"),
                source_columns_truncated=res.get("source_columns_truncated", False))
    if res.get("manifest_rows"): base["manifest_url"] = f"/api/manifest/{res['upload_id']}?t={res['manifest_token']}"
    if res.get("policy_mode") == "disposition_aware":
        v = dq.public_view(res)
        base.update(notices=v["notices"], reconciliation=v["reconciliation"], groups=v["groups"],
                    quality={"provenance": v["provenance"], "decision_digest": v["decision_digest"], "records_total": v["records_total"]})
    return base


def read_optional_body(handler, size, ticket):
    """Bound only optional request reads; closed owners retain the actual in-flight work cap."""
    deadline=time.monotonic()+OPTIONAL_BODY_DEADLINE_SECONDS
    connection=getattr(handler,"connection",None)
    previous=connection.gettimeout() if connection else None
    chunks=[]
    remaining=size
    try:
        while remaining:
            OPTIONAL_RESOURCES.check_active(ticket)
            budget=deadline-time.monotonic()
            if budget<=0: raise optional_intake.IntakeError("UPLOAD-TIMEOUT","The optional file upload timed out. Try again.",408)
            if connection: connection.settimeout(budget)
            read=getattr(handler.rfile,"read1",handler.rfile.read)
            chunk=read(min(65536,remaining))
            if not chunk: raise optional_intake.IntakeError("INCOMPLETE-FILE","The file upload did not finish. Try again.",400)
            chunks.append(chunk);remaining-=len(chunk)
        OPTIONAL_RESOURCES.check_active(ticket)
        return b"".join(chunks)
    except TimeoutError: raise optional_intake.IntakeError("UPLOAD-TIMEOUT","The optional file upload timed out. Try again.",408) from None
    finally:
        if connection: connection.settimeout(previous)


class H(BaseHTTPRequestHandler):
    server_version = "AthenaLocal"
    def log_message(self, *a): pass

    def json(self, status, obj):
        self.bytes(status, json.dumps(obj).encode("utf-8"), "application/json")

    def bytes(self, status, b, ctype, extra=None):
        self.send_response(status); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(b)

    def err(self, status, code, message, issues=None):
        e = {"error_code": code, "message": message, "request_id": "local"}
        if issues: e["field_issues"] = issues
        self.json(status, e)

    def sample(self, p):
        """Testing only: serve the sample setup and its dataset files from the chosen set folder, by an allow-listed name."""
        plan = json.loads((ROOT / "config/sample_injection.json").read_text(encoding="utf-8"))
        query = parse_qs(urlsplit(self.path).query)
        chosen = (query.get("set") or [plan["default_set"]])[0]
        if chosen not in plan["sets"]: return self.err(404, "NOT-FOUND", "Not found.")
        folder = ((ROOT / plan["folder"]).resolve() / chosen)
        names = {plan["primary"]["file"], *plan["optional"].values()}
        if p == "/api/sample":
            info = folder / "SET_INFO.json"
            if not info.is_file(): return self.err(404, "SAMPLE-MISSING", "The sample folder is not available on this computer.")
            meta = json.loads(info.read_text(encoding="utf-8"))
            setup = {k: v for k, v in plan.items() if k not in ("folder", "sets", "default_set")}
            setup.update(account=meta["account"], targets=meta["targets"])
            return self.json(200, {"set": chosen, "sets": plan["sets"], "setup": setup, "available": sorted(n for n in names if (folder / n).is_file())})
        name = p[len("/api/sample/file/"):]
        if name not in names: return self.err(404, "NOT-FOUND", "Not found.")
        if not (folder / name).is_file(): return self.err(404, "SAMPLE-MISSING", "The sample folder is not available on this computer.")
        return self.bytes(200, (folder / name).read_bytes(), "text/csv", {"X-Content-Type-Options": "nosniff"})

    def do_GET(self):
        raw_path = self.path
        if urlsplit(raw_path).path in ("/assets/athena-light-02.svg", "/assets/athena-dark-02.svg"):
            return self.bytes(200, (ROOT / "journey" / urlsplit(raw_path).path.lstrip("/")).read_bytes(), "image/svg+xml")
        p = urlsplit(raw_path).path
        if p == "/favicon.ico":
            return self.bytes(204, b"", "image/x-icon")
        if p == "/":
            html = tokens.render((ROOT / "journey/index.html").read_text(encoding="utf-8"))
            return self.bytes(200, html.encode("utf-8"), "text/html; charset=utf-8",
                              {"Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'"})
        if p.startswith("/templates/") and p[11:] in TEMPLATES:
            return self.bytes(200, (ROOT / "vendor/handoff/templates" / p[11:]).read_bytes(), "text/csv")
        optional_template=next((m["template"] for m in optional_intake.MODULES.values() if p=="/"+m["template"]),None)
        if optional_template:
            return self.bytes(200,(ROOT/optional_template).read_bytes(),"text/csv",{"X-Content-Type-Options":"nosniff"})
        if p == "/api/sample" or p.startswith("/api/sample/file/"):
            return self.sample(p)
        if p == "/api/config":
            sess = storage_mode() == "session"
            return self.json(200, {"business_questions": questionnaire.load()["business_questions"], "duration_units": session_config.DURATION_UNITS, "directions": metrics.DIRECTIONS, "metrics": {k: {"label": metrics.get(k)["label"], "directions": metrics.get(k)["directions"], "default_direction": metrics.get(k)["default_direction"], "columns": metrics.get(k).get("columns", {})} for k in session_config.ANALYSABLE}, "configuration_storage": storage_mode(), "shell": ui_shell(), "guides": guides(),
                                   "profiles": [] if sess else profiles.load_all(), "field_help": session_config.TEMPLATE_HELP if sess else profiles.FIELD_HELP})
        if p == "/api/account-template":
            if storage_mode() == "session":
                b = json.dumps(session_config.blank_template(), indent=2).encode("utf-8"); fn = "session_configuration_template.json"
            else:
                b = json.dumps(profiles.template()["profile"], indent=2).encode("utf-8"); fn = "account_configuration_template.json"
            return self.bytes(200, b, "application/json", {"Content-Disposition": f'attachment; filename="{fn}"'})
        if p.startswith("/api/manifest/"):
            u = urlsplit(raw_path); uid = u.path[len("/api/manifest/"):]; tok = (parse_qs(u.query).get("t") or [""])[0]
            r = UPLOADS.get(uid) if ID.match(uid) else None
            if not r or not r.get("manifest_rows") or not secrets.compare_digest(tok, r.get("manifest_token", "-")):
                return self.err(404, "NOT-FOUND", "No rows to list.")
            return self.bytes(200, neutralize_csv(ingest.manifest_csv(r)), "text/csv; charset=utf-8",
                              {"Content-Disposition": 'attachment; filename="rows_to_correct.csv"', "X-Content-Type-Options": "nosniff"})
        self.err(404, "NOT-FOUND", "Not found.")

    def body(self, limit):
        n = int(self.headers.get("Content-Length") or 0)
        return None if n > limit else self.rfile.read(n)

    def do_POST(self):
        def header(name):
            return next((value for key,value in self.headers.items() if key.lower()==name.lower()),None)
        if self.path=="/api/upload/session":
            raw=self.body(1000)
            try:
                if raw is None or json.loads(raw or b"{}")!={}: raise ValueError()
                return self.json(200,OPTIONAL_RESOURCES.create_owner())
            except optional_intake.IntakeError as exc: return self.err(exc.status,exc.code,exc.message)
            except (ValueError,TypeError): return self.err(400,"INVALID-JSON","The optional-file session request could not be read.")
        if self.path=="/api/inspect" and header("X-Dataset-Module") is not None:
            ticket=None
            try:
                length=header("Content-Length")
                if not isinstance(length,str) or not re.fullmatch(r"[0-9]{1,10}",length):
                    raise optional_intake.IntakeError("CONTENT-LENGTH","Supply the optional file's supported length.",411)
                module=header("X-Dataset-Module")
                size=int(length)
                ticket=OPTIONAL_RESOURCES.reserve(header("X-Optional-Owner"),header("X-Optional-Token"),module,size)
                data=read_optional_body(self,size,ticket)
                if len(data)!=size: raise optional_intake.IntakeError("INCOMPLETE-FILE","The file upload did not finish. Try again.",400)
                name=re.sub(r"[\r\n]","",header("X-Filename") or "upload.csv")[:128]
                settings,fmt,zone=date_settings(header)
                candidate=optional_intake.inspect(module,name,data,date_format=fmt,zone=zone)
                candidate["date_settings"]=settings
                return self.json(200,OPTIONAL_RESOURCES.commit(ticket,candidate))
            except optional_intake.IntakeError as exc: return self.err(exc.status,exc.code,exc.message)
            except Exception: return self.err(500,"OPTIONAL-CHECK-FAILED","The optional file could not be checked. Try again.")
            finally:
                if ticket: OPTIONAL_RESOURCES.cancel(ticket)
        if self.path == "/api/end-session":
            # Uploads live only for the browser tab that created them.  Ending one
            # tab's session must never discard another tab's in-memory work.
            raw = self.body(10_000)
            try: req = json.loads(raw or b"{}")
            except (ValueError, TypeError): req = {}
            uid = req.get("upload_id") if isinstance(req, dict) else None
            if isinstance(req,dict) and ("uploads" in req or "optional_owner" in req):
                entries=req.get("uploads",[]); owner=req.get("optional_owner")
                if not isinstance(entries,list) or len(entries)>8 or any(not isinstance(e,dict) or set(e)-{"id","token"} or not isinstance(e.get("id"),str) or not ID.fullmatch(e["id"]) for e in entries):
                    return self.err(400,"INVALID-UPLOADS","The file cleanup request could not be read.")
                try:
                    with OPTIONAL_RESOURCES.lock:
                        if owner is not None:
                            if not isinstance(owner,dict) or set(owner)!={"owner_id","owner_token"}: return self.err(400,"OPTIONAL-OWNER","The optional-file session could not be read.")
                            OPTIONAL_RESOURCES._owner(owner["owner_id"],owner["owner_token"])
                        for entry in entries:
                            r=UPLOADS.get(entry["id"])
                            if not r: continue
                            if r.get("role")=="optional":
                                if owner is None: raise optional_intake.IntakeError("OPTIONAL-OWNER","An optional-file session is required.",403)
                                OPTIONAL_RESOURCES.restore(entry["id"],entry.get("token"),owner["owner_id"],owner["owner_token"])
                            elif not isinstance(entry.get("token"),str) or not secrets.compare_digest(entry["token"],r.get("restore_token","-")):
                                return self.err(403,"UPLOAD-OWNER","The file cleanup capability does not match.")
                        for entry in entries:
                            r=UPLOADS.get(entry["id"])
                            if r and r.get("role")=="optional": OPTIONAL_RESOURCES.release(entry["id"],entry.get("token"),owner["owner_id"],owner["owner_token"])
                            else: UPLOADS.pop(entry["id"],None)
                        if req.get("close_optional_owner") is True and owner is not None: OPTIONAL_RESOURCES.close(owner["owner_id"],owner["owner_token"])
                except optional_intake.IntakeError as exc: return self.err(exc.status,exc.code,exc.message)
            if isinstance(uid, str) and ID.match(uid):
                if UPLOADS.get(uid,{}).get("role")=="optional": return self.err(403,"OPTIONAL-OWNER","Use the optional-file cleanup capability.")
                with OPTIONAL_RESOURCES.lock: UPLOADS.pop(uid, None)
            return self.json(200, {"ok": True})
        if self.path == "/api/upload/restore":
            raw = self.body(10_000)
            try: req = json.loads(raw or b"{}"); uid, tok = req["upload_id"], req["token"]
            except (ValueError, KeyError, TypeError): return self.err(400, "INVALID-JSON", "The request could not be read.")
            r = UPLOADS.get(uid) if isinstance(uid, str) and ID.match(uid) else None
            if r and r.get("role")=="optional":
                owner=req.get("optional_owner")
                try:
                    if not isinstance(owner,dict) or set(owner)!={"owner_id","owner_token"}: raise optional_intake.IntakeError("OPTIONAL-OWNER","An optional-file session is required.",403)
                    return self.json(200,OPTIONAL_RESOURCES.restore(uid,tok,owner["owner_id"],owner["owner_token"]))
                except optional_intake.IntakeError as exc: return self.err(exc.status,exc.code,exc.message)
            if not r or not isinstance(tok, str) or not secrets.compare_digest(tok, r.get("restore_token", "-")): return self.err(404, "NOT-FOUND", "That file is no longer available.")
            return self.json(200, inspect_response(r))
        if self.path == "/api/configuration/validate":
            if storage_mode() != "session": return self.err(404, "NOT-FOUND", "Not found.")
            data = self.body(1_000_000)
            if data is None: return self.err(413, "FILE-TOO-LARGE", "The configuration file is too large.")
            r = session_config.load_any(data)
            return self.json(200, {"ok": r["ok"], "kind": r["kind"], "issues": r["issues"], "warnings": r["warnings"], "configuration": r["configuration"],
                                   "summary": session_config.summary(r["configuration"]) if r["ok"] else None})
        if self.path == "/api/configuration/diff":
            if storage_mode() != "session": return self.err(404, "NOT-FOUND", "Not found.")
            raw = self.body(1_000_000)
            try: req = json.loads(raw or b"{}"); lines = session_config.diff(req["active"], req["staged"])
            except (ValueError, KeyError, TypeError): return self.err(400, "INVALID-JSON", "The request could not be read.")
            return self.json(200, {"lines": lines})
        if self.path == "/api/account":
            if storage_mode() != "stored_files": return self.err(404, "NOT-FOUND", "Not found.")
            data = self.body(1_000_000)
            if data is None: return self.err(413, "FILE-TOO-LARGE", "The configuration file is too large.")
            ok, issues = profiles.save(data, VALIDATOR)
            return self.json(200, {"ok": ok, "issues": issues, "profiles": profiles.load_all()})
        if self.path == "/api/inspect":
            data = self.body(LIMITS["max_upload_bytes"])
            if data is None: return self.err(413, "FILE-TOO-LARGE", "The file is larger than the supported size.")
            name = re.sub(r"[\r\n]", "", self.headers.get("X-Filename", "upload.csv"))[:128]
            try: settings, fmt, zone = date_settings(header)
            except optional_intake.IntakeError as exc: return self.err(exc.status, exc.code, exc.message)
            res = ingest.inspect(name, data, LIMITS, VALIDATOR, ingest.policy(POLICY_FILE), date_format=fmt, zone=zone)
            res["date_settings"] = settings
            # Display-only source metadata; never changes inspection eligibility.
            try:
                if b"\x00" in data: raise ValueError("Non-text header")
                header = next(csv.reader(io.StringIO(data.decode("utf-8-sig"), newline="")), None)
                if header is not None:
                    res.update(source_columns=[s[:256] for s in header[:256]], source_column_count=len(header),
                               source_columns_truncated=len(header) > 256 or any(len(s) > 256 for s in header))
            except (UnicodeDecodeError, csv.Error, ValueError):
                pass
            # ``ingest`` assigns a stable content fingerprint.  The web session
            # needs a separate opaque handle: two tabs may inspect identical
            # bytes and must still be able to end independently.
            res["source_upload_id"] = res["upload_id"]
            res["upload_id"] = secrets.token_hex(8)
            res["profile"] = profiles.match(res["summary"]["accounts"][0]) if (res["ok"] and storage_mode() == "stored_files") else None
            res["manifest_token"] = secrets.token_urlsafe(16); res["restore_token"] = secrets.token_urlsafe(16)
            with OPTIONAL_RESOURCES.lock: UPLOADS[res["upload_id"]] = res
            return self.json(200, inspect_response(res))
        raw = self.body(1_000_000)
        try: req = json.loads(raw or b"{}")
        except ValueError: return self.err(400, "INVALID-JSON", "The request could not be read.")
        uid = req.get("upload_id")
        up = UPLOADS.get(uid) if isinstance(uid, str) and ID.match(uid) else None
        if up and up.get("role")=="optional": return self.err(422,"PRIMARY-REQUIRED","Choose a primary contact or agent-day dataset for this analysis.")
        detected = up["summary"] if up and up["ok"] else None
        prof = up.get("profile") if up and up["ok"] else None
        configuration, cissues = active_configuration(req)
        if cissues: return self.err(422, "CONFIG-INVALID", "The active configuration could not be used.", [{"field": i.get("code"), "reason_code": i["code"], "message": i["problem"]} for i in cissues])
        base_configuration = configuration
        cockpit = req.get("journey") == "cycle1"
        display_unit = req.get("display_unit", "seconds")
        if not isinstance(display_unit, str) or display_unit not in session_config.DURATION_UNITS:
            return self.err(422, "UNIT-INVALID", "Choose seconds, minutes or hours for AHT.")
        if cockpit and "analysis_mapping" in req and "analysis_setup" in req:
            return self.err(422, "MAPPING-INVALID", "Use one target mapping for this analysis.")
        if cockpit and "analysis_mapping" in req:
            configuration, mapping_issues = session_config.with_analysis_mapping(configuration, req["analysis_mapping"])
            if mapping_issues:
                return self.err(422, "MAPPING-INVALID", "Review the target periods, limits and scope.", mapping_issues)
        mapping_warnings = []
        if cockpit and configuration:
            configuration, mapping_issues, mapping_warnings = session_config.for_analysis(configuration, detected, req.get("answers") or {}, req.get("analysis_setup"))
            if mapping_issues: return self.err(422, "MAPPING-INVALID", "Review the target periods, limits and scope.", mapping_issues)
        if self.path == "/api/plan":
            pl = questionnaire.plan(req.get("answers") or {}, detected, profile=prof, configuration=configuration, cockpit=cockpit)
            pl["dataset_notices"] = mapping_warnings
            return self.json(200, pl)
        if self.path == "/api/result":
            daily_request = "daily_window" in req or "daily_run" in req
            if daily_request and not cockpit:
                return self.err(422, "DAILY-SCOPE", "Open the current Daily trend result before applying a selection.")
            if not up or not up["ok"]: return self.err(404, "NOT-FOUND", "No usable upload.")
            pl = questionnaire.plan(req.get("answers") or {}, detected, profile=prof, configuration=configuration, cockpit=cockpit)
            if not pl["complete"]:
                return self.err(422, "INCOMPLETE", "Some answers are still needed.",
                                [{"field": f, "reason_code": "REQUIRED", "message": "Needed."} for f in pl["missing"]])
            full_detail = cockpit and req.get("full_detail") is True
            calculation_sections = FULL_DETAIL_SECTIONS if full_detail else pl["sections"]
            a = pl["answers"]
            scope = {"account": detected["accounts"][0], "lines_of_business": a["scope_lines_of_business"],
                     "start": a["scope_period"]["start"], "end": a["scope_period"]["end"], "group_by": a.get("group_dimension")}
            if cockpit: scope["contact_types"] = pl["allowed_contact_types"]
            if cockpit and (not base_configuration or not (pl["configuration_status"] or {}).get("applied")):
                return self.err(422, "CONFIG-ACCOUNT-MISMATCH", "Choose a configuration for this account.")
            applied = configuration if (pl["configuration_status"] or {}).get("applied") else None
            dates_basis = up.get("dates_basis")
            if applied and dates_basis == "account_business_dates":
                account = applied["account"]
                settings = {"time_zone": account["business_timezone"], "date_format": account.get("date_format", "month_first")}
                if up["date_settings"] != settings:
                    return self.err(422, "DATE-SETTINGS-CHANGED", "Add the primary file again so Athena can read it using the current date settings.")
            if cockpit:
                scope["group_dimensions"] = ["line_of_business", "contact_type"]
                scope["source_configuration_sha256"] = session_config.sha(base_configuration)
                scope["analysis_setup"] = req.get("analysis_setup")
                scope["display_unit"] = display_unit
            fp, pins = run_fingerprint(up, pl["answers"], scope, prof, applied)
            source = {"fingerprint": detected["fingerprint"], "run_id": f"RUN-{fp[:16]}", "snapshot_id": f"SNAPSHOT-{fp[:12]}",
                      "dataset_id": f"DATASET-{up.get('source_upload_id') or up['upload_id']}", "grain": up["grain"], "source_rows": detected["rows"]}
            quality = {"non_eligible": up.get("non_eligible"), "reconciliation": up.get("reconciliation")} if up.get("policy_mode") == "disposition_aware" else None
            mid = session_config.primary_metric(applied) if applied else "aht"
            m_scoring = ((applied or {}).get("metrics") or [{}])[0].get("scoring") if mid != "aht" else None
            percent_scoring = (m_scoring or {}).get("scoring_type") == "percent" and mid != "aht"
            score_format = detected.get("score_formats", {}).get(mid)
            supplied_fraction = score_format == "fraction"
            in_rows = up["aggregates"]
            if cockpit:
                in_scope = set(a["scope_lines_of_business"])
                types = set(pl["allowed_contact_types"]) if pl["allowed_contact_types"] is not None else None
                in_rows = [x for x in in_rows if x["line_of_business_id"] in in_scope and scope["start"] <= x["date"] <= scope["end"] and (types is None or x["contact_type"] in types)]
            mrows, m_problem = metric_view.rows(in_rows if cockpit and percent_scoring else up["aggregates"], mid, m_scoring, up["grain"],
                                               score_format=score_format)
            if m_problem:
                message = "This file does not have the columns or scoring this metric needs."
                field = mid
                if percent_scoring:
                    contact = up["grain"] == "contact"
                    column_kind = "score" if supplied_fraction else "pass_flag" if contact else "pass_rate_pct"
                    field = metrics.get(mid)["columns"][up["grain"]][column_kind]
                    if m_problem == "INVALID-PASS-OUTCOME":
                        expected = "0 or 1" if contact else "a percentage from 0 to 100"
                        message = f"Check {field} in the selected data. Each supplied value must be {expected}."
                    elif m_problem == "COLUMN-MISSING":
                        message = f"Percent scoring needs eligible values in {field} for the selected data."
                return self.err(422, "METRIC-UNAVAILABLE", message, [{"field": field, "reason_code": m_problem, "message": message}])
            vs = session_config.metric_versions(applied, mid) if applied else None          # official targets are reported whenever they apply
            tz = applied["account"]["business_timezone"] if applied else None
            optionals = {}
            optional_refs = req.get("optional_uploads")
            daily_aht = cockpit and mid == "aht" and "time" in pl["views"]
            if daily_aht and isinstance(optional_refs, dict) and optional_refs.get("D08"):
                with OPTIONAL_RESOURCES.lock:
                    OPTIONAL_RESOURCES._prune()
            if cockpit and isinstance(optional_refs, dict):
                for code in optional_intake.MODULES:
                    oid = optional_refs.get(code)
                    upload = UPLOADS.get(oid) if isinstance(oid, str) and ID.match(oid) else None
                    if upload and upload.get("role") == "optional" and upload.get("module_id") == code and upload.get("ok"):
                        optionals[code] = upload
            rup = optionals.get("D06")
            roster = None
            if rup:
                fmt = dates.FORMAT_NAMES.get((rup.get("date_settings") or {}).get("date_format"), "mdy")
                roster = insights.roster_lookup(rup["records"], fmt, account=scope["account"])
            component_source = {"csat": "D03", "qa_score": "D04"}.get(mid)
            if "hour_window" in req:
                key = _view_run_key(fp, optionals, "D06")
                if not cockpit or "time" not in pl["views"] or req.get("hour_run") != key:
                    return self.err(422, "HOURLY-SCOPE", "Open the completed What Happened report to compare hours.")
                shifts = session_config.operating_profile(applied).get("shifts", [])
                try:
                    heatmap = hourly.build(up.get("heatmap_contacts"), mid, m_scoring, score_format, scope, tz, roster, shifts, req["hour_window"])
                except ValueError as error:
                    return self.err(422, "HOURLY-FILTER", str(error))
                if heatmap is None:
                    return self.err(422, "HOURLY-UNAVAILABLE", "The report has no timestamped primary contacts.")
                return self.json(200, heatmap | {"comparison_key": key})
            if "component_window" in req:
                key = _view_run_key(fp, optionals, component_source, "D06")
                if not cockpit or "factors" not in calculation_sections or req.get("component_run") != key:
                    return self.err(422, "COMPONENT-SCOPE", "Open the completed Performance Factors report to compare components.")
                try:
                    movement = components.component_movement(mid, up["grain"], in_rows, optionals, scope, tz, roster, req["component_window"])
                except ValueError as error:
                    return self.err(422, "COMPONENT-DATES", str(error))
                if movement is None:
                    return self.err(422, "COMPONENT-UNAVAILABLE", "The component source is unavailable. Run the analysis again.")
                return self.json(200, movement | {"comparison_key": key})
            amb = targets.ambiguity_from_buckets(up["utc_buckets"], tz) if (applied and dates_basis is None and up.get("utc_buckets") is not None) else None
            if "requirements_window" in req:
                if not cockpit or req.get("requirements_run") != fp:
                    return self.err(422, "REQUIREMENTS-SCOPE", "Open the completed analysis before changing the requirements period.")
            if cockpit:
                work_types = pl["allowed_contact_types"]
                eligible_types = set(work_types) if work_types is not None else None
                requirement_rows = (mrows if eligible_types is None else
                                    [row for row in mrows if row["contact_type"] in eligible_types])
                try:
                    requirements = targets.requirements_window(requirement_rows, vs, set(a["scope_lines_of_business"]),
                                                               (scope["start"], scope["end"]), amb, up["grain"], tz,
                                                               dates_basis, req.get("requirements_window"),
                                                               metric_id=mid, scoring=m_scoring, supplied_fraction=supplied_fraction)
                except ValueError as error:
                    return self.err(422, "REQUIREMENTS-DATES", str(error))
                if "requirements_window" in req:
                    return self.json(200, requirements | {"run": fp})
            r = metric_engine.result(mrows, a["scope_lines_of_business"], (scope["start"], scope["end"]), pl["target_value"],
                                  a.get("group_dimension"), scope, source, up.get("exclusions"), quality,
                                  versions=vs, ambiguity=amb, layout=up["grain"], contact_types=pl["allowed_contact_types"], config=applied, business_timezone=tz, dates_basis=dates_basis,
                                  provenance=({"configuration_id": applied["configuration_id"], "configuration_version": applied["configuration_version"], **applied["provenance"], **({"analysis_mapping_sha256": session_config.sha(req["analysis_mapping"]), "target_source": "analysis_setup"} if cockpit and "analysis_mapping" in req else {})} if applied else None),
                                  target_kind=pl["target_kind"], group_dimensions=("line_of_business", "contact_type") if cockpit else None)
            if cockpit:
                r["account_requirements"] = requirements | {"run": fp}
                if mid == "aht" and "time" in pl["views"]:
                    r["daily_references"] = targets.dated_references(
                        applied, vs, r["by_groups"], scope["lines_of_business"], (scope["start"], scope["end"]),
                        amb, up["grain"], tz, dates_basis)
                r["dataset_notices"] = mapping_warnings
                scoped = mrows if percent_scoring else [x for x in mrows if x["line_of_business_id"] in in_scope and scope["start"] <= x["date"] <= scope["end"] and (types is None or x["contact_type"] in types)]
                calendar = optionals.get("D08") if "time" in pl["views"] else None
                if calendar and calendar["date_settings"]["date_format"] != applied["account"].get("date_format", "month_first"):
                    return self.err(422, "DATE-SETTINGS-CHANGED", "Add the calendar file again so Athena can read it using the current date format.")
                if daily_aht or daily_request:
                    daily_run = _view_run_key(fp, optionals, "D08")
                    if daily_request and (not daily_aht or not isinstance(req.get("daily_window"), dict)):
                        return self.err(422, "DAILY-SCOPE", "Open the current Daily trend result before applying a selection.")
                    if daily_request and req.get("daily_run") != daily_run:
                        return self.err(422, "DAILY-SOURCE-CHANGED", "The recorded-event source or analysis changed. Run the analysis again.")
                    try:
                        comparison = _daily_event_comparison(r, scope, applied["account"]["line_of_business_ids"],
                                                             calendar, daily_run, req.get("daily_window"))
                    except ValueError as error:
                        return self.err(422, "DAILY-DATES", str(error))
                    if daily_request:
                        return self.json(200, comparison)
                    r["daily_event_comparison"] = comparison
                ver = session_config.version_at(vs, scope["end"]) if vs else None
                f_target = pl["target_value"] if pl["target_value"] is not None else (ver or {}).get("target")
                f_dir = (ver or {}).get("direction") or (scope["analysis_setup"] or {}).get("direction") or metrics.get(mid)["default_direction"]
                m_unit = metric_view.engine_unit(mid, m_scoring)
                i_dir = f_dir if f_dir in ("lower_is_better", "higher_is_better") else metrics.get(mid)["default_direction"]
                i_label = "average handle time" if mid == "aht" else metrics.get(mid)["label"].lower()
                par = None
                cup = optionals.get("D09")
                if cup:
                    par = constraints.pareto([{"level1": x["record"]["constraint_level_1"], "level2": x["record"]["constraint_level_2"], "controllable": x["record"]["controllable"], "count": x["record"]["count"]}
                                              for x in cup["records"] if x["status"] == "valid" and x["record"]["account_id"] == scope["account"]])
                gap_value, gap_reason = None, "BASELINE-REQUIRED"
                if par and r.get("value") is not None:
                    top = (m_scoring or {}).get("scale_end") if (m_scoring or {}).get("scoring_type") == "scale" else (100 if m_unit == "percent" else None)
                    ceil, gap_reason = metrics.ceiling(mid, f_dir, f_target, top)
                    gap_value = constraints.gap(r["value"], ceil, f_dir) if ceil is not None else None
                cv = None                                                                  # handle time is checked against quality, its default countervailing measure (docs/55)
                if mid == "aht":
                    qa_rows = metric_view.score_rows(in_rows, "qa_score", up["grain"])
                    if qa_rows: cv = {"rows": qa_rows, "label": "quality score", "metric": "qa_score", "direction": "higher_is_better"}
                constraint_findings = []
                if par:
                    for pool in par["pools"]:
                        if pool["vital_few"] and not pool["unclassified"]:
                            constraint_findings.append(constraints.pareto_finding({"pools": [pool]}, mid, i_dir, i_label))
                comp, comp_find = None, None
                cmod, ckind = {"qa_score": ("D04", "qa"), "csat": ("D03", "csat")}.get(mid, (None, None))
                cup2 = optionals.get(cmod)
                component_links = components.aht_links(in_rows, (scope["start"], scope["end"])) if mid == "aht" and up["grain"] == "contact" else None
                if cup2:
                    component_links = components.sample_links(cup2, ckind, scope, tz, percent=percent_scoring and not supplied_fraction)
                    if component_links and supplied_fraction:
                        component_links["outcome"] = "sample_score"
                    comp = components.sample_shortfall(cup2, ckind, scope, tz)
                    comp_find = components.finding(comp, mid, i_label)
                cs = req.get("constraint_setup") if isinstance(req.get("constraint_setup"), dict) else {}
                adoption = cs.get("adoption") if cs.get("adoption") in (0.5, 0.7, 0.8) else 0.8            # the Cockpit offers 50, 70 or 80%; 80% unless changed
                scenario_args = {"lines": par["lines"], "gap": gap_value, "gap_reason": gap_reason,
                                 "adoption": adoption, "baseline": r.get("value"), "direction": f_dir,
                                 "target": f_target if f_dir in ("lower_is_better", "higher_is_better") else None} if par else None
                paired = relationships.build(in_rows, scoped, mid, up["grain"], detected["file"], optionals, scope, tz) \
                    if dates_basis in ("account_business_dates", "declared_business_dates") else []
                action_input_revisions = {code: upload.get("file_sha256") for code, upload in optionals.items()}
                r["insights"] = insights.report(scoped, (scope["start"], scope["end"]), direction=i_dir, metric=mid, label=i_label, roster=roster, unit=m_unit, grain=up["grain"],
                                                extra=constraint_findings + ([comp_find] if comp_find else []), constraints=par, components=comp, cv=cv,
                                                scenario_args=scenario_args, metric_relationships=paired,
                                                action_scope={"account": scope["account"], "lines_of_business": scope["lines_of_business"],
                                                              "contact_types": scope.get("contact_types"), "timezone": tz, "direction": f_dir,
                                                              "run_id": source["run_id"], "configuration_revision": scope["source_configuration_sha256"],
                                                              "source_revision": pins["source_sha256"], "optional_revisions": action_input_revisions,
                                                              "policy_revision": pins["rules_version"], "engine_revision": pins["engine_version"],
                                                              "revision": session_config.sha({"run": fp, "optional": action_input_revisions, "adoption": adoption}),
                                                              "adoption": adoption,
                                                              "room_basis": ceil if par and r.get("value") is not None else None})
                driver_direction = (scope["analysis_setup"] or {}).get("direction", f_dir)
                driver_impact = insights.contact_driver_impact(r["by_groups"]["contact_type"], r["value"], r["count"], driver_direction)
                if driver_impact:
                    r["insights"]["contact_driver_impact"] = driver_impact
                if component_links:
                    r["insights"]["component_links"] = component_links
                if "factors" in calculation_sections:
                    if dates_basis in ("account_business_dates", "declared_business_dates"):
                        r["insights"]["cart_profiles"] = cart_profiles.build(
                            in_rows, scoped, mid, up["grain"], detected.get("score_formats", {}), optionals, scope, tz,
                            r["target_assessment"] if not session_config.has_scoped_targets(applied) else None)
                    movement = components.component_movement(mid, up["grain"], in_rows, optionals, scope, tz, roster)
                    if movement:
                        r["insights"]["component_movement"] = movement | {"comparison_key": _view_run_key(fp, optionals, component_source, "D06")}
                if paired:
                    r["insights"]["metric_relationships"] = paired
                disclosures = []
                for mod in ("D03", "D04"):
                    mup = optionals.get(mod)
                    if mup:
                        disclosures.append(match.disclose(mod, mup["records"], up.get("contact_ids"), (scope["start"], scope["end"])))
                r["match_disclosure"] = disclosures
                count_basis = ("handled_contacts" if mid == "aht" else
                               "contact_weight" if up["grain"] == "agent_day" else
                               "scored_contacts" if supplied_fraction or not percent_scoring else "contacts_with_pass_outcomes")
                r["metric"] = {"metric_id": mid, "label": metrics.get(mid)["label"], "scoring": m_scoring, "unit": m_unit, "direction": f_dir,
                               "count_basis": count_basis,
                               "cutoff_share": metric_view.cutoff_share(in_rows, mid, m_scoring, up["grain"], score_format=score_format)}
                if percent_scoring:
                    r["metric"]["percent_basis"] = ("supplied_fraction" if supplied_fraction else
                                                   "pass_flags" if up["grain"] == "contact" else "weighted_period_rates")
                r["forecast"] = forecast.build(scoped, (scope["start"], scope["end"]), target_versions=vs or [])
                r["stability"] = stability.build(r["forecast"]["history"], mid)
                if calendar:
                    events, diagnostics = _calendar_events(
                        calendar, scope, applied["account"]["line_of_business_ids"], include_recorded_scope=mid == "aht")
                    r["calendar_events"] = events
                    if diagnostics["withheld_rows"]:
                        r["calendar_event_diagnostics"] = diagnostics
                    if events or diagnostics["withheld_rows"]:
                        r["calendar_event_source"] = {"sha256": calendar["file_sha256"], "date_format": calendar["date_settings"]["date_format"]}
                if optionals.get("D07"):
                    r["current_actions"] = _report_actions(optionals["D07"], scope)
                if "time" in pl["views"] and up.get("heatmap_contacts"):
                    shifts = session_config.operating_profile(applied).get("shifts", [])
                    heatmap = hourly.build(up["heatmap_contacts"], mid, m_scoring, score_format, scope, tz, roster, shifts)
                    r["hourly_heatmap"] = heatmap | {"comparison_key": _view_run_key(fp, optionals, "D06")}
                if r["value"] is not None:
                    if "happened" in calculation_sections:
                        r["group_comparison"] = metric_engine.group_comparison(
                            in_rows, scoped, mid, up["grain"], detected.get("score_formats", {}), roster)
                    population = components.component_population(mid, up["grain"], in_rows, optionals, scope, tz)
                    matrix = agent_heatmap.build(mid, up["grain"], in_rows, scoped, m_unit,
                                                 detected.get("score_formats", {}), population, roster)
                    maximum = r.get("hourly_heatmap", {}).get("maximum")
                    if f_dir == "monitor_only" and up["grain"] == "agent_day":
                        source_rows, _ = metric_view.rows(up["aggregates"], mid, m_scoring, up["grain"], score_format=score_format)
                        maximum = max((row["total"] / row["count"] for row in source_rows or ()
                                       if row["count"] and math.isfinite(row["total"])), default=None)
                    r["agent_heatmap"] = matrix | {"maximum": maximum}
                r["datasets_analyzed"] = _datasets_analyzed(up, optionals, r, pl["sections"])
                if full_detail:
                    r["full_detail_sections"] = calculation_sections
                    r["full_detail_views"] = pl["views"]
                    r["full_detail_datasets_analyzed"] = _datasets_analyzed(up, optionals, r, calculation_sections)
            if pl.get("report_panels") is not None:
                r["report_panels"] = pl["report_panels"]
                r["report_questions"] = pl["answers"]["report_questions"]
                if "volume" in r["report_panels"] or full_detail:
                    handled_by_day = {}
                    for row in in_rows:
                        handled_by_day[row["date"]] = handled_by_day.get(row["date"], 0) + row["count"]
                    r["handled_contacts_by_day"] = [
                        {"key": day, "count": count} for day, count in sorted(handled_by_day.items()) if count
                    ]
                    if r.get("evidence"):
                        r["evidence"][0]["numerical_outputs"]["handled_contacts_by_day"] = r["handled_contacts_by_day"]
            if full_detail or "contact-performance" in (pl.get("report_panels") or []):
                handled_by_type = {}
                for row in in_rows:
                    key = row["contact_type"]
                    handled_by_type[key] = handled_by_type.get(key, 0) + row["count"]
                r["handled_contacts_by_type"] = [
                    {"key": key, "count": count} for key, count in sorted(handled_by_type.items()) if count
                ]
                if r.get("evidence"):
                    r["evidence"][0]["numerical_outputs"]["handled_contacts_by_type"] = r["handled_contacts_by_type"]
            r.update(views=pl["views"], sections=pl["sections"], restrictions=pl["restrictions"], assumptions=pl["assumptions"],
                     summary=detected, scope=scope, exclusions=up.get("exclusions"), profile=prof, run_fingerprint=fp, run_pins=pins,
                     configuration=session_config.summary(applied) if applied else None, configuration_status=pl["configuration_status"],
                     target_mode=pl["target_mode"], target_coverage=pl["target_coverage"],
                     data_quality=inspect_response(up) if up.get("policy_mode") == "disposition_aware" else None)
            if cockpit:
                r["analysis_mapping"] = req.get("analysis_mapping")
                r["analysis_setup"] = req.get("analysis_setup")
                r["source_configuration_sha256"] = session_config.sha(base_configuration)
                r["target_mapping_source"] = "analysis_setup"
                r["configuration"] = session_config.summary(base_configuration)
                r["display_unit"] = display_unit
            return self.json(200, r)
        self.err(404, "NOT-FOUND", "Not found.")


def make(port=0):
    return ThreadingHTTPServer(("127.0.0.1", port), H)


if __name__ == "__main__":
    s = make(int(sys.argv[1]) if len(sys.argv) > 1 else 8765)
    print("http://127.0.0.1:%d" % s.server_address[1]); s.serve_forever()
