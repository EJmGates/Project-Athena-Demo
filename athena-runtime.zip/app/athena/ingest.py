"""Upload inspection entry point. Selects the engine from the policy.

- A strict-legacy policy (config/exclusion_policy.json) runs athena/ingest_legacy.py, the Build 01.00 module,
  byte for byte. Selecting it restores Build 01.00 behaviour.
- The disposition-aware policy (config/data_quality_policy.json) runs athena/dq.py.

Tests and servers select a policy explicitly, by argument or by setting ACTIVE_POLICY_PATH.
"""
import json
from pathlib import Path

from athena import dq_contracts, ingest_legacy

ROOT = Path(__file__).resolve().parent.parent
LEGACY_POLICY_PATH = ROOT / "config" / "exclusion_policy.json"
DISPOSITION_POLICY_PATH = ROOT / "config" / "data_quality_policy.json"
ACTIVE_CONFIG_PATH = ROOT / "config" / "active_policy.json"
ALLOWED_POLICIES = {"data_quality_policy.json", "exclusion_policy.json"}


def configured_policy_path(cfg_path=None):
    """The policy named by config/active_policy.json. An unknown or missing name is an error, never a silent default."""
    name = json.loads(Path(cfg_path or ACTIVE_CONFIG_PATH).read_text(encoding="utf-8")).get("policy")
    if name not in ALLOWED_POLICIES:
        raise ValueError(f"active_policy.json must name one of {sorted(ALLOWED_POLICIES)}, not {name!r}")
    return ROOT / "config" / name


ACTIVE_POLICY_PATH = configured_policy_path()
STORAGE_MODES = {"session", "stored_files"}


def configured_storage_mode(cfg_path=None):
    """'session' or 'stored_files'. A file written before this setting existed means Build 02.00 behaviour (stored_files)."""
    mode = json.loads(Path(cfg_path or ACTIVE_CONFIG_PATH).read_text(encoding="utf-8")).get("configuration_storage", "stored_files")
    if mode not in STORAGE_MODES:
        raise ValueError(f"configuration_storage must be one of {sorted(STORAGE_MODES)}, not {mode!r}")
    return mode


def policy(path=None):
    return json.loads(Path(path or ACTIVE_POLICY_PATH).read_text(encoding="utf-8"))


def inspect(name, data, limits, validator, pol=None, **kw):
    pol = pol or policy()
    if dq_contracts.is_legacy(pol):
        res = ingest_legacy.inspect(name, data, limits, validator, pol)
        res["policy_mode"] = "strict_legacy"
        return res
    from athena import dq
    return dq.inspect(name, data, limits, validator, pol, **kw)


def manifest_csv(res):
    if res.get("policy_mode") == "strict_legacy":
        return ingest_legacy.manifest_csv(res)
    from athena import dq
    return dq.manifest_csv(res)
