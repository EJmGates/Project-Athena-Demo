"""Stdlib validator for the JSON Schema subset used by the Athena handoff contracts.

NOT a full JSON Schema implementation. Any keyword it does not implement raises
NotImplementedError, so nothing is silently skipped. Full-validator checks
(`tools/validate_handoff.py --json-schema`) remain not_run until an isolated
dependency setup is approved.
"""
import json, re
from datetime import date, datetime
from pathlib import Path

ANNOTATIONS = {"$schema", "$id", "title", "description", "examples", "$comment", "default", "x-identity"}
KEYWORDS = {"type", "const", "enum", "required", "properties", "additionalProperties", "items",
            "minItems", "maxItems", "uniqueItems", "minLength", "maxLength", "pattern", "minimum",
            "maximum", "exclusiveMinimum", "format", "allOf", "anyOf", "oneOf", "if", "then", "else", "$ref"}
_DT = re.compile(r"\d{4}-\d{2}-\d{2}[Tt]\d{2}:\d{2}:[0-5]\d(?:\.\d+)?(?:[Zz]|[+-](?:[01]\d|2[0-3]):[0-5]\d)")


def _is_date(v):
    try:
        return re.fullmatch(r"\d{4}-\d{2}-\d{2}", v) is not None and bool(date.fromisoformat(v))
    except ValueError:
        return False


def _is_datetime(v):
    if _DT.fullmatch(v) is None:
        return False
    try:
        p = datetime.fromisoformat(v[:-1] + "+00:00" if v[-1] in "Zz" else v)
    except ValueError:
        return False
    return p.tzinfo is not None


def _type_ok(v, t):
    if t == "string": return isinstance(v, str)
    if t == "boolean": return isinstance(v, bool)
    if t == "null": return v is None
    if t == "object": return isinstance(v, dict)
    if t == "array": return isinstance(v, list)
    if t == "integer": return (isinstance(v, int) and not isinstance(v, bool)) or (isinstance(v, float) and v.is_integer())
    if t == "number": return isinstance(v, (int, float)) and not isinstance(v, bool)
    raise NotImplementedError("type " + t)


def _ecma(p):  # ECMA '$' matches only at end; Python '$' also matches before a final newline
    return p[:-1] + r"\Z" if p.endswith("$") and not p.endswith("\\$") else p


class Validator:
    def __init__(self, contracts_dir):
        self.dir = Path(contracts_dir)
        self._cache = {}

    def schema(self, name):
        if name not in self._cache:
            self._cache[name] = json.loads((self.dir / name).read_text(encoding="utf-8"))
        return self._cache[name]

    def errors(self, instance, schema_name):
        out = []
        self._walk(instance, self.schema(schema_name), "$", out, schema_name)
        return out

    def is_valid(self, instance, schema_name):
        return not self.errors(instance, schema_name)

    def _walk(self, v, s, path, out, cur):
        for k in s:
            if k not in KEYWORDS and k not in ANNOTATIONS:
                raise NotImplementedError("unsupported schema keyword: " + k)
        if "$ref" in s:
            name = s["$ref"].split("/")[-1]
            self._walk(v, self.schema(name), path, out, name)
        if "type" in s:
            ts = s["type"] if isinstance(s["type"], list) else [s["type"]]
            if not any(_type_ok(v, t) for t in ts):
                out.append((path, "type")); return
        if "const" in s and not (v == s["const"] and type(v) is type(s["const"])):
            out.append((path, "const"))
        if "enum" in s and v not in s["enum"]:
            out.append((path, "enum"))
        if isinstance(v, str):
            if "minLength" in s and len(v) < s["minLength"]: out.append((path, "minLength"))
            if "maxLength" in s and len(v) > s["maxLength"]: out.append((path, "maxLength"))
            if "pattern" in s and re.search(_ecma(s["pattern"]), v) is None: out.append((path, "pattern"))
            f = s.get("format")
            if f == "date" and not _is_date(v): out.append((path, "format:date"))
            elif f == "date-time" and not _is_datetime(v): out.append((path, "format:date-time"))
            elif f not in (None, "date", "date-time"): raise NotImplementedError("format " + f)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            if "minimum" in s and v < s["minimum"]: out.append((path, "minimum"))
            if "maximum" in s and v > s["maximum"]: out.append((path, "maximum"))
            if "exclusiveMinimum" in s and v <= s["exclusiveMinimum"]: out.append((path, "exclusiveMinimum"))
        if isinstance(v, list):
            if "minItems" in s and len(v) < s["minItems"]: out.append((path, "minItems"))
            if "maxItems" in s and len(v) > s["maxItems"]: out.append((path, "maxItems"))
            if s.get("uniqueItems") and len({json.dumps(i, sort_keys=True) for i in v}) != len(v):
                out.append((path, "uniqueItems"))
            if "items" in s:
                for i, it in enumerate(v): self._walk(it, s["items"], f"{path}[{i}]", out, cur)
        if isinstance(v, dict):
            for r in s.get("required", []):
                if r not in v: out.append((f"{path}.{r}", "required"))
            props = s.get("properties", {})
            for k, sub in props.items():
                if k in v: self._walk(v[k], sub, f"{path}.{k}", out, cur)
            ap = s.get("additionalProperties", True)
            for k in v:
                if k not in props:
                    if ap is False: out.append((f"{path}.{k}", "additionalProperties"))
                    elif isinstance(ap, dict): self._walk(v[k], ap, f"{path}.{k}", out, cur)
        for sub in s.get("allOf", []): self._walk(v, sub, path, out, cur)
        if "anyOf" in s and all(self._sub_errors(v, sub, path, cur) for sub in s["anyOf"]): out.append((path, "anyOf"))
        if "oneOf" in s:
            n = sum(1 for sub in s["oneOf"] if not self._sub_errors(v, sub, path, cur))
            if n != 1: out.append((path, "oneOf"))
        if "if" in s:
            if not self._sub_errors(v, s["if"], path, cur):
                if "then" in s: self._walk(v, s["then"], path, out, cur)
            elif "else" in s: self._walk(v, s["else"], path, out, cur)

    def _sub_errors(self, v, s, path, cur):
        o = []; self._walk(v, s, path, o, cur); return o
