"""Session configuration v0.2.0 and the adapters that produce it (Increment 2).

Inputs: a legacy business profile (v0.1.0), a session configuration (v0.2.0), or a metric dictionary (v0.2.0) given
together with a profile that supplies the account scope. Nothing is stored here; the browser tab holds the active
configuration and the server revalidates it on every request.

Rules kept throughout: an absent target stays absent; periods are start-inclusive and end-exclusive; a unit that is not
the engine's canonical unit is refused, never converted; target, specification limit and control limit stay separate;
the original input is kept by hash and every transformation is recorded; optional fields survive a round trip.
"""
import copy, hashlib, json, re, uuid, math
from datetime import date, timedelta
from pathlib import Path
from zoneinfo import available_timezones
from decimal import Decimal, InvalidOperation

from athena import metric_view, metrics
from athena.dq_contracts import canonical_json
from athena.schema_subset import Validator

ROOT = Path(__file__).resolve().parent.parent
LOCAL = ROOT / "contracts" / "local"
SCHEMA, DICT_SCHEMA = "session_configuration.schema.json", "athena_metric_definitions.v0.2.0.schema.json"
CATALOG = {"aht": {"direction": metrics.get("aht")["default_direction"], "target_rule": metrics.target_rule(metrics.get("aht")["default_direction"])}}   # facts about the metric (from the registry), not about the account
ENGINE_UNITS = {"aht": "seconds"}
ANALYSABLE = ("aht", "csat", "qa_score")           # metrics the Cockpit can analyse today (docs/59: AHT, CSAT and QA first)


def unit_factors(metric_id, scoring):
    """The units a person may enter a target or limit in for this metric, and what each multiplies by to reach the engine's unit."""
    if metric_id == "aht": return DURATION_UNITS
    kind = (scoring or {}).get("scoring_type")
    return {"percent": 1} if kind == "percent" else {"points": 1}


def primary_metric(cfg):
    """The metric this configuration sets targets for (AHT unless the analysis setup chose another)."""
    ids = [m.get("metric_id") for m in (cfg or {}).get("metrics", []) if isinstance(m, dict)]
    return ids[0] if ids else "aht"

DURATION_UNITS = {"seconds": 1, "minutes": 60, "hours": 3600}
DATE_FORMATS = ("month_first", "day_first")           # how slash dates in uploaded files are read; absent means month first
RULE_FOR_DIRECTION = {d: v["target_rule"] for d, v in metrics.DIRECTIONS.items() if "target" in v["requires"]}   # only directions that take a target have a rule
LEGACY_PLACEHOLDERS = {"PROFILE-REPLACE-ME", "ACCOUNT-ID-FROM-YOUR-DATA", "LINE-OF-BUSINESS-ID", "CONTACT-TYPE", "SUBJECT-ID-OF-APPROVER", "REFERENCE-FOR-THE-APPROVAL"}

TEXT = {
    "CONFIG-NOT-JSON": ("The configuration file could not be read.", "Athena needs the JSON template, not a spreadsheet or document.", "Download the template, fill it in and upload it again."),
    "CONFIG-INVALID": ("The configuration is missing or has invalid values.", "Athena will not guess a target, a scope or a definition.", "Fill in the fields listed and upload again."),
    "CONFIG-UNEDITED-TEMPLATE": ("The configuration is the blank template, unchanged.", "A blank template carries no facts about your account.", "Fill in the template and upload it again."),
    "CONFIG-ACCOUNT-MISMATCH": ("The metric dictionary and the profile are for different accounts.", "A configuration describes one account.", "Use a dictionary and a profile for the same account."),
    "CONFIG-VERSION-OVERLAP": ("Two versions of the same metric apply on the same dates.", "Athena cannot tell which target applies.", "Give each version its own dates; a version may end on the day the next one starts."),
    "CONFIG-TARGET-DISAGREEMENT": ("The profile and the metric dictionary give different targets for the same dates.", "Athena will not choose between two official targets.", "Correct one of them so they agree, then upload again."),
    "CONFIG-TIMEZONE-NOT-IANA": ("The business time zone is not a recognised time zone name.", "A time zone such as Asia/Manila decides which day each contact belongs to.", "Use a name such as Asia/Manila. An offset such as +08:00 is not enough."),
    "CONFIG-UNIT-INCOMPATIBLE": ("A metric is measured in a unit Athena does not compare directly.", "Athena does not convert or assume units are equivalent.", "Provide the metric in its canonical unit."),
    "CONFIG-TARGET-NOT-POSITIVE": ("A target of zero or less cannot be met by a handling time.", "A missing target must stay missing, not become zero.", "Remove the target, or give a value above zero."),
    "CONFIG-DIRECTION-RULE-MISMATCH": ("A target rule contradicts the metric's direction.", "Lower is better means a target is met at or below the value.", "Make the rule match the direction."),
    "CONFIG-SCOPE-REQUIRED": ("A metric dictionary has no Lines of Business, contact types, time zone or confirmation.", "Athena needs the account scope to apply it.", "Upload it together with a business profile for the account."),
    "CONFIG-UNSUPPORTED": ("This file is not a configuration Athena recognises.", "Athena reads a session configuration, a business profile, or a dictionary with a profile.", "Start from the template."),
}
WARN = {"CONFIG-VERSION-GAP": "There are dates between two versions where no target applies. Those dates have no target comparison."}


def issue(code, fields=None, **extra):
    p, w, r = TEXT[code]
    i = {"code": code, "problem": p, "why": w, "remedy": r}
    if fields: i["fields"] = sorted(set(fields))
    i.update(extra)
    return i


def sha(obj): return hashlib.sha256(canonical_json(obj)).hexdigest()
def content_sha(cfg): return sha({k: v for k, v in cfg.items() if k != "provenance"})


def with_analysis_mapping(cfg, mapping):
    """Validate a run-local mapping without revising its source configuration."""
    bad = [issue("CONFIG-INVALID", ["analysis_mapping"])]
    if not cfg or not isinstance(mapping, list) or not mapping or len(mapping) > 100:
        return None, bad
    if cfg.get("schema_version") in ("0.3.0", "0.4.0"):
        # Migrated v1 wizard periods remain run-local definitions; validate the
        # existing metric schema without fabricating a v0.2 approval envelope.
        v = Validator(LOCAL)
        v._cache["run_metrics"] = v.schema(SCHEMA)["properties"]["metrics"]
        errs = v.errors(mapping, "run_metrics")
        for i, m in enumerate(mapping):
            for field in ("target", "lower_specification_limit", "upper_specification_limit"):
                if isinstance(m, dict) and field in m and (not isinstance(m[field], (int, float)) or isinstance(m[field], bool) or not math.isfinite(m[field]) or m[field] < 0):
                    errs.append((f"metrics[{i}].{field}", "minimum"))
        if errs: return None, [_schema_issue(errs)]
        effective = copy.deepcopy(cfg); effective["metrics"] = copy.deepcopy(mapping)
        for field in ("line_of_business_ids", "contact_types"):
            effective["account"][field] = sorted({x for m in mapping for x in (m.get("applies_to") or {}).get(field, [])})
        issues, _ = semantic_issues(effective)
        return (None, issues) if issues else (effective, [])
    editable = {"definition_version", "effective_start", "effective_end", "target", "target_rule",
                "lower_specification_limit", "upper_specification_limit", "applies_to"}
    originals = [m for m in cfg["metrics"] if m["metric_id"] == "aht"]
    effective = copy.deepcopy(cfg)
    for rule in mapping:
        if not isinstance(rule, dict) or rule.get("metric_id") != "aht": return None, bad
        immutable = {k: v for k, v in rule.items() if k not in editable}
        if not any(immutable == {k: v for k, v in m.items() if k not in editable} for m in originals):
            return None, bad
    effective["metrics"] = copy.deepcopy(mapping) + [copy.deepcopy(m) for m in cfg["metrics"] if m["metric_id"] != "aht"]
    issues, _ = validate_config(effective)
    return (None, issues) if issues else (effective, [])
def _next_day(d): return (date.fromisoformat(d) + timedelta(days=1)).isoformat()


# Guided configuration is intentionally different from imported JSON.  An operator may
# provide a business-facing name, but technical identity and revision belong to Athena.
# UUID5 makes both deterministic for a given, reviewable configuration content without
# pretending that a typed label is a technical identifier.
_GUIDED_ID_NAMESPACE = uuid.UUID("7d92e0ea-216c-5a76-9c08-20c7d25193a2")
_TECHNICAL_CONFIGURATION_ID = re.compile(r"^CFG-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
_TECHNICAL_REVISION = re.compile(r"^REV-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


def _guided_basis(form, label=None):
    """The business content that determines a generated identity or revision.

    Server provenance and revision history describe prior processing, not a new business
    definition, so neither should cause a no-op edit to acquire a different revision.
    """
    basis = copy.deepcopy(form)
    for key in ("configuration_id", "configuration_version", "provenance", "prior_provenance", "prior_snapshot", "business_label"):
        basis.pop(key, None)
    extensions = basis.get("extensions")
    if isinstance(extensions, dict):
        extensions.pop("revision_history", None)
        extensions.pop("business_label", None)
        if not extensions:
            basis.pop("extensions", None)
    if label:
        basis["business_label"] = label
    return basis


def _guided_identity_basis(basis):
    """Return the stable, operator-owned part of a guided configuration.

    Target periods are deliberately excluded. Changing a target is a new
    revision of the same configuration, not a different configuration.
    """
    identity = copy.deepcopy(basis)
    identity.pop("metrics", None)
    return identity


def _generated_id(basis):
    return "CFG-" + str(
        uuid.uuid5(
            _GUIDED_ID_NAMESPACE,
            "configuration:" + content_sha(_guided_identity_basis(basis)),
        )
    )


def _generated_revision(basis):
    return "REV-" + str(uuid.uuid5(_GUIDED_ID_NAMESPACE, "revision:" + content_sha(basis)))


def operating_profile_issues(profile):
    """Strict descriptive context only: never a population or calendar rule."""
    if not isinstance(profile, dict): return ["operating_profile"]
    strings = {"project_name": 128, "account_name": 128, "industry": 128, "current_phase": 128,
               "service_scope": 2000, "support_notes": 2000, "account_background": 8000}
    lists = {"lines_of_business", "contact_channels", "regions_supported", "service_languages", "markets_served", "delivery_sites"}
    bad = ["operating_profile." + k for k in set(profile) - set(strings) - lists - {"contact_flow", "hours", "shifts"}]
    def text(v, limit, narrative=False):
        forbidden = r"[\x00-\x08\x0b-\x1f\x7f]" if narrative else r"[\x00-\x1f\x7f]"
        return isinstance(v, str) and bool(v.strip()) and len(v) <= limit and not re.search(forbidden, v)
    for key, limit in strings.items():
        if key in profile and not text(profile[key], limit, key in ("service_scope", "support_notes", "account_background")): bad.append("operating_profile." + key)
    for key in lists:
        if key not in profile: continue
        value = profile[key]
        if not isinstance(value, list) or len(value) > 50 or not all(text(v, 128) for v in value) or len(set(value)) != len(value): bad.append("operating_profile." + key)
    if "contact_flow" in profile and profile["contact_flow"] not in ("inbound", "outbound", "blended"): bad.append("operating_profile.contact_flow")
    def interval(value, shift=False):
        if not isinstance(value, dict): return False
        keys = {"days", "start", "end", "ends_next_day"} | ({"name"} if shift else {"mode"})
        if not shift and value == {"mode": "24_7"}: return True
        if set(value) != keys or (not shift and value.get("mode") != "weekly"): return False
        if shift and not text(value.get("name"), 128): return False
        days = value.get("days")
        if not isinstance(days, list) or not 1 <= len(days) <= 7 or not all(type(v) is int and 0 <= v <= 6 for v in days) or len(set(days)) != len(days): return False
        start, end, overnight = value.get("start"), value.get("end"), value.get("ends_next_day")
        if not all(isinstance(v, str) and re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", v) for v in (start, end)) or type(overnight) is not bool: return False
        return end <= start if overnight else end > start
    if "hours" in profile and not interval(profile["hours"]): bad.append("operating_profile.hours")
    if "shifts" in profile:
        shifts = profile["shifts"]
        if not isinstance(shifts, list) or len(shifts) > 50 or not all(interval(v, True) for v in shifts): bad.append("operating_profile.shifts")
        elif len({v["name"] for v in shifts}) != len(shifts): bad.append("operating_profile.shifts")
    return bad


def operating_profile(cfg):
    return cfg.get("operating_profile", (cfg.get("extensions") or {}).get("operating_profile", {}))


def from_session_setup(obj, stored=False):
    """Minimal account setup; technical provenance never implies human approval."""
    if not isinstance(obj, dict): return None, [issue("CONFIG-INVALID", ["session_setup"])], []
    allowed = {"schema_version", "account", "draft_id", "configuration_id", "configuration_version"}
    if stored: allowed.add("provenance")
    bad = set(obj) - allowed
    a = obj.get("account")
    version = obj.get("schema_version")
    if version not in ("0.3.0", "0.4.0"): bad.add("schema_version")
    if version == "0.4.0":
        allowed.add("operating_profile")
        bad.discard("operating_profile")
        if "operating_profile" in obj: bad.update(operating_profile_issues(obj["operating_profile"]))
    if not isinstance(a, dict): bad.add("account"); a = {}
    bad.update("account." + k for k in set(a) - {"account_id", "business_timezone", "coverage_start", "coverage_end"} - ({"date_format"} if version == "0.4.0" else set()))
    if "date_format" in a and a["date_format"] not in DATE_FORMATS: bad.add("account.date_format")
    aid, tz = a.get("account_id"), a.get("business_timezone")
    if not isinstance(aid, str) or not aid.strip() or len(aid) > 128 or re.search(r"[\r\n]", aid): bad.add("account.account_id")
    if not isinstance(tz, str) or not 1 <= len(tz) <= 64: bad.add("account.business_timezone")
    for key in ("coverage_start", "coverage_end"):
        if key in a and not _isdate(a[key]): bad.add("account." + key)
    if all(_isdate(a.get(k)) for k in ("coverage_start", "coverage_end")) and a["coverage_end"] <= a["coverage_start"]: bad.add("account.coverage_end")
    if "draft_id" in obj:
        try:
            if not isinstance(obj["draft_id"], str) or len(obj["draft_id"]) > 64: raise ValueError()
            uuid.UUID(obj["draft_id"])
        except (ValueError, TypeError, AttributeError): bad.add("draft_id")
    for key, pattern in (("configuration_id", _TECHNICAL_CONFIGURATION_ID), ("configuration_version", _TECHNICAL_REVISION)):
        if key in obj and not isinstance(obj[key], str) or key in obj and not pattern.fullmatch(obj[key]): bad.add(key)
    if bad:
        reasons = {field: ("profile-hours" if field.endswith(".hours") else "profile-shifts" if field.endswith(".shifts") else "profile-value")
                   for field in bad if field.startswith("operating_profile")}
        return None, [issue("CONFIG-INVALID", list(bad), **({"field_reasons": reasons} if reasons else {}))], []
    if tz not in available_timezones(): return None, [issue("CONFIG-TIMEZONE-NOT-IANA", ["account.business_timezone"])], []
    basis = {"schema_version": version, "account": copy.deepcopy(a)}
    if "operating_profile" in obj: basis["operating_profile"] = copy.deepcopy(obj["operating_profile"])
    cfg = copy.deepcopy(obj)
    cfg["configuration_id"] = obj.get("configuration_id") or "CFG-" + str(uuid.uuid5(_GUIDED_ID_NAMESPACE, "setup:" + obj.get("draft_id", sha(basis))))
    revision = _generated_revision(basis)
    if stored and obj.get("configuration_version") != revision: return None, [issue("CONFIG-INVALID", ["configuration_version"])], []
    cfg["configuration_version"] = revision
    expected = _prov("session_setup", version, basis, [{"rule_id": "SESSION-SETUP-" + version}])
    if stored and obj.get("provenance") != expected: return None, [issue("CONFIG-INVALID", ["provenance"])], []
    cfg["provenance"] = expected
    return cfg, [], []


def for_analysis(cfg, detected, answers, setup=None):
    """Resolve dataset scope and optional cockpit rules without changing source bytes."""
    if not cfg: return None, [issue("CONFIG-INVALID", ["configuration"])], []
    effective, warns = copy.deepcopy(cfg), []
    if detected:
        a = effective["account"]
        actual = (detected.get("accounts") or [a["account_id"]])[0]
        if actual != a["account_id"]:
            warns.append({"code": "DATASET-ACCOUNT-DIFFERENT", "text": "The dataset account differs from your setup. Check that this is the dataset you intended to analyse.", "configured_account": a["account_id"], "dataset_account": actual})
        a["account_id"] = actual
        for field, source in (("line_of_business_ids", "line_of_business_id"), ("contact_types", "contact_type")):
            a[field] = list(detected.get("distinct", {}).get(source, []))
    effective.setdefault("metrics", [])
    retained = []
    for m in effective["metrics"]:
        scope = m.get("applies_to") or {}
        if any(not set(vals) <= set(effective["account"].get(field, [])) for field, vals in scope.items()):
            warns.append({"code": "TARGET-SCOPE-UNMATCHED", "text": "An imported target names groups absent from this dataset. That target is not applied; observed results remain available."})
        else: retained.append(m)
    effective["metrics"] = retained
    if setup is None: return effective, [], warns
    bad = lambda field: (None, [issue("CONFIG-INVALID", [field])], warns)
    keys = {"metric_id", "direction", "unit", "scoring", "target", "lower_specification_limit", "upper_specification_limit", "periods"}
    mid = setup.get("metric_id") if isinstance(setup, dict) else None
    spec = metrics.get(mid) if mid in ANALYSABLE else None
    if not isinstance(setup, dict) or set(setup) - keys or spec is None or setup.get("direction") not in spec["directions"]: return bad("analysis_setup")
    fields = {"target", "lower_specification_limit", "upper_specification_limit"}
    scoring = setup.get("scoring")
    if mid != "aht" and metrics.check_scoring(scoring): return bad("analysis_setup.scoring")
    score_format = (detected or {}).get("score_formats", {}).get(mid)
    if score_format == "fraction" and scoring["scoring_type"] != "percent":
        return bad("analysis_setup.scoring")
    if mid == "aht" and scoring is not None: return bad("analysis_setup.scoring")
    factors = unit_factors(mid, scoring)
    unit = setup.get("unit", next(iter(factors)))
    if not isinstance(unit, str) or unit not in factors: return bad("analysis_setup.unit")
    factor = factors[unit]
    setup = copy.deepcopy(setup)
    periods = setup.get("periods", [])
    if not isinstance(periods, list) or len(periods) > 100: return bad("analysis_setup.periods")
    for n, p in enumerate([setup] + periods):
        if not isinstance(p, dict): return bad("analysis_setup.periods")
        if n and (set(p) - (fields | {"effective_start", "effective_end"}) or not _isdate(p.get("effective_start")) or not fields.intersection(p)): return bad("analysis_setup.periods")
        if n and "effective_end" in p and (not _isdate(p["effective_end"]) or p["effective_end"] <= p["effective_start"]): return bad("analysis_setup.periods")
        for f in fields & set(p):
            v = p[f]
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0 or f == "target" and v == 0: return bad("analysis_setup." + f)
        if "target" in p and setup["direction"] not in RULE_FOR_DIRECTION: return bad("analysis_setup.target")
        if p.get("lower_specification_limit", 0) > p.get("upper_specification_limit", math.inf): return bad("analysis_setup.lower_specification_limit")
        for f in fields & set(p):
            try: converted = float(Decimal(str(p[f])) * Decimal(str(factor)))
            except (InvalidOperation, OverflowError, ValueError): return bad("analysis_setup." + f)
            if not math.isfinite(converted): return bad("analysis_setup." + f)
            p[f] = converted
    ordered = sorted(periods, key=lambda p: p["effective_start"])
    for p, q in zip(ordered, ordered[1:]):
        if p.get("effective_end", "9999-12-31") > q["effective_start"]: return bad("analysis_setup.periods")
    span = (answers or {}).get("scope_period", {
        "start": (detected or {}).get("date_min"), "end": (detected or {}).get("date_max")
    }) or {}
    start, end = span.get("start"), span.get("end")
    if not periods and (not _isdate(start) or not _isdate(end)):
        effective["metrics"] = []
        return effective, [], warns
    rules = periods or [{**{f: setup[f] for f in fields if f in setup}, "effective_start": start, "effective_end": _next_day(end)}]
    effective["metrics"] = [{"metric_id": mid, "canonical_unit": metric_view.engine_unit(mid, scoring), "direction": setup["direction"], **({"scoring": copy.deepcopy(scoring)} if scoring else {}),
                             "definition_version": ("period:" if periods else "analysis-applicability:") + sha({**p, "metric_id": mid, "scoring": scoring})[:16], **copy.deepcopy(p), **({"target_rule": RULE_FOR_DIRECTION[setup["direction"]]} if "target" in p else {})} for p in rules]
    return effective, [], warns


# ---------- version resolution ----------
def scope_of(m):
    """None for an account-level version; otherwise the explicit scope the version names."""
    a = m.get("applies_to")
    if not a: return None
    return ("line_of_business_ids", tuple(sorted(a["line_of_business_ids"]))) if "line_of_business_ids" in a else ("contact_types", tuple(sorted(a["contact_types"])))


def metric_versions(cfg, metric_id="aht"):
    """Account-level versions only. A target for a subgroup is never assumed from these."""
    return sorted((m for m in cfg.get("metrics", []) if m["metric_id"] == metric_id and scope_of(m) is None), key=lambda m: m["effective_start"])


def scoped_versions(cfg, group_by, key, metric_id="aht"):
    """Versions that explicitly name this line_of_business (group_by 'line_of_business') or contact type (group_by 'contact_type')."""
    field = "line_of_business_ids" if group_by == "line_of_business" else "contact_types"
    return sorted((m for m in cfg["metrics"] if m["metric_id"] == metric_id and key in (m.get("applies_to") or {}).get(field, [])), key=lambda m: m["effective_start"])


def version_at(versions, day):
    """The version in force on a business date, or None. Start-inclusive, end-exclusive."""
    for v in versions:
        if v["effective_start"] <= day and (v.get("effective_end") is None or day < v["effective_end"]): return v
    return None


def boundaries(versions):
    return sorted({d for v in versions for d in (v["effective_start"], v.get("effective_end")) if d})


def rule_for(v):
    return v.get("target_rule") or RULE_FOR_DIRECTION.get(v["direction"])


# ---------- validation ----------
def blank_template():
    """Every required fact is empty, so an unedited template can never be applied."""
    return {"schema_version": "0.2.0", "configuration_id": "", "configuration_version": "",
            "account": {"account_id": "", "line_of_business_ids": [], "contact_types": [], "business_timezone": ""},
            "metrics": [{"metric_id": "", "definition_version": "", "effective_start": "", "direction": "", "canonical_unit": ""}],
            "confirmation": {"confirmed_by": "", "confirmed_at": "", "confirmation_reference": ""},
            "provenance": {"inputs": [], "transformations": []}}


TEMPLATE_HELP = {
    "configuration_id": "Technical identifier generated by Athena for a new guided configuration. Keep an imported value as supplied.",
    "configuration_version": "Technical revision generated by Athena for a new guided configuration. Keep an imported value as supplied; do not author one in the guided form.",
    "account.account_id": "Must match the account in your data file exactly.", "account.line_of_business_ids": "Every line_of_business this contract covers.",
    "account.contact_types": "Every contact type this contract covers.", "account.business_timezone": "A time zone name such as Asia/Manila.",
    "metrics": "One performance-rule period for each distinct target or limit. Add a period when a target or limit changes.",
    "metrics[].effective_start": "First date this performance-rule period applies, as YYYY-MM-DD.",
    "metrics[].effective_end": "The date the next performance-rule period starts. Leave it out for the current period.",
    "metrics[].direction": "lower_is_better, higher_is_better, within_bounds or monitor_only.",
    "metrics[].target": "Leave it out if there is no target. It is never treated as zero.",
    "metrics[].upper_specification_limit": "The approved upper limit, if there is one. Separate from the target.",
    "metrics[].canonical_unit": "The unit the figures are measured in. Athena compares seconds for handle time.",
    "confirmation": "Who approved these facts, when, and where the approval is recorded.",
}


REASON_TEXT = {"required": "required", "enum": "choose one", "type": "wrong kind of value", "format:date": "not a real date", "format:date-time": "not a real date and time", "pattern": "not valid",
               "minLength": "required", "minItems": "add at least one", "minimum": "too small", "exclusiveMinimum": "must be above zero", "additionalProperties": "not recognised", "const": "not valid"}


def _isdate(x):
    try: return isinstance(x, str) and bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}", x)) and bool(date.fromisoformat(x))
    except ValueError: return False


def _schema_issue(errs, extra=None):
    """One CONFIG-INVALID issue naming each field and why it failed, so a form can show the reason beside the field."""
    reasons = {}
    for path, reason in errs:
        reasons.setdefault(path.replace("$.", ""), reason)
    for f, r in (extra or {}).items(): reasons.setdefault(f, r)
    return issue("CONFIG-INVALID", list(reasons), field_reasons=dict(reasons))


def semantic_issues(cfg, defensive=False):
    """Rules that go beyond the schema. With defensive=True it also works on a form that is still being filled in:
    it checks only what is present and well formed, so a guided form can be told about a bad time zone or an overlap
    before every required field exists. The same checks, in the same words, serve both cases."""
    issues, warns = [], []
    acct = cfg.get("account") if isinstance(cfg.get("account"), dict) else {}
    tz = acct.get("business_timezone")
    if isinstance(tz, str) and tz and tz not in available_timezones(): issues.append(issue("CONFIG-TIMEZONE-NOT-IANA", ["account.business_timezone"]))
    if _isdate(acct.get("coverage_start")) and _isdate(acct.get("coverage_end")) and acct["coverage_end"] <= acct["coverage_start"]: issues.append(issue("CONFIG-INVALID", ["account.coverage_end"]))
    raw = cfg.get("metrics") if isinstance(cfg.get("metrics"), list) else []
    good = [(i, m) for i, m in enumerate(raw) if isinstance(m, dict) and isinstance(m.get("metric_id"), str) and m["metric_id"] and _isdate(m.get("effective_start"))
            and isinstance(m.get("direction"), str) and isinstance(m.get("canonical_unit"), str) and isinstance(m.get("definition_version"), str)]
    for i, m in good:
        if _isdate(m.get("effective_end")) and m["effective_end"] <= m["effective_start"]: issues.append(issue("CONFIG-INVALID", [f"metrics[{i}].effective_end"]))
        unit = ENGINE_UNITS.get(m["metric_id"])
        if unit and m["canonical_unit"] != unit: issues.append(issue("CONFIG-UNIT-INCOMPATIBLE", [f"metrics[{i}].canonical_unit"]))
        tg = m.get("target")
        if m["metric_id"] == "aht" and isinstance(tg, (int, float)) and not isinstance(tg, bool) and tg <= 0: issues.append(issue("CONFIG-TARGET-NOT-POSITIVE", [f"metrics[{i}].target"]))
        lo, hi = m.get("lower_specification_limit"), m.get("upper_specification_limit")
        if isinstance(lo, (int, float)) and isinstance(hi, (int, float)) and lo > hi: issues.append(issue("CONFIG-INVALID", [f"metrics[{i}].lower_specification_limit"]))
        r, d = m.get("target_rule"), m["direction"]
        if r and r != "none" and d in RULE_FOR_DIRECTION and r != RULE_FOR_DIRECTION[d]: issues.append(issue("CONFIG-DIRECTION-RULE-MISMATCH", [f"metrics[{i}].target_rule"]))
        a = m.get("applies_to")
        if a is None: continue
        if not isinstance(a, dict) or len(a) != 1 or not (set(a) <= {"line_of_business_ids", "contact_types"}): issues.append(issue("CONFIG-INVALID", [f"metrics[{i}].applies_to"])); continue
        field = "line_of_business_ids" if "line_of_business_ids" in a else "contact_types"
        known = acct.get(field) if isinstance(acct.get(field), list) else []
        if isinstance(a[field], list) and not set(a[field]) <= set(known): issues.append(issue("CONFIG-INVALID", [f"metrics[{i}].applies_to"]))
    safe = {"metrics": [m for _, m in good]}; idx = {id(m): i for i, m in good}
    def overlap(a, b, key):
        issues.append(issue("CONFIG-VERSION-OVERLAP", [f"metrics[{idx[id(a)]}].effective_end", f"metrics[{idx[id(b)]}].effective_start"], scope=key))
    scoped_ok = [(m, k) for _, m in good for k in [m.get("applies_to")] if isinstance(k, dict) and len(k) == 1]
    for field, group_by in (("line_of_business_ids", "line_of_business"), ("contact_types", "contact_type")):
        for mid, key in sorted({(m["metric_id"], k) for m, a in scoped_ok for k in (a.get(field) if isinstance(a.get(field), list) else [])}):
            vs = scoped_versions(safe, group_by, key, mid)
            for a, b in zip(vs, vs[1:]):
                if not _isdate(a.get("effective_end")) or a["effective_end"] > b["effective_start"]: overlap(a, b, key); break
    for mid in sorted({m["metric_id"] for _, m in good}):
        vs = [m for m in metric_versions(safe, mid)]
        for a, b in zip(vs, vs[1:]):
            end = a.get("effective_end")
            if not _isdate(end) or end > b["effective_start"]: overlap(a, b, None); break
            if end < b["effective_start"]: warns.append({"code": "CONFIG-VERSION-GAP", "text": WARN["CONFIG-VERSION-GAP"], "metric_id": mid, "from": end, "to": b["effective_start"]})
    ids = [cfg.get("configuration_id"), acct.get("account_id"), (cfg.get("confirmation") or {}).get("confirmed_by") if isinstance(cfg.get("confirmation"), dict) else None]
    if any(x in LEGACY_PLACEHOLDERS for x in ids if isinstance(x, str)): issues.append(issue("CONFIG-UNEDITED-TEMPLATE"))
    return issues, warns


def validate_config(cfg, validator=None):
    """Schema and semantic checks. Returns (issues, warnings)."""
    if isinstance(cfg, dict) and cfg.get("schema_version") in ("0.3.0", "0.4.0"):
        _, issues, warns = from_session_setup(cfg, stored=True)
        return issues, warns
    v = validator or Validator(LOCAL)
    errs = v.errors(cfg, SCHEMA)
    if errs:
        return [_schema_issue(errs)], []
    issues, warnings = semantic_issues(cfg)
    if isinstance(cfg.get("extensions"), dict) and "operating_profile" in cfg["extensions"]:
        fields = operating_profile_issues(cfg["extensions"]["operating_profile"])
        if fields: issues.append(issue("CONFIG-INVALID", fields))
    return issues, warnings


# ---------- adapters ----------
def _prov(kind, schema_version, obj, rules):
    return {"inputs": [{"kind": kind, "schema_version": schema_version, "sha256": sha(obj)}], "transformations": rules}


def from_legacy_profile(profile, validator=None):
    """Legacy business profile v0.1.0 -> session configuration v0.2.0. Returns (config or None, issues, warnings)."""
    vv = validator or Validator(ROOT / "vendor" / "handoff" / "contracts")
    p = copy.deepcopy(profile)
    errs = vv.errors(p, "business_profile.schema.json")
    if errs: return None, [issue("CONFIG-INVALID", [e[0].replace("$.", "") for e in errs])], []
    md = p["metric_definition"]; mid = md["metric_id"]; cat = CATALOG.get(mid)
    if cat is None: return None, [issue("CONFIG-UNSUPPORTED")], []
    t = [{"rule_id": "LEGACY-PROFILE-TO-CONFIGURATION-0.2.0", "from_path": "$", "to_path": "$"},
         {"rule_id": "DEFAULT-DIRECTION-FROM-CATALOG", "from_path": "metric_definition.metric_id", "to_path": "metrics[0].direction", "note": f"{mid} is {cat['direction']}"}]
    m = {"metric_id": mid, "definition_version": f"profile:{p['profile_version']}", "effective_start": p["effective_start"], "direction": cat["direction"],
         "canonical_unit": md["canonical_unit"], "aggregation_rule": md["definition"], "handling_components": md["handling_components"]}
    if "target_seconds" in p:
        m["target"] = p["target_seconds"]; m["target_rule"] = cat["target_rule"]
        t.append({"rule_id": "TARGET-SECONDS-TO-TARGET", "from_path": "target_seconds", "to_path": "metrics[0].target"})
    if "effective_end" in p:
        m["effective_end"] = _next_day(p["effective_end"])
        t.append({"rule_id": "LEGACY-EFFECTIVE-END-INCLUSIVE-TO-EXCLUSIVE", "from_path": "effective_end", "to_path": "metrics[0].effective_end", "note": f"the legacy profile's last day is included; the exclusive end is the next calendar day in {p['business_timezone']}"})
    if "minimum_meaningful_effect_seconds" in p: m["materiality_seconds"] = p["minimum_meaningful_effect_seconds"]
    cfg = {"schema_version": "0.2.0", "configuration_id": p["profile_id"], "configuration_version": p["profile_version"],
           "account": {"account_id": p["account_id"], "line_of_business_ids": p["line_of_business_ids"], "contact_types": p["contact_types"], "business_timezone": p["business_timezone"]},
           "metrics": [m], "confirmation": {"confirmed_by": p["confirmed_by"], "confirmed_at": p["confirmed_at"], "confirmation_reference": p["confirmation_reference"]},
           "provenance": _prov("business_profile", p["schema_version"], profile, t)}
    if "guardrail_definitions" in p: cfg["extensions"] = {"legacy_profile": {"guardrail_definitions": p["guardrail_definitions"]}}
    issues, warns = validate_config(cfg)
    return (None if issues else cfg), issues, warns


def merge_dictionary_and_profile(dictionary, profile, validator=None):
    """Metric dictionary v0.2.0 for the metrics, a legacy profile for the account scope and confirmation."""
    base, issues, warns = from_legacy_profile(profile, validator)
    if base is None: return None, issues, warns
    dv = Validator(LOCAL); e = dv.errors(dictionary, DICT_SCHEMA)
    if e: return None, [issue("CONFIG-INVALID", [x[0].replace("$.", "") for x in e])], []
    if dictionary["account_id"] != base["account"]["account_id"]: return None, [issue("CONFIG-ACCOUNT-MISMATCH")], []
    ptarget = next((m.get("target") for m in base["metrics"] if "target" in m), None)
    pend = base["metrics"][0].get("effective_end"); pstart = base["metrics"][0]["effective_start"]
    if ptarget is not None:
        for m in dictionary["metrics"]:
            if m["metric_id"] != base["metrics"][0]["metric_id"] or "target" not in m: continue
            overlaps = (m.get("effective_end") is None or m["effective_end"] > pstart) and (pend is None or m["effective_start"] < pend)
            if overlaps and m["target"] != ptarget: return None, [issue("CONFIG-TARGET-DISAGREEMENT", ["target"])], []
    metrics = []
    for m in dictionary["metrics"]:
        x = {k: v for k, v in m.items() if k in ("metric_id", "definition_version", "effective_start", "effective_end", "direction", "canonical_unit", "target", "target_rule",
                                                    "lower_specification_limit", "upper_specification_limit", "numerator_id", "denominator_id", "aggregation_rule", "guardrail", "bounded_min", "bounded_max")}
        metrics.append(x)
    prof_def = base["metrics"][0]
    for x in metrics:
        if x["metric_id"] == prof_def["metric_id"] and "handling_components" in prof_def: x["handling_components"] = prof_def["handling_components"]
    cfg = copy.deepcopy(base); cfg["metrics"] = metrics
    cfg["provenance"] = {"inputs": base["provenance"]["inputs"] + [{"kind": "metric_dictionary", "schema_version": dictionary["schema_version"], "sha256": sha(dictionary)}],
                         "transformations": [{"rule_id": "DICTIONARY-PLUS-PROFILE-TO-CONFIGURATION-0.2.0", "from_path": "$", "to_path": "$"},
                                             {"rule_id": "SCOPE-FROM-PROFILE", "from_path": "business_profile", "to_path": "account"},
                                             {"rule_id": "METRICS-FROM-DICTIONARY", "from_path": "metric_dictionary.metrics", "to_path": "metrics"}]}
    issues, warns = validate_config(cfg)
    return (None if issues else cfg), issues, warns


def from_guided_form(form, *, require_preparer=True):
    """Guided form -> session configuration v0.2.0. The page sends the configuration without provenance; the server stamps it.

    Provenance is truthful: the one input recorded is the form itself, identified by a reproducible hash of its content
    (the same hash for the same content), never a source document that does not exist. When an existing configuration is
    edited, its earlier provenance is carried in front, unchanged, through prior_provenance. Every supported contract
    field passes through untouched."""
    if not isinstance(form, dict): return None, [issue("CONFIG-INVALID")], []
    f = copy.deepcopy(form)
    prior = f.pop("prior_provenance", None)
    prior_snapshot = f.pop("prior_snapshot", None)
    # Editing a previously validated import retains its historical confirmation;
    # it does not require the operator to add a new preparer identity.
    if isinstance(prior_snapshot, dict) and prior_snapshot.get("schema_version") == "0.2.0":
        prior_issues, _ = validate_config(prior_snapshot)
        if not prior_issues and f.get("confirmation") == prior_snapshot.get("confirmation"):
            require_preparer = False
    label = f.pop("business_label", None)
    # Older guided pages used configuration_id as their visible name.  Treat any
    # nontechnical value as that label instead of letting it become the identifier.
    incoming_id = f.get("configuration_id")
    incoming_revision = f.get("configuration_version")
    prior_rules = (prior or {}).get("transformations", []) if isinstance(prior, dict) else []
    was_created_from_a_guided_form = any(
        isinstance(rule, dict) and rule.get("rule_id") == "GUIDED-FORM-TO-CONFIGURATION-0.2.0"
        for rule in prior_rules
    )
    # Identity syntax alone cannot establish where it came from: an imported file
    # is allowed to use a CFG-shaped ID or even a REV-shaped version. Provenance is
    # the reliable distinction. Such a file keeps its supplied identity until an
    # actual guided edit replaces the revision under Athena's control.
    has_imported_identity = bool(
        prior and isinstance(incoming_id, str) and incoming_id
        and isinstance(incoming_revision, str) and incoming_revision
        and not was_created_from_a_guided_form
    )
    if not has_imported_identity and not isinstance(label, str) and isinstance(incoming_id, str) and incoming_id and not _TECHNICAL_CONFIGURATION_ID.fullmatch(incoming_id):
        label = incoming_id
    if not isinstance(label, str): label = ""
    label = label.strip()
    if not has_imported_identity and not _TECHNICAL_CONFIGURATION_ID.fullmatch(str(incoming_id or "")):
        f["configuration_id"] = ""
    if not has_imported_identity and not _TECHNICAL_REVISION.fullmatch(str(f.get("configuration_version") or "")):
        f["configuration_version"] = ""
    basis = _guided_basis(f, label)
    has_existing_technical_identity = bool(_TECHNICAL_CONFIGURATION_ID.fullmatch(str(f.get("configuration_id") or "")))
    if not has_existing_technical_identity and not has_imported_identity:
        f["configuration_id"] = _generated_id(basis)
    if not has_existing_technical_identity and not has_imported_identity:
        f["configuration_version"] = _generated_revision(basis)
    elif isinstance(prior_snapshot, dict):
        # Existing configurations keep their revision through a no-op guided
        # round-trip. The client supplies the pre-edit snapshot solely for this
        # comparison. An imported file gains a system revision only after a real
        # edit, while retaining its imported identifier and a trace of the value it
        # replaced.
        previous_label = ((prior_snapshot.get("extensions") or {}).get("business_label")
                          if isinstance(prior_snapshot.get("extensions"), dict) else "")
        if content_sha(_guided_basis(prior_snapshot, previous_label)) != content_sha(basis):
            old_revision = f["configuration_version"]
            f["configuration_version"] = _generated_revision(basis)
            if has_imported_identity:
                extensions = f.setdefault("extensions", {})
                history = extensions.setdefault("revision_history", [])
                entry = {"replaced_version": old_revision,
                         "replaced_content_sha256": content_sha(_guided_basis(prior_snapshot, previous_label))}
                if entry not in history: history.append(entry)
    if label:
        f.setdefault("extensions", {})["business_label"] = label
    if "provenance" in f: return None, [issue("CONFIG-INVALID", ["provenance"], field_reasons={"provenance": "not recognised"})], []
    h = content_sha(f)
    inputs = [x for x in (prior or {}).get("inputs", [])] if isinstance(prior, dict) and isinstance(prior.get("inputs"), list) else []
    trans = [x for x in (prior or {}).get("transformations", [])] if isinstance(prior, dict) and isinstance(prior.get("transformations"), list) else []
    if not any(isinstance(x, dict) and x.get("sha256") == h for x in inputs): inputs.append({"kind": "guided_form", "schema_version": "0.2.0", "sha256": h})
    if prior: trans.append({"rule_id": "GUIDED-FORM-EDIT-OF-EXISTING-CONFIGURATION", "from_path": "$", "to_path": "$"})
    trans.append({"rule_id": "GUIDED-FORM-TO-CONFIGURATION-0.2.0", "from_path": "$", "to_path": "$"})
    for i, m in enumerate(f.get("metrics") or []):
        if isinstance(m, dict) and m.get("metric_id") == "aht" and m.get("effective_end"):
            trans.append({"rule_id": "GUIDED-FORM-LAST-DAY-TO-EXCLUSIVE-END", "from_path": f"metrics[{i}].last_day", "to_path": f"metrics[{i}].effective_end"})
    if isinstance(f.get("account"), dict) and f["account"].get("coverage_end"):
        trans.append({"rule_id": "GUIDED-FORM-LAST-DAY-TO-EXCLUSIVE-END", "from_path": "account.coverage_last_day", "to_path": "account.coverage_end"})
    cfg = {**f, "provenance": {"inputs": inputs, "transformations": trans}}
    errs = Validator(LOCAL).errors(cfg, SCHEMA)
    pb = (cfg.get("confirmation") or {}).get("prepared_by") if isinstance(cfg.get("confirmation"), dict) else None
    extra = {} if (not require_preparer or (isinstance(pb, str) and pb.strip())) else {"confirmation.prepared_by": "required"}
    if errs or extra:
        sem, warns = semantic_issues(cfg, defensive=True)
        return None, [_schema_issue(errs, extra)] + sem, warns
    issues, warns = validate_config(cfg)
    return (None if issues else cfg), issues, warns


def load_any(data):
    """Accept bytes from an upload. Returns {ok, issues, warnings, configuration, kind}."""
    out = {"ok": False, "issues": [], "warnings": [], "configuration": None, "kind": None}
    try: obj = json.loads(data.decode("utf-8-sig"))
    except (ValueError, UnicodeDecodeError):
        out["issues"] = [issue("CONFIG-NOT-JSON")]; return out
    if not isinstance(obj, dict): out["issues"] = [issue("CONFIG-UNSUPPORTED")]; return out
    if set(obj) == {"session_setup"} or obj.get("schema_version") in ("0.3.0", "0.4.0"):
        stored = "session_setup" not in obj
        cfg, i, w = from_session_setup(obj if stored else obj["session_setup"], stored=stored)
        out.update(kind="session_setup", configuration=cfg, issues=i, warnings=w, ok=cfg is not None)
        return out
    if obj == blank_template(): out["issues"] = [issue("CONFIG-UNEDITED-TEMPLATE")]; return out
    if set(obj) == {"guided_form"}:
        cfg, i, w = from_guided_form(obj["guided_form"]); out["kind"] = "guided_form"
        out.update(issues=i, warnings=w, configuration=cfg, ok=cfg is not None); return out
    if "metric_dictionary" in obj and "business_profile" in obj and set(obj) == {"metric_dictionary", "business_profile"}:
        cfg, i, w = merge_dictionary_and_profile(obj["metric_dictionary"], obj["business_profile"]); out["kind"] = "dictionary_and_profile"
    elif (obj.get("schema_version") == "0.2.0" and obj.get("configuration_id") == "" and obj.get("configuration_version") == ""
          and obj.get("provenance") == {"inputs": [], "transformations": []}):
        # The downloadable advanced template deliberately leaves technical identity
        # and provenance blank.  Once its operator-owned facts are filled, stamp it
        # exactly as a guided draft instead of asking an operator to invent those
        # technical values.  A wholly untouched template was already rejected above.
        form = copy.deepcopy(obj); form.pop("provenance", None)
        cfg, i, w = from_guided_form(form, require_preparer=False); out["kind"] = "guided_template"
    elif obj.get("configuration_id") is not None or ("metrics" in obj and "account" in obj):
        out["kind"] = "session_configuration"; i, w = validate_config(obj); cfg = None if i else obj
        if cfg is not None:
            cfg = copy.deepcopy(cfg); h = content_sha(obj)       # hash of the content, not the provenance, so reloading never adds an entry
            if not any(x["sha256"] == h for x in cfg["provenance"]["inputs"]):
                cfg["provenance"]["inputs"].append({"kind": "session_configuration", "schema_version": "0.2.0", "sha256": h})
    elif "profile_id" in obj:
        out["kind"] = "business_profile"; cfg, i, w = from_legacy_profile(obj)
    elif "metrics" in obj and "account_id" in obj:
        out["kind"] = "metric_dictionary"; cfg, i, w = None, [issue("CONFIG-SCOPE-REQUIRED")], []
    else:
        cfg, i, w = None, [issue("CONFIG-UNSUPPORTED")], []
    out.update(issues=i, warnings=w, configuration=cfg, ok=cfg is not None)
    return out


# ---------- presentation helpers ----------
def summary(cfg):
    vs = metric_versions(cfg, primary_metric(cfg))
    extensions = cfg.get("extensions") if isinstance(cfg.get("extensions"), dict) else {}
    return {"configuration_id": cfg["configuration_id"], "configuration_version": cfg["configuration_version"], "operating_profile": copy.deepcopy(operating_profile(cfg)),
            "business_label": extensions.get("business_label"), "account_id": cfg["account"]["account_id"],
            "line_of_business_ids": cfg["account"].get("line_of_business_ids", []), "contact_types": cfg["account"].get("contact_types", []), "business_timezone": cfg["account"]["business_timezone"],
            "date_format": cfg["account"].get("date_format", "month_first"),
            "confirmed_by": cfg.get("confirmation", {}).get("confirmed_by"), "prepared_by": cfg.get("confirmation", {}).get("prepared_by"),
            "coverage": {"start": cfg["account"].get("coverage_start"), "end": cfg["account"].get("coverage_end")},
            "targets": [{"definition_version": v["definition_version"], "start": v["effective_start"], "end": v.get("effective_end"), "target": v.get("target"),
                         "upper_specification_limit": v.get("upper_specification_limit"), "lower_specification_limit": v.get("lower_specification_limit"),
                         "direction": v["direction"], "unit": v["canonical_unit"]} for v in vs],
            "scoped_targets": [{"scope": {"kind": "line_of_business" if "line_of_business_ids" in m["applies_to"] else "contact_type", "values": m["applies_to"].get("line_of_business_ids") or m["applies_to"].get("contact_types")},
                                "definition_version": m["definition_version"], "start": m["effective_start"], "end": m.get("effective_end"), "target": m.get("target"),
                                "upper_specification_limit": m.get("upper_specification_limit"), "lower_specification_limit": m.get("lower_specification_limit"),
                                "direction": m["direction"], "unit": m["canonical_unit"]}
                               for m in sorted((x for x in cfg.get("metrics", []) if x["metric_id"] == primary_metric(cfg) and x.get("applies_to")), key=lambda x: (str(scope_of(x)), x["effective_start"]))]}


def diff(active, staged):
    """What changes if a staged configuration replaces the active one, in plain lines."""
    if active is None: return []
    out = []
    for k, label in (("business_label", "Configuration name"), ("account_id", "Account"), ("business_timezone", "Time zone")):
        if active.get(k) != staged.get(k): out.append(f"{label}: {active.get(k)} becomes {staged.get(k)}.")
    if active.get("configuration_id") != staged.get("configuration_id"):
        out.append("Configuration identity changes internally.")
    if active.get("configuration_version") != staged.get("configuration_version"):
        out.append("Technical revision updates automatically.")
    if active.get("coverage") != staged.get("coverage"): out.append("Coverage dates change.")
    for k, label in (("line_of_business_ids", "Lines of Business"), ("contact_types", "Contact types")):
        if active[k] != staged[k]: out.append(f"{label}: {', '.join(active[k])} becomes {', '.join(staged[k])}.")
    if active["targets"] != staged["targets"]: out.append(f"Targets and limits change: {len(active['targets'])} version(s) become {len(staged['targets'])}.")
    return out


def profile_view(cfg):
    """The legacy-shaped summary the questionnaire consumes. It never carries a single target: versions do."""
    m = (metric_versions(cfg, primary_metric(cfg)) or [None])[-1]
    return {"profile_id": cfg["configuration_id"], "profile_version": cfg["configuration_version"], "account_id": cfg["account"]["account_id"],
            "line_of_business_ids": cfg["account"].get("line_of_business_ids", []), "contact_types": cfg["account"].get("contact_types", []), "target_seconds": None,
            "definition": (m or {}).get("aggregation_rule") or "Total handling seconds divided by handled contacts.",
            "confirmed_by": cfg.get("confirmation", {}).get("confirmed_by"), "minimum_meaningful_effect_seconds": None}


def has_target_versions(cfg):
    return any("target" in v for v in metric_versions(cfg, primary_metric(cfg)))


def has_scoped_targets(cfg):
    return any("target" in m for m in cfg.get("metrics", []) if m["metric_id"] == primary_metric(cfg) and m.get("applies_to"))


def uncovered_ranges(versions, first, last):
    """Dates between first and last (inclusive) on which no version applies, as inclusive ranges."""
    out, day, one = [], date.fromisoformat(first), timedelta(days=1)
    end = date.fromisoformat(last); start = None
    while day <= end:
        if version_at(versions, day.isoformat()) is None:
            if start is None: start = day
        elif start is not None:
            out.append((start.isoformat(), (day - one).isoformat())); start = None
        day += one
    if start is not None: out.append((start.isoformat(), end.isoformat()))
    return out
