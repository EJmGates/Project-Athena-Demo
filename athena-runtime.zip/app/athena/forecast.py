"""Simplified 13-week forecast (EJ, 6 Nov 2026), modelled on the Hermes run chart and made to follow the approved gate in spirit.

The weekly series comes from complete Monday-to-Sunday weeks inside the chosen period. Candidates are last value (the benchmark),
simple smoothing, Holt trend and a straight line. Each is scored on one-step-ahead errors on weeks it had not seen (MAD first, MAPE and
MSD for information). A candidate replaces the benchmark only if its MAD is at least 5% lower. The forecast is the next 13 weeks.
The target check says whether the forecast reaches the target by more than the typical error.

Not included yet: 75% and 95% ranges, attainment probabilities, a separate untouched holdout, structural checks. The result says so.
"""
from datetime import date, timedelta

import numpy as np

from athena import session_config, targets

HORIZON = 13
MIN_WEEKS = 12            # 4 training weeks and 8 scored one-step-ahead origins
MIN_TRAIN = 4
IMPROVEMENT = 0.05
ALPHAS = (0.2, 0.4, 0.6, 0.8)
BETAS = (0.2, 0.5, 0.8)
LIMITS = "Simplified forecast: one expected value per week, with no 75% or 95% ranges, no chance of reaching the target and no separate holdout check yet. It describes the recent pattern continuing."


def weekly_series(rows, period):
    """Complete Monday-to-Sunday weeks inside the period: [{start, value, count}], value = total / count over the week's rows."""
    lo, hi = date.fromisoformat(period[0]), date.fromisoformat(period[1])
    first = lo + timedelta(days=(7 - lo.weekday()) % 7)                  # first Monday on or after the period start
    weeks = {}
    for r in rows:
        d = date.fromisoformat(r["date"])
        start = d - timedelta(days=d.weekday())
        c = weeks.setdefault(start, [0.0, 0])
        c[0] += r["total"]; c[1] += r["count"]
    out, w = [], first
    while w + timedelta(days=6) <= hi:
        t, n = weeks.get(w, [0.0, 0])
        out.append({"start": w.isoformat(), "value": (t / n) if n else None, "count": n})
        w += timedelta(days=7)
    return out


def _errors(actual, predicted):
    e = np.asarray(actual, float) - np.asarray(predicted, float)
    nz = np.abs(np.asarray(actual, float)) > 1e-12
    return {"mad": float(np.mean(np.abs(e))), "msd": float(np.mean(e ** 2)),
            "mape": float(np.mean(np.abs(e[nz] / np.asarray(actual, float)[nz])) * 100) if nz.any() else None}


def _ses(y, alpha):
    level = y[0]
    for v in y[1:]:
        level = alpha * v + (1 - alpha) * level
    return lambda h: np.repeat(level, h)


def _holt(y, alpha, beta):
    level, trend = y[0], (y[1] - y[0])
    for v in y[1:]:
        prior = level
        level = alpha * v + (1 - alpha) * (level + trend)
        trend = beta * (level - prior) + (1 - beta) * trend
    return lambda h: level + trend * np.arange(1, h + 1)


def _line(y):
    x = np.arange(1, len(y) + 1, dtype=float)
    slope, intercept = np.polyfit(x, y, 1)
    n = len(y)
    return lambda h: intercept + slope * (n + np.arange(1, h + 1))


def _models():
    out = [("last", "Last value", {}, lambda y: (lambda h: np.repeat(y[-1], h)))]
    for a in ALPHAS:
        out.append(("ses", "Simple smoothing", {"alpha": a}, lambda y, a=a: _ses(y, a)))
    for a in ALPHAS:
        for b in BETAS:
            out.append(("holt", "Trend smoothing", {"alpha": a, "beta": b}, lambda y, a=a, b=b: _holt(y, a, b)))
    out.append(("line", "Straight-line trend", {}, _line))
    return out


def _score(y, fit):
    pred = [float(fit(np.asarray(y[:t], float))(1)[0]) for t in range(MIN_TRAIN, len(y))]
    return _errors(y[MIN_TRAIN:], pred)


def select(values):
    """Scores every candidate on one-step-ahead errors and applies the benchmark rule. Returns (chosen, benchmark, all scored)."""
    y = [float(v) for v in values]
    scored = []
    for key, label, params, fit in _models():
        scored.append({"key": key, "label": label, "params": params, "fit": fit, "errors": _score(y, fit)})
    bench = scored[0]
    better = [s for s in scored[1:] if s["errors"]["mad"] < bench["errors"]["mad"] * (1 - IMPROVEMENT)]
    chosen = min(better, key=lambda s: (s["errors"]["mad"], s["errors"]["msd"], s["label"])) if better else bench
    return chosen, bench, scored


def reach(values, target, direction, mad):
    """Whether the forecast reaches the target by more than the typical error. higher_is_better / lower_is_better only; others get no verdict."""
    if target is None or direction not in ("higher_is_better", "lower_is_better"):
        return {"status": "none", "first_week": None}
    sign = 1 if direction == "higher_is_better" else -1
    margins = [sign * (v - target) for v in values]
    sure = [i for i, m in enumerate(margins) if m >= mad]
    near = [i for i, m in enumerate(margins) if m >= 0]
    if sure:
        return {"status": "expected", "first_week": sure[0] + 1}
    if near:
        return {"status": "within_typical_error", "first_week": near[0] + 1}
    return {"status": "not_expected", "first_week": None}


def build(rows, period, target=None, direction=None, *, target_versions=None):
    weeks = weekly_series(rows, period)
    missing = [w for w in weeks if w["value"] is None]
    if len(weeks) < MIN_WEEKS or missing:
        why = ("Needs at least %d complete weeks of data in the chosen period (%d found)." % (MIN_WEEKS, len(weeks)) if len(weeks) < MIN_WEEKS
               else "One or more complete weeks in the chosen period have no data, so the weekly series is not continuous.")
        return {"status": "withheld", "reason": why, "history": weeks, "limits": LIMITS}
    y = [w["value"] for w in weeks]
    chosen, bench, scored = select(y)
    fc = [float(v) for v in chosen["fit"](np.asarray(y, float))(HORIZON)]
    last = date.fromisoformat(weeks[-1]["start"])
    future = [{"start": (last + timedelta(days=7 * (i + 1))).isoformat(), "value": v} for i, v in enumerate(fc)]
    if target_versions is not None:
        for week in future:
            end = (date.fromisoformat(week["start"]) + timedelta(days=6)).isoformat()
            version = session_config.version_at(target_versions, week["start"])
            if version is None or session_config.version_at(target_versions, end) is not version:
                continue
            assessment = targets.assess_value(week["value"], version)
            if assessment["target_met"] is not None:
                week.update(target=assessment["target"], target_met=assessment["target_met"], target_rule=assessment["target_rule"])
        references = {(week.get("target"), week.get("target_rule")) for week in future}
        reference = references.pop() if len(references) == 1 else (None, None)
        target, rule = reference
        direction = {"at_or_below": "lower_is_better", "at_or_above": "higher_is_better"}.get(rule)
    e = chosen["errors"]
    return {"status": "published", "history": weeks, "forecast": future, "horizon_weeks": HORIZON,
            "model": {"label": chosen["label"], "params": chosen["params"], "mad": e["mad"], "mape": e["mape"], "msd": e["msd"],
                      "beat_benchmark": chosen is not bench},
            "benchmark": {"label": bench["label"], "mad": bench["errors"]["mad"], "mape": bench["errors"]["mape"], "msd": bench["errors"]["msd"]},
            "scored_origins": len(y) - MIN_TRAIN, "improvement_required": IMPROVEMENT,
            "target": target, "direction": direction, "reach": reach(fc, target, direction, e["mad"]), "limits": LIMITS}
