"""Account configuration: stored business profiles, blank template, upload and matching.

A profile holds the facts Athena must not guess: the contractual target, what handling includes,
the lines_of_business and contact types in scope, the business time zone and who confirmed it. Profiles are
files under config/profiles/, never values written into code. A matched profile fills the target
field and names its source; the user can still change it.
"""
import json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIR = ROOT / "config" / "profiles"
SCHEMA = "business_profile.schema.json"
SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")

# FROZEN FOR REGRESSION ONLY. This legacy template carries target_seconds: 0, which must never be offered to a user. It is served only
# when configuration_storage is "stored_files" (legacy tests and rollback). The production template is session_config.blank_template().
TEMPLATE = {
    "schema_version": "0.1.0",
    "profile_id": "PROFILE-REPLACE-ME",
    "profile_version": "0.1.0",
    "account_id": "ACCOUNT-ID-FROM-YOUR-DATA",
    "line_of_business_ids": ["LINE-OF-BUSINESS-ID"],
    "contact_types": ["CONTACT-TYPE"],
    "effective_start": "2026-01-01",
    "business_timezone": "UTC",
    "metric_definition": {"metric_id": "aht", "definition": "State what handling time includes in your contract.",
                          "canonical_unit": "seconds",
                          "handling_components": ["talk_seconds", "hold_seconds", "after_call_work_seconds"]},
    "target_seconds": 0,
    "confirmed_by": "SUBJECT-ID-OF-APPROVER",
    "confirmed_at": "2026-01-01T00:00:00Z",
    "confirmation_reference": "REFERENCE-FOR-THE-APPROVAL",
}
FIELD_HELP = {
    "profile_id": "Your identifier for this configuration.",
    "account_id": "Must match the account in your data file exactly.",
    "line_of_business_ids": "Every line_of_business this contract covers.",
    "effective_start": "First date this contract applies, as YYYY-MM-DD.",
    "business_timezone": "Time zone the business day is measured in.",
    "metric_definition": "What handling time includes under this contract.",
    "target_seconds": "Contractual target in seconds. Leave out if there is no target.",
    "minimum_meaningful_effect_seconds": "Smallest difference that matters to you, in seconds. Optional.",
    "confirmed_by": "Who approved these facts.",
    "confirmation_reference": "Where the approval is recorded.",
}


def template():
    return {"profile": TEMPLATE, "field_help": FIELD_HELP}


def _summary(p):
    return {"profile_id": p["profile_id"], "profile_version": p["profile_version"], "account_id": p["account_id"],
            "line_of_business_ids": p["line_of_business_ids"], "target_seconds": p.get("target_seconds"),
            "minimum_meaningful_effect_seconds": p.get("minimum_meaningful_effect_seconds"),
            "definition": p["metric_definition"]["definition"], "business_timezone": p["business_timezone"],
            "effective_start": p["effective_start"], "effective_end": p.get("effective_end"),
            "confirmed_by": p["confirmed_by"], "confirmation_reference": p["confirmation_reference"]}


def load_all():
    out = []
    if DIR.is_dir():
        for f in sorted(DIR.glob("*.json")):
            try: out.append(_summary(json.loads(f.read_text(encoding="utf-8"))))
            except (ValueError, KeyError): continue
    return out


def match(account_id, validator=None):
    """The stored profile for an account, or None. Two profiles for one account is an unresolved
    configuration, never a silent pick, so nothing is returned."""
    hits = [p for p in load_all() if p["account_id"] == account_id]
    return hits[0] if len(hits) == 1 else None


def save(data, validator):
    """Validate and store an uploaded profile. Returns (ok, issues)."""
    try: p = json.loads(data.decode("utf-8-sig"))
    except (ValueError, UnicodeDecodeError):
        return False, [{"code": "PROFILE-NOT-JSON", "problem": "The configuration file could not be read.",
                        "why": "Athena needs the JSON template, not a spreadsheet or document.",
                        "remedy": "Download the template, fill it in and upload it again."}]
    errs = validator.errors(p, SCHEMA)
    if errs:
        return False, [{"code": "PROFILE-INVALID", "problem": "The configuration is missing or has invalid values in: "
                        + ", ".join(sorted({e[0].split(".")[-1].split("[")[0] for e in errs})) + ".",
                        "why": "Athena will not guess a contractual target, scope or definition.",
                        "remedy": "Fill in these fields in the template and upload again."}]
    if p.get("effective_end") and p["effective_end"] < p["effective_start"]:
        return False, [{"code": "PROFILE-DATES", "problem": "The end date is before the start date.",
                        "why": "A contract period cannot end before it begins.", "remedy": "Correct the dates and upload again."}]
    if not SAFE.match(p["profile_id"]):
        return False, [{"code": "PROFILE-ID", "problem": "The profile identifier contains unsupported characters.",
                        "why": "It is used as a file name.", "remedy": "Use letters, digits, dot, dash or underscore only."}]
    DIR.mkdir(parents=True, exist_ok=True)
    (DIR / f"{p['profile_id']}.json").write_text(json.dumps(p, indent=2), encoding="utf-8")
    return True, []
