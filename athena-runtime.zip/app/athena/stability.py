"""Individuals and Moving Range for the complete business weeks in a Cockpit run."""
from collections import deque
from dataclasses import asdict, dataclass
from itertools import pairwise
from math import isfinite
from statistics import fmean


@dataclass(frozen=True)
class Baseline:
    center: float
    sigma: float
    mr_center: float
    observations: int
    pairs: int

    @property
    def mr_upper(self):
        return (1.128 + 3 * 0.8525) * self.sigma


def build(weeks, metric_id):
    if metric_id != "aht":
        return {"status": "descriptive", "reason_code": "METRIC-SCOPE", "reason": "I-MR is available for weekly AHT."}
    values = [week["value"] for week in weeks]
    baseline = estimate_baseline(values)
    if baseline is None:
        return {"status": "descriptive", "reason_code": "NO-MOVING-VARIATION",
                "reason": "Estimating control limits requires at least one pair of consecutive eligible weeks with different readings."}
    result = evaluate_fixed_limits(baseline, zip((week["start"] for week in weeks), values))
    return {**result, "status": "assessed", "method": "I-MR", "baseline": asdict(baseline),
            "estimation_window": {"first_week": weeks[0]["start"], "last_week": weeks[-1]["start"]}}


def estimate_baseline(values):
    values = tuple(values)
    readings = [value for value in values if value is not None]
    if any(not isfinite(value) for value in readings):
        raise ValueError("Use finite Stability readings or mark the interval as missing.")
    ranges = [abs(right - left) for left, right in pairwise(values) if left is not None and right is not None]
    if not ranges or not any(ranges):
        return None
    mr_center = fmean(ranges)
    return Baseline(fmean(readings), mr_center / 1.128, mr_center, len(readings), len(ranges))


def _same_side(values, center, width, required):
    above, below = center + width, center - width
    return ((values[-1] > above and sum(value > above for value in values) >= required)
            or (values[-1] < below and sum(value < below for value in values) >= required))


def _individuals_rules(baseline):
    center, sigma = baseline.center, baseline.sigma

    def increasing_or_decreasing(values):
        changes = [right - left for left, right in pairwise(values)]
        return all(change > 0 for change in changes) or all(change < 0 for change in changes)

    def alternating(values):
        changes = [right - left for left, right in pairwise(values)]
        return all((left < 0 < right) or (right < 0 < left) for left, right in pairwise(changes))

    lower, upper = center - sigma, center + sigma
    return (
        (1, 1, lambda v: v[-1] < center - 3 * sigma or v[-1] > center + 3 * sigma),
        (2, 9, lambda v: _same_side(v, center, 0, 9)),
        (3, 6, increasing_or_decreasing),
        (4, 14, alternating),
        (5, 3, lambda v: _same_side(v, center, 2 * sigma, 2)),
        (6, 5, lambda v: _same_side(v, center, sigma, 4)),
        (7, 15, lambda v: all(lower < value < upper for value in v)),
        (8, 8, lambda v: all(value < lower or value > upper for value in v)),
    )


def evaluate_fixed_limits(baseline, readings):
    """Return candidate evidence for (interval, value) pairs, using unchanged historical limits."""
    if baseline is None:
        return None
    history = deque(maxlen=15)
    plotted = []
    rules = _individuals_rules(baseline)
    for interval, value in readings:
        if value is None:
            history.clear()
            plotted.append({"interval": interval, "value": None, "range": None, "pair": None,
                            "eligible_tests": [], "hits": []})
            continue
        if not isfinite(value):
            raise ValueError("Use finite Stability readings or mark the interval as missing.")
        pair = (history[-1], (interval, value)) if history else None
        moving_range = abs(value - pair[0][1]) if pair else None
        hits = []
        if moving_range is not None and moving_range > baseline.mr_upper:
            hits.append({"chart": "moving_range", "test": 1, "readings": pair})
        history.append((interval, value))
        run = list(history)
        eligible_tests = []
        for test, width, matches in rules:
            if len(run) >= width:
                eligible_tests.append(test)
                window = run[-width:]
                if matches([point[1] for point in window]):
                    hits.append({"chart": "individuals", "test": test, "readings": window})
        plotted.append({"interval": interval, "value": value, "range": moving_range, "pair": pair,
                        "eligible_tests": eligible_tests, "hits": hits})
    evaluated = sum(point["value"] is not None for point in plotted)
    evaluated_ranges = sum(point["range"] is not None for point in plotted)
    flagged = sum(bool(point["hits"]) for point in plotted)
    mr_flagged = any(hit["chart"] == "moving_range" for point in plotted for hit in point["hits"])
    return {
        "baseline": baseline,
        "individuals_limits": (baseline.center - 3 * baseline.sigma, baseline.center + 3 * baseline.sigma),
        "moving_range_limits": (0, baseline.mr_upper),
        "readings": plotted,
        "evaluated_dates": evaluated,
        "evaluated_ranges": evaluated_ranges,
        "flagged_dates": flagged,
        "flagged_share": flagged / evaluated if evaluated else None,
        "interpret_individuals": bool(evaluated_ranges) and not mr_flagged,
    }
