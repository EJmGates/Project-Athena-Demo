"""Generate the interface's CSS variables from config/design_tokens.json.

The token file is the source. The page carries a placeholder that this fills in, so a colour or spacing
value exists in exactly one place and cannot drift between the design record and what people see.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PLACEHOLDER = "/*__TOKENS__*/"


def load(path=None):
    return json.loads((Path(path) if path else ROOT / "config/design_tokens.json").read_text(encoding="utf-8"))


def css(tok=None):
    t = tok or load()
    def block(mode):
        return "".join(f"--{k}:{v[mode]};" for k, v in t["color"].items())
    light, dark = block("light"), block("dark")
    rest = "".join(f"--font-{k}:{v};" for k, v in t["font"].items()) + "".join(f"--space-{k}:{v};" for k, v in t["space"].items())
    return (f":root{{{light}{rest}}}\n"
            f"@media (prefers-color-scheme:dark){{:root:not([data-theme=light]){{{dark}}}}}\n"
            f":root[data-theme=dark]{{{dark}}}\n")


def render(html, tok=None):
    if PLACEHOLDER not in html:
        raise ValueError("page is missing the token placeholder")
    return html.replace(PLACEHOLDER, css(tok))
