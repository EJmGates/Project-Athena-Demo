"""Disposition-aware data-quality classification (Increment 1, stage 2).

Every source row ends in exactly one role:
  canonical_valid  valid and the representative of its identity group (contributes to scope KPIs)
  collapsed_copy   valid, an identical repeat of a canonical record under an authorized rule (counted once, traceable)
  quarantined      demonstrably invalid
  held             member of an unresolved conflict or unconfirmed duplicate group
Source-row disposition, canonical status and per-calculation contribution are separate facts.

Classification is deterministic: the same input and policy versions give the same decisions. Timestamps and other
execution metadata are kept apart from decisions so tests can compare decisions alone.

Cell values are data: never evaluated, never shown on screen. Row numbers go to the screen. Values go only into the
downloadable list for the user's own file.
"""
import csv, hashlib, io, json
from collections import defaultdict
from datetime import datetime, timezone
import re

from athena import dates, metrics
from athena import rules as data_rules
from athena import dq_contracts as C
from athena import ingest_legacy as L0
from athena.schema_subset import Validator
from athena.upload_checks import REQUIRED, check_upload

ENGINE = "dq/1.0.0"
CANONICAL, COLLAPSED, QUARANTINED, HELD = 1, 2, 3, 4
ROLE_NAME = {CANONICAL: "canonical_valid", COLLAPSED: "collapsed_copy", QUARANTINED: "quarantined", HELD: "held"}
NUM, DUR = L0.NUM, L0.DUR
CORE = {g: set(REQUIRED[g]) | set(NUM[g]) for g in NUM}
LEVEL_LIMIT = 40          # a column with at most this many distinct values (a rating scale, a 0/1 flag) keeps a count for each value
DERIVED_AHT = {"aht_seconds"}      # the file's own handle-time average; Athena calculates AHT from the totals


def _now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _num(s):
    return L0._num(s)


def _norm_ts(s):
    try:
        t = datetime.fromisoformat(s.strip().replace("Z", "+00:00").replace("z", "+00:00"))
    except ValueError:
        return s.strip()
    return t.astimezone(timezone.utc).isoformat() if t.tzinfo else s.strip()


def normalize(layout_rules, col, raw):
    """Versioned normalization used to decide whether two records are identical (rules normalization_version)."""
    s = raw.strip()
    if s == "": return None
    if col in layout_rules.get("timestamp_fields", []): return _norm_ts(s)
    if col in layout_rules.get("numeric_fields", []):
        x = _num(s)
        if isinstance(x, float) and x.is_integer(): x = int(x)
        return x
    return s


def _canonical_dates(grain, cells, date_format="mdy", zone=None):
    """Keep the canonical source instant and return its account business date."""
    col, want_time = ("occurred_at", True) if grain == "contact" else ("work_date", False)
    r = dates.read(cells.get(col, ""), date_format, zone)
    if r.ok and r.has_time == want_time:
        cells[col] = r.instant_utc if want_time else r.business_date
        return r.business_date
    return None


def _event(seq, frm, to, code, rule_id, rule_version, at):
    return {"seq": seq, "from_state": frm, "to_state": to, "reason_code": code, "rule_id": rule_id, "rule_version": rule_version, "at": at}


def inspect(name, data, limits, validator, pol, declarations=None, rules=None, clock=None, date_format="mdy", zone=None):
    """declarations: {"duplicate_semantics": {...}} already validated by dq_contracts.duplicate_semantics_from_manifest.
    date_format ("mdy" or "dmy") and zone (IANA name) are how the date reader interprets the file; defaults keep the earlier behaviour."""
    errs = C.validate_policy(pol)
    if errs: raise ValueError("invalid data-quality policy: " + "; ".join(errs[:3]))
    rules = rules or C.load_identity_rules()
    zone = dates.zone_for(zone)
    clock = clock or _now
    at = clock()
    for code, f in pol["record_faults"].items():
        if f["disposition"] not in ("quarantine", "hold"): raise ValueError(f"record fault {code} may only quarantine or hold")
    prov = {"policy_version": pol["policy_version"], "policy_sha256": C.sha256_of(pol), "identity_rules_version": rules["rules_version"],
            "identity_rules_sha256": C.sha256_of(rules), "normalization_version": rules["normalization_version"], "engine": ENGINE}
    out = {"ok": False, "upload_id": hashlib.sha256(data).hexdigest()[:16], "file_sha256": hashlib.sha256(data).hexdigest(), "grain": None,
           "issues": [], "notices": [], "summary": None, "aggregates": None, "exclusions": None, "faults": {}, "reconciliation": None,
           "records": [], "groups": [], "non_eligible": [], "manifest_rows": [], "decision_digest": None, "provenance": prov,
           "execution": {"classified_at": at}, "policy_mode": "disposition_aware"}

    def block(code, section="run_blocks", rows=None):
        f = pol[section][code]
        i = {"code": code, "problem": f["problem"], "why": f["why"], "remedy": f["remedy"], "disposition": f["disposition"], "level": f["level"]}
        if rows: i["rows"] = sorted(rows)[:10]; i["row_count"] = len(rows)
        out["issues"].append(i)

    probe = "contact" if b"contact_id" in data[:2000] else "agent_day"
    unsafe = [i for i in check_upload(name, data, probe, limits) if i["reason_code"] != "MISSING-COLUMN"]
    if unsafe:
        c = unsafe[0]["reason_code"]; p, w, r = L0.SAFETY_TEXT[c]
        out["issues"] = [{"code": c, "problem": p, "why": w, "remedy": r, "disposition": "block", "level": "run"}]
        return out
    rd = csv.reader(io.StringIO(data.decode("utf-8-sig"), newline=""))
    header = next(rd, []); grain = L0._detect(header)
    if grain is None:
        out["issues"] = [{"code": "UNKNOWN-LAYOUT", "problem": "The columns do not match either template.", "why": "Athena needs the template columns to know what each value means.",
                          "remedy": "Start from one of the templates and upload again.", "disposition": "block", "level": "run"}]
        return out
    out["grain"] = grain
    missing = [c for c in REQUIRED[grain] if c not in header]
    if missing:
        out["issues"] = [{"code": "MISSING-COLUMN", "problem": "Required columns are missing: " + ", ".join(missing) + ".", "why": "Without them Athena cannot calculate handle time.",
                          "remedy": "Add the columns from the template and upload again.", "disposition": "block", "level": "run"}]
        return out

    sel = C.schema_selection(pol, grain)                       # chosen by the policy contract, never by a record
    sv = Validator(sel["schema_dir"]); optional_agent = sel["agent_attribution"] == "optional"
    lay = rules["layouts"][grain]; ident_fields = lay["identity_fields"]
    idx = {h: i for i, h in enumerate(header)}
    roles, detail_of, key_of = [], {}, {}
    valid = []                                                  # record-level valid rows awaiting group resolution
    codes_of = defaultdict(list)                                # row -> reason codes (quarantine)
    nonelig = {}                                                # row -> compact info for coverage

    for n, raw in enumerate(rd, start=2):
        cells = {h: (raw[i] if i < len(raw) else "") for h, i in idx.items()}
        business_date = _canonical_dates(grain, cells, date_format, zone)
        rec = {}
        for h in header:
            if h not in CORE[grain]: continue
            v = cells[h]
            if h in NUM[grain]:
                x = _num(v)
                if x is not None: rec[h] = x
            elif v != "" or (h in REQUIRED[grain] and not (optional_agent and h == "agent_id")):
                rec[h] = v
        e = sv.errors(rec, sel["schema"])
        if business_date is None and not e:
            e = [("$.occurred_at" if grain == "contact" else "$.work_date", "unreadable date")]
        code, det = None, None
        if e:
            bad = {p.split(".")[-1].split("[")[0] for p, _ in e}
            dur_raw = cells.get(DUR[grain], "").strip(); cnt = rec.get("handled_contacts"); d = _num(dur_raw)
            if grain == "agent_day" and cnt == 0 and isinstance(d, (int, float)) and d > 0:
                code, det = "ZERO-CONTACT-POSITIVE-DURATION", f"{DUR[grain]}={dur_raw}, handled_contacts=0"
            elif grain == "agent_day" and cells.get("agent_id", "").strip() == "":
                code, det = "AGENT-DAY-MISSING-AGENT", "agent_id is empty"
            elif dur_raw == "" and DUR[grain] in bad:
                code, det = "BLANK-DURATION", f"{DUR[grain]} is empty"
            elif DUR[grain] in bad:
                code, det = "INVALID-DURATION", f"{DUR[grain]}={dur_raw}"
            elif "handled_contacts" in bad:
                code, det = "INVALID-COUNT", f"handled_contacts={cells.get('handled_contacts', '')}"
            else:
                code, det = "INVALID-ROW", ", ".join(f"{b}={cells.get(b, '')}" for b in sorted(bad))
        elif grain == "contact":
            comp = pol["metric_rules"]["aht"]["handling_components"]
            if all(c in rec for c in comp) and sum(rec[c] for c in comp) > rec["handling_seconds"]:
                code, det = "COMPONENTS-EXCEED-TOTAL", f"components {sum(rec[c] for c in comp)} > handling_seconds={rec['handling_seconds']}"
        rid = cells.get("contact_id") or cells.get("agent_id") or ""
        if code:
            disp = pol["record_faults"][code]["disposition"]
            roles.append(QUARANTINED if disp == "quarantine" else HELD); codes_of[n].append(code); detail_of[n] = (code, rid, det)
            nonelig[n] = {"row": n, "role": ROLE_NAME[roles[-1]], "code": code, "line_of_business_id": cells.get("line_of_business_id", "").strip() or None,
                          "date": business_date, "contacts": (1 if grain == "contact" else (cnt if isinstance(cnt, int) and cnt >= 0 else None))}
            continue
        roles.append(CANONICAL)                                  # provisional; group resolution may change it
        key = tuple(cells[f].strip() for f in ident_fields)
        sig = tuple((h, normalize(lay, h, cells[h])) for h in header)
        attributed = bool(rec.get("agent_id")) if grain == "contact" else True
        valid.append({"n": n, "rec": rec, "key": key, "sig": sig, "attributed": attributed, "cells": cells, "date": business_date})

    accounts = sorted({v["rec"]["account_id"] for v in valid})
    groups_by = defaultdict(list)
    for v in valid: groups_by[v["key"]].append(v)
    groups, records, events = [], {}, defaultdict(list)
    rule_ver = rules["rules_version"]
    decl = (declarations or {}).get("duplicate_semantics")
    need = lay["identical"].get("required_declaration")

    def add_events(n, *evs):
        for e in evs: events[n].append(e)

    for key, members in sorted(groups_by.items()):
        if len(members) == 1: continue
        members.sort(key=lambda v: v["n"]); rows = [m["n"] for m in members]
        gid = "GRP-" + hashlib.sha256("|".join(key).encode("utf-8")).hexdigest()[:12]
        identical = all(m["sig"] == members[0]["sig"] for m in members)
        base = {"group_id": gid, "identity_key": "|".join(key), "member_rows": rows, "rule_version": rule_ver, "layout": grain}
        if identical and lay["identical"]["action"] == "collapse":
            canon = rows[0]
            groups.append(dict(base, kind="identical", status="collapsed_by_rule", rule_id=lay["identical"]["rule_id"], reason_code="DUPLICATE-COLLAPSED", canonical_row=canon))
            for m in members[1:]:
                roles[m["n"] - 2] = COLLAPSED
                records[m["n"]] = {"row": m["n"], "disposition": "valid", "canonical": False, "reason_codes": ["DUPLICATE-COLLAPSED"], "flags": [], "group_id": gid, "collapsed_into_row": canon}
                add_events(m["n"], _event(1, "received", "valid", None, "RECORD-CHECKS", pol["policy_version"], at),
                           _event(2, "valid", "valid_collapsed_copy", "DUPLICATE-COLLAPSED", lay["identical"]["rule_id"], rule_ver, at))
                nonelig[m["n"]] = {"row": m["n"], "role": "collapsed_copy", "code": "DUPLICATE-COLLAPSED", "line_of_business_id": m["cells"].get("line_of_business_id", "").strip() or None,
                                   "date": m["date"], "contacts": 1 if grain == "contact" else m["rec"].get("handled_contacts")}
                detail_of[m["n"]] = ("DUPLICATE-COLLAPSED", m["cells"].get("contact_id") or "", f"identical to row {canon}")
        elif identical and lay["identical"]["action"] == "hold_unless_declared" and decl == need:
            canon = rows[0]
            groups.append(dict(base, kind="identical", status="collapsed_by_rule", rule_id=lay["identical"]["collapse_rule_id"], reason_code="DUPLICATE-COLLAPSED", canonical_row=canon))
            for m in members[1:]:
                roles[m["n"] - 2] = COLLAPSED
                records[m["n"]] = {"row": m["n"], "disposition": "valid", "canonical": False, "reason_codes": ["DUPLICATE-COLLAPSED"], "flags": [], "group_id": gid, "collapsed_into_row": canon}
                add_events(m["n"], _event(1, "received", "valid", None, "RECORD-CHECKS", pol["policy_version"], at),
                           _event(2, "valid", "valid_collapsed_copy", "DUPLICATE-COLLAPSED", lay["identical"]["collapse_rule_id"], rule_ver, at))
                nonelig[m["n"]] = {"row": m["n"], "role": "collapsed_copy", "code": "DUPLICATE-COLLAPSED", "line_of_business_id": m["cells"].get("line_of_business_id", "").strip() or None,
                                   "date": m["date"], "contacts": m["rec"].get("handled_contacts")}
                detail_of[m["n"]] = ("DUPLICATE-COLLAPSED", "", f"identical to row {canon}")
        else:
            code = "UNCONFIRMED-DUPLICATE" if identical else "CONFLICTING-DUPLICATE"
            rid = lay["conflicting"]["rule_id"] if not identical else lay["identical"]["rule_id"]
            groups.append(dict(base, kind="identical" if identical else "conflicting", status="held_unresolved", rule_id=rid, reason_code=code, canonical_row=None))
            for m in members:
                roles[m["n"] - 2] = HELD
                records[m["n"]] = {"row": m["n"], "disposition": "hold", "canonical": False, "reason_codes": [code], "flags": [], "group_id": gid, "collapsed_into_row": None}
                add_events(m["n"], _event(1, "received", "valid", None, "RECORD-CHECKS", pol["policy_version"], at), _event(2, "valid", "hold", code, rid, rule_ver, at))
                nonelig[m["n"]] = {"row": m["n"], "role": "held", "code": code, "line_of_business_id": m["cells"].get("line_of_business_id", "").strip() or None,
                                   "date": m["date"], "contacts": 1 if grain == "contact" else m["rec"].get("handled_contacts")}
                detail_of[m["n"]] = (code, m["cells"].get("contact_id") or "", "same identity as rows " + ", ".join(str(r) for r in rows if r != m["n"]))

    # quarantined rows
    for n, (code, rid, det) in detail_of.items():
        if n in records or roles[n - 2] not in (QUARANTINED, HELD) or code in ("CONFLICTING-DUPLICATE", "UNCONFIRMED-DUPLICATE", "DUPLICATE-COLLAPSED"): continue
        f = pol["record_faults"][code]
        records[n] = {"row": n, "disposition": f["disposition"], "canonical": None, "reason_codes": codes_of[n], "flags": [], "group_id": None, "collapsed_into_row": None}
        add_events(n, _event(1, "received", f["disposition"], code, "POLICY:" + code, pol["policy_version"], at))

    canon_rows = [v for v in valid if roles[v["n"] - 2] == CANONICAL]
    for v in canon_rows:
        if not v["attributed"]:
            records[v["n"]] = {"row": v["n"], "disposition": "valid", "canonical": True, "reason_codes": [], "flags": ["UNATTRIBUTED-CONTACT"], "group_id": None, "collapsed_into_row": None}
            add_events(v["n"], _event(1, "received", "valid", None, "RECORD-CHECKS", pol["policy_version"], at),
                       _event(2, "valid", "valid_flagged", "UNATTRIBUTED-CONTACT", "POLICY:UNATTRIBUTED-CONTACT", pol["policy_version"], at))
            detail_of[v["n"]] = ("UNATTRIBUTED-CONTACT", v["cells"].get("contact_id") or "", "agent_id is empty")

    # contribution and history on every record in the ledger
    for n, r in records.items():
        canon_valid = r["disposition"] == "valid" and r["canonical"] is True
        r["contributes"] = {"scope_kpi": canon_valid, "agent_identity": canon_valid and "UNATTRIBUTED-CONTACT" not in r["flags"]}
        r["history"] = events[n]
    assert all(roles), "every source row must be classified exactly once"
    n_roles = {k: roles.count(k) for k in (CANONICAL, COLLAPSED, QUARANTINED, HELD)}
    source_rows = len(roles)
    assert sum(n_roles.values()) == source_rows

    contacts = (len(canon_rows) if grain == "contact" else sum(v["rec"]["handled_contacts"] for v in canon_rows))
    unattr = sum(1 for v in canon_rows if not v["attributed"])
    by_reason = defaultdict(lambda: {"rows": 0})
    for n, (code, _, _) in detail_of.items():
        sec = next((s for s in ("record_faults", "group_faults", "group_resolutions", "flags") if code in pol[s]), None)
        by_reason[code]["disposition"] = pol[sec][code]["disposition"] if sec else "valid"; by_reason[code]["rows"] += 1
    out["reconciliation"] = {"source_rows": source_rows, "canonical_valid": n_roles[CANONICAL], "collapsed_copies": n_roles[COLLAPSED],
                             "quarantined": n_roles[QUARANTINED], "held": n_roles[HELD],
                             "every_row_accounted_for_once": n_roles[CANONICAL] + n_roles[COLLAPSED] + n_roles[QUARANTINED] + n_roles[HELD] == source_rows,
                             "eligible_contacts": contacts, "unattributed_canonical_rows": unattr, "attributed_canonical_rows": len(canon_rows) - unattr,
                             "by_reason": {k: dict(v) for k, v in sorted(by_reason.items())}}
    out["faults"] = {k: v["rows"] for k, v in sorted(by_reason.items())}
    out["findings"] = data_rules.findings(out["faults"])
    out["records"] = [records[n] for n in sorted(records)]
    out["groups"] = groups
    out["non_eligible"] = [nonelig[n] for n in sorted(nonelig)]
    # notices: grouped by code, never raw values
    sec_of = {}
    for s in ("record_faults", "group_faults", "group_resolutions", "flags"):
        for c, f in pol[s].items(): sec_of[c] = f
    effects = {"quarantine": "Set aside and not counted.", "hold": "Held out of every calculation until the conflict is resolved.",
               "valid": "Counted once, and every occurrence stays traceable.", "flag": "Counted in account and Line of Business results; not used where the agent matters."}
    rows_by_code = defaultdict(list)
    for n, (code, _, _) in detail_of.items(): rows_by_code[code].append(n)
    for code in sorted(rows_by_code):
        f = sec_of[code]; rows = sorted(rows_by_code[code])
        out["notices"].append({"code": code, "problem": f["problem"], "why": f["why"], "remedy": f["remedy"], "disposition": f["disposition"], "level": f["level"],
                               "effect": effects[f["disposition"]], "rows": rows[:10], "row_count": len(rows)})
    rem = {c: sec_of[c]["remedy"] for c in sec_of}
    out["manifest_rows"] = sorted((n, code, rid, det, rem[code], sec_of[code]["disposition"]) for n, (code, rid, det) in detail_of.items())

    # run-level and metric-level blocks
    if len(accounts) > 1:
        block("MULTIPLE-ACCOUNTS")
    elif n_roles[CANONICAL] == 0:
        block("NO-ELIGIBLE-RECORDS")
    elif contacts == 0:
        block("NO-HANDLED-CONTACTS")
    if canon_rows:
        ds = sorted({v["date"] for v in canon_rows})
        out["summary"] = {"file": name, "grain": grain, "rows": source_rows, "accounts": accounts,
                          "agents": len({v["rec"]["agent_id"] for v in canon_rows if v["attributed"]}),
                          "date_min": ds[0], "date_max": ds[-1], "unit": "seconds",
                          "distinct": {"line_of_business_id": sorted({v["rec"]["line_of_business_id"] for v in canon_rows}), "contact_type": sorted({v["rec"]["contact_type"] for v in canon_rows})},
                          "longest_contact_seconds": max(v["rec"]["handling_seconds"] for v in canon_rows) if grain == "contact" else None,
                          "fingerprint": out["file_sha256"][:12], "eligible_records": len(canon_rows), "unattributed_contacts": unattr,
                          "extra_columns": [h for h in header if h not in CORE[grain] and h not in DERIVED_AHT]}
    n_set_aside = n_roles[QUARANTINED] + n_roles[HELD]
    entries = [{"code": c, "row_count": by_reason[c]["rows"], "disposition": by_reason[c]["disposition"]} for c in sorted(by_reason) if by_reason[c]["disposition"] in ("quarantine", "hold")]
    out["exclusions"] = ({"policy_version": pol["policy_version"], "excluded_row_count": n_set_aside, "collapsed_copies": n_roles[COLLAPSED], "entries": entries}
                         if (n_set_aside or n_roles[COLLAPSED]) else None)
    if not out["issues"]:
        measures = [h for h in header if h not in CORE[grain] and h not in DERIVED_AHT]       # every other numeric column the user supplied
        if grain == "contact":
            measures.extend(h for h in pol["metric_rules"]["aht"]["handling_components"] if h in CORE[grain] and h in header)
        score_columns = {column: metric for metric, spec in metrics.METRICS.items()
                         if (column := spec.get("columns", {}).get(grain, {}).get("score")) in measures}
        score_formats = {}
        seen = {h: set() for h in measures}                                                      # columns with few distinct values also keep a count per value
        for v in canon_rows:
            for h in measures:
                if len(seen[h]) <= LEVEL_LIMIT:
                    x = _num(v["cells"].get(h, ""))
                    if isinstance(x, (int, float)) and not isinstance(x, bool): seen[h].add(x)
        levelled = {h for h in measures if len(seen[h]) <= LEVEL_LIMIT}
        if grain == "contact":
            levelled.update(score_columns)  # The selected cutoff needs the full score distribution.
        pass_key = "pass_flag" if grain == "contact" else "pass_rate_pct"
        pass_columns = {column for spec in metrics.METRICS.values()
                        if (column := spec.get("columns", {}).get(grain, {}).get(pass_key))}
        agg = defaultdict(lambda: [0, 0, {}, set()])
        for v in canon_rows:
            r = v["rec"]; d = v["date"]
            k = (r["line_of_business_id"], r["contact_type"], d, r["agent_id"] if v["attributed"] else "")
            w = 1 if grain == "contact" else r["handled_contacts"]
            c = agg[k]; c[0] += w; c[1] += r["handling_seconds"] if grain == "contact" else r["total_handling_seconds"]
            for h in measures:
                x = _num(v["cells"].get(h, ""))
                if h in pass_columns and x is not None:
                    valid = isinstance(x, (int, float)) and (x in (0, 1) if grain == "contact" else 0 <= x <= 100)
                    if not valid:
                        if w:
                            c[3].add(h)
                        continue
                if isinstance(x, (int, float)) and not isinstance(x, bool):
                    m = c[2].setdefault(h, [0, 0.0, 0.0, {}]); m[0] += w; m[1] += x; m[2] += x * w
                    if h in levelled: m[3][x] = m[3].get(x, 0) + w
                    if w and h in score_columns:
                        metric = score_columns[h]
                        previous = score_formats.get(metric)
                        if previous == "points" or not 0 <= x <= 1:
                            score_formats[metric] = "points"
                        elif previous == "fraction" or x not in (0, 1):
                            score_formats[metric] = "fraction"
                        else:
                            score_formats[metric] = "binary"
        if score_formats:
            out["summary"]["score_formats"] = score_formats
        out["aggregates"] = [{"line_of_business_id": q, "contact_type": t, "date": d, "agent_id": (a or None), "attributed": bool(a), "count": c, "total": s,
                              "measures": {h: ({"weight": m[0], "sum": m[1], "weighted_sum": m[2]} | ({"levels": m[3]} if h in levelled else {})) for h, m in ms.items()}}
                             | ({"invalid_pass_columns": sorted(invalid)} if invalid else {})
                             for (q, t, d, a), (c, s, ms, invalid) in sorted(agg.items())]
        out["ok"] = True
    out["contact_ids"] = {v["cells"].get("contact_id", "").strip() for v in canon_rows} if (grain == "contact" and canon_rows) else None      # kept in memory only, to say how surveys and audits match
    out["dates_basis"] = "declared_business_dates" if grain == "agent_day" else "account_business_dates"
    buckets = defaultdict(int)
    if grain == "contact":
        columns = [field for spec in metrics.METRICS.values() for name, field in spec.get("columns", {}).get("contact", {}).items()
                   if name in ("score", "pass_flag") and field in header]
        timed_rows = []
        for v in canon_rows:
            t = datetime.fromisoformat(v["cells"]["occurred_at"].strip().replace("Z", "+00:00")).astimezone(timezone.utc)
            r = v["rec"]
            buckets[(r["line_of_business_id"], t.date().isoformat(), (t.hour * 60 + t.minute) // 15)] += 1
            local = t.astimezone(zone)
            timed_rows.append((v["date"], local.hour * 60 + local.minute, r["line_of_business_id"], r["contact_type"],
                               r["agent_id"] if v["attributed"] else None, r["handling_seconds"],
                               tuple(_num(v["cells"].get(column, "")) for column in columns)))
        out["heatmap_contacts"] = {"columns": columns, "rows": timed_rows}
    out["utc_buckets"] = [{"line_of_business_id": q, "utc_date": d, "quarter": k, "contacts": c} for (q, d, k), c in sorted(buckets.items())]
    out["decision_digest"] = decision_digest(out)
    return out


def canonical_decisions(res):
    """Decisions only: no timestamps, no execution metadata. Same inputs and policy versions give the same value."""
    recs = [{k: v for k, v in r.items() if k != "history"} | {"history": [{k: v for k, v in e.items() if k != "at"} for e in r["history"]]} for r in res["records"]]
    return {"grain": res["grain"], "ok": res["ok"], "issues": [i["code"] for i in res["issues"]], "reconciliation": res["reconciliation"],
            "records": recs, "groups": res["groups"], "policy_version": res["provenance"]["policy_version"],
            "identity_rules_version": res["provenance"]["identity_rules_version"], "normalization_version": res["provenance"]["normalization_version"]}


def decision_digest(res):
    return hashlib.sha256(C.canonical_json(canonical_decisions(res))).hexdigest()


def order_independent_view(res):
    """Group outcomes keyed by identity and content, independent of where rows sit in the file."""
    return sorted((g["identity_key"], g["kind"], g["status"], g["reason_code"], len(g["member_rows"])) for g in res["groups"])


PUBLIC_DROP = {"manifest_rows", "non_eligible", "contact_ids", "heatmap_contacts"}


def public_view(res):
    """What may leave the server: no cell values and no identity keys. Row numbers and counts only."""
    v = {k: x for k, x in res.items() if k not in PUBLIC_DROP and k not in ("aggregates", "records", "groups")}
    v["groups"] = [{k: g[k] for k in ("group_id", "kind", "status", "rule_id", "reason_code", "member_rows", "canonical_row")} for g in res["groups"]]
    v["records"] = [{k: r[k] for k in ("row", "disposition", "canonical", "reason_codes", "flags", "group_id", "contributes")} for r in res["records"]][:200]
    v["records_total"] = len(res["records"])
    return v


def _safe_cell(x):
    s = str(x)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s


def manifest_csv(res):
    """The user's own records that need attention, with values, for whoever owns the source extract."""
    buf = io.StringIO(newline="")
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(["csv_row", "fault", "record_key", "reported_values", "what_to_do", "disposition"])
    for n, code, key, det, remedy, disp in res.get("manifest_rows", []):
        w.writerow([n, code, _safe_cell(key), _safe_cell(det), remedy, disp])
    return buf.getvalue().encode("utf-8")
