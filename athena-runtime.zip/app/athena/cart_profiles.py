"""Historical CART profiles of the selected KPI at agent/business-date/work-cell grain."""
from collections import defaultdict

import numpy as np
from sklearn import __version__ as sklearn_version
from sklearn.tree import DecisionTreeRegressor

from athena import components, metric_view, relationships, targets


MIN_FIT_CELLS = 20
MIN_LATER_CELLS = 10
MIN_LEAF_AGENTS = 4
MIN_LEAF_DATES = 3
MAX_CANDIDATE_VALUES = 500_000
MAX_PRIMARY_CANDIDATES = len(relationships.PEERS) + len(components.AHT_COMPONENTS)


class _InputTooWide(Exception):
    """The report scope would exceed the work-cell limit for CART inputs."""


def _cell(row):
    return row["agent_id"], row["date"], row["line_of_business_id"], row["contact_type"]


def _pool(rows, keys=None):
    totals = defaultdict(lambda: [0, 0.0])
    for row in rows:
        if not row.get("agent_id") or not row.get("attributed", True) or not row["count"]:
            continue
        key = _cell(row)
        if keys is None or key in keys:
            totals[key][0] += row["count"]
            totals[key][1] += row["total"]
    return totals


def _predictors(primary, outcome, metric, grain, formats, optionals, scope, zone, first_later):
    source = "D01" if grain == "contact" else "D02"

    def candidate(label, unit, code, role, values, column=None):
        origin = "Primary operational data" if code == source else "Customer outcomes and quality"
        availability = "After the work cell is observed" if code == source else "When the survey or audit is recorded"
        return {"label": label, "column": column, "unit": unit, "source": code, "origin": origin, "role": role,
                "availability": availability}, values

    handled = _pool(primary, outcome)
    yield candidate("Handled contacts", "contacts", source, "Workload", {key: v[0] for key, v in handled.items()})
    for peer, label, unit, fallback in relationships.PEERS:
        if peer in (metric, "handled"):
            continue
        rows = primary if peer == "aht" else metric_view.score_rows(primary, peer, grain)
        values = _pool(rows, outcome)
        code = source
        if not any(key[1] < first_later for key in values) and fallback in optionals:
            code = fallback
            values = _pool(relationships.scoped_sample_measure(optionals[code], code, scope, zone, peer), outcome)
        if peer in ("csat", "qa_score"):
            unit = "fraction" if code == source and formats.get(peer) == "fraction" else "points"
        yield candidate(label, unit, code, "Sample coverage" if peer == "surveys" else "Peer performance",
                        {key: count if peer == "surveys" else total / count for key, (count, total) in values.items()})
    candidate_count = MAX_PRIMARY_CANDIDATES
    for code, peer, unit in (("D03", "csat", "rating points"), ("D04", "qa_score", "points")):
        if peer == metric or code not in optionals:
            continue
        columns, samples = components.sample_component_cells(optionals[code], code, scope, zone)
        candidate_count += len(columns)
        if len(outcome) * candidate_count > MAX_CANDIDATE_VALUES:
            raise _InputTooWide
        values = [defaultdict(lambda: [0, 0.0]) for _ in columns]
        for day, agent, line, driver, count, totals in samples:
            key = agent, day, line, driver
            if key in outcome:
                for pooled, total in zip(values, totals[1:], strict=True):
                    pooled[key][0] += count
                    pooled[key][1] += total
        for (column, label), pooled in zip(columns.items(), values, strict=True):
            yield candidate(label, unit, code, "Peer KPI component",
                            {key: total / count for key, (count, total) in pooled.items()}, column)
    if metric != "aht" and grain == "contact":
        for column, label in components.AHT_COMPONENTS.items():
            rows = ({**row, "count": part["weight"], "total": part["weighted_sum"]}
                    for row in primary if (part := row.get("measures", {}).get(column)))
            values = _pool(rows, outcome)
            yield candidate(label, "seconds", source, "Peer KPI component",
                            {key: total / count for key, (count, total) in values.items()}, column)


def _paths(tree, features, scale, node=0, steps=()):
    left, right = tree.children_left[node], tree.children_right[node]
    if left == right:
        yield node, steps
        return
    feature = int(tree.feature[node])
    threshold = float(tree.threshold[node])
    missing_left = bool(tree.missing_go_to_left[node])
    for child, operator, accepts_missing in ((left, "≤", missing_left), (right, ">", not missing_left)):
        # A split at infinity separates supplied values from missing values.
        condition = {"feature": feature, "operator": operator, "threshold": threshold if np.isfinite(threshold) else None,
                     "accepts_missing": accepts_missing, "has_missing": features[feature]["missing"] > 0,
                     "fit_value": float(tree.value[child, 0, 0]) * scale}
        yield from _paths(tree, features, scale, child, (*steps, condition))


def _leaf_stats(rows, outcome, minimum):
    agents = len({key[0] for key in rows})
    days = len({key[1] for key in rows})
    if len(rows) < minimum or agents < MIN_LEAF_AGENTS or days < MIN_LEAF_DATES:
        return None
    count = sum(outcome[key][0] for key in rows)
    observed = sum(outcome[key][1] for key in rows) / count
    if not np.isfinite(observed):
        return None
    return {"cells": len(rows), "agents": agents, "dates": days, "observations": count, "observed": observed}


def build(primary, selected, metric, grain, formats, optionals, scope, zone, assessment):
    """Fit a shallow weighted regression tree, then describe the same paths on later dates."""
    result = {"method": "CART regression", "library_version": sklearn_version, "paths": [], "features": [],
              "outcome_source": "D01" if grain == "contact" else "D02"}
    overall = (assessment or {}).get("overall") or {}
    result["target"] = overall.get("target") if assessment and assessment["status"] == "published" and overall.get("classified") else None
    result["target_rule"] = overall.get("target_rule") if result["target"] is not None else None
    outcome = {key: value for key, value in _pool(selected).items() if np.isfinite(value[1])}
    keys = sorted(outcome, key=lambda key: (key[1], key))
    days = sorted({key[1] for key in keys})
    result["cells"] = len(keys)
    result["observations"] = sum(outcome[key][0] for key in keys)
    if len(days) < 40:
        return result | {"reason": "At least 40 distinct business dates with eligible agent work cells are needed for the historical fit and later-date check."}
    first_later = days[-(len(days) // 4)]
    split = sum(key[1] < first_later for key in keys)
    result.update(fit_dates=[days[0], keys[split - 1][1]], later_dates=[first_later, days[-1]])
    if split < 2 * MIN_FIT_CELLS or len(keys) - split < MIN_LATER_CELLS:
        return result | {"reason": "Too few eligible agent work cells in the fit or later period."}
    size_reason = "The selected work cells and measures exceed the input limit for CART profiles."
    if len(keys) * MAX_PRIMARY_CANDIDATES > MAX_CANDIDATE_VALUES:
        return result | {"reason": size_reason}

    columns = []
    try:
        for feature, values in _predictors(primary, outcome, metric, grain, formats, optionals, scope, zone, first_later):
            with np.errstate(over="ignore", invalid="ignore"):
                column = np.array([values.get(key, np.nan) for key in keys], dtype=np.float32)
            column[~np.isfinite(column)] = np.nan
            finite = np.isfinite(column)
            if finite[:split].sum() >= MIN_FIT_CELLS and np.unique(column[:split][finite[:split]]).size >= 2:
                columns.append(column)
                result["features"].append(feature | {"missing": int((~finite).sum())})
    except _InputTooWide:
        return result | {"reason": size_reason, "features": []}
    if not columns:
        return result | {"reason": "No varying measure has enough aligned values in the fit period."}

    x = np.column_stack(columns)
    weights = np.array([outcome[key][0] for key in keys[:split]])
    y = np.array([outcome[key][1] / outcome[key][0] for key in keys[:split]])
    scale = float(np.max(np.abs(y)))
    if not scale or np.all(y == y[0]):
        return result | {"reason": "The selected KPI did not vary in the fit period."}
    tree = DecisionTreeRegressor(max_depth=2, min_samples_leaf=MIN_FIT_CELLS, random_state=0)
    tree.fit(x[:split], y / scale, sample_weight=weights)
    if tree.tree_.node_count == 1:
        return result | {"reason": "The tree found no supported split in the fit period."}
    members = defaultdict(lambda: ([], []))
    for index, node in enumerate(tree.apply(x)):
        members[node][index >= split].append(keys[index])
    result["fit_baseline"] = float(tree.tree_.value[0, 0, 0]) * scale
    for node, conditions in _paths(tree.tree_, result["features"], scale):
        fit, later = members[node]
        fit_stats = _leaf_stats(fit, outcome, MIN_FIT_CELLS)
        later_stats = _leaf_stats(later, outcome, MIN_LATER_CELLS)
        fitted = conditions[-1]["fit_value"]
        if fit_stats and later_stats and np.isfinite(fitted):
            if result["target_rule"] in ("at_or_below", "at_or_above"):
                rule = {"target": result["target"], "target_rule": result["target_rule"]}
                later_stats["target_met"] = targets.assess_value(later_stats["observed"], rule)["target_met"]
            result["paths"].append({"id": int(node), "conditions": list(conditions), "fit": fit_stats, "later": later_stats,
                                    "fitted": fitted})
    result["terminal_count"] = int(tree.get_n_leaves())
    if not result["paths"]:
        result["reason"] = "No terminal path has enough agent work cells, agents and dates in both periods."
    return result
