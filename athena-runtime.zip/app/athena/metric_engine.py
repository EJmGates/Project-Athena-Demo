"""Scoped, contact-weighted average handle time (registry M025), with a computed weighting proof.

Ratios are always recomputed from totals, never averaged. No contacts in scope means no AHT (None),
not zero. A target produces a gap only when one was given.

The weighting proof is calculated from the data in scope on every run. Nothing in it is a constant.
"""
import math

from athena import insights, metric_view, metrics, session_config as S
from athena import targets as T
from athena.cohorts import MILD, MIN_RANKED, percentile

FIELD = {"line_of_business": "line_of_business_id", "contact_type": "contact_type"}
FORMULA = "total handling seconds / handled contacts"
METHOD_ID, METHOD_VERSION, POLICY_VERSION = "M025", "0.1.0", "0.1.0"
ENGINE_VERSION = "metric_engine/1.3.0"


def _agg(rows):
    c = sum(r["count"] for r in rows); t = sum(r["total"] for r in rows)
    return {"count": c, "total": t, "value": (t / c) if c else None}


def _gap(aht, target):
    return None if aht is None or target is None else aht - target


def _grouped(rows, key, target):
    m = {}
    for r in rows: m.setdefault(r[key], []).append(r)
    out = []
    for k in sorted(m):
        a = _agg(m[k]); a["key"] = k; a["gap"] = _gap(a["value"], target); out.append(a)
    return out


def _group_charts(rows, dimension):
    """Daily pooled values and an anonymous distribution of per-agent KPI values."""
    return _group_distributions(rows, FIELD[dimension], daily=True)


def _group_distributions(rows, field, *, daily=False):
    groups = {}
    for row in rows:
        key = row.get(field)
        if key is not None and key != "":
            groups.setdefault(key, []).append(row)
    charts = []
    for key, members in sorted(groups.items()):
        agents = _grouped([r for r in members if r.get("agent_id") and r.get("attributed", True)], "agent_id", None)
        values = sorted(a["value"] for a in agents if a["value"] is not None and math.isfinite(a["value"]))
        box = None
        if len(values) >= MIN_RANKED and math.isfinite(values[-1] - values[0]):
            q1, median, q3 = (percentile(values, p) for p in (0.25, 0.5, 0.75))
            spread = MILD * (q3 - q1)
            inside = [v for v in values if q1 - spread <= v <= q3 + spread]
            box = {"q1": q1, "median": median, "q3": q3, "lower": inside[0], "upper": inside[-1],
                   "outliers": [v for v in values if v < q1 - spread or v > q3 + spread]}
        chart = {"key": key, "agent_count": len(values), "box": box}
        if not box and len(values) >= MIN_RANKED:
            chart["box_reason"] = "Values exceed the chart's numeric range."
        if daily:
            chart["by_day"] = _grouped(members, "date", None)
        else:
            total = _agg(members)
            chart.update(count=total["count"], value=total["value"] if total["value"] is not None and math.isfinite(total["value"]) else None)
        charts.append(chart)
    return charts


def group_comparison(primary, selected, metric, grain, formats, roster):
    """Additional box-plot views, using the same distributions as the selected KPI."""
    source = "D01" if grain == "contact" else "D02"
    people = {dimension: insights.DIMENSIONS[dimension] for dimension in insights.PEOPLE_DIMENSIONS}
    measures = []
    for measure, rows in [({"id": metric}, selected), *metric_view.primary_peers(primary, metric, grain, formats)]:
        peer = measure["id"] != metric
        dimensions = FIELD | people if peer else people
        enriched, _ = insights.enrich(rows, roster) if roster else (rows, None)
        groups = {}
        for dimension, field in dimensions.items():
            values = _group_distributions(enriched, field)
            if values:
                groups[dimension] = values
        if groups:
            measures.append({**measure, "source": source, "count": sum(row["count"] for row in rows),
                             "direction": metrics.get(measure["id"])["default_direction"], "groups": groups})
    return measures


NO_ATTRIBUTED = {"code": "NO-ATTRIBUTED-CONTACTS",
                 "reason": "No contact in this selection has an agent recorded, so the comparison with an average of agent averages cannot be made."}


def weighting_proof(rows, scoped):
    """Contact-weighted AHT against the unweighted mean of per-agent AHT, both from the same contacts.

    Only contacts with a recorded agent can be compared by agent, so both figures use that population and the
    proof reports the contacts left out. Scope KPIs elsewhere keep every eligible contact. Agent identifiers are
    included for operational follow-up; this explains the metric and is not an agent ranking.
    """
    att_rows = [r for r in rows if r.get("attributed", True)]
    un = _agg([r for r in rows if not r.get("attributed", True)])
    att = _agg(att_rows)
    per = _grouped(att_rows, "agent_id", None)
    usable = [a for a in per if a["value"] is not None]
    if not usable or att["value"] is None:
        return None
    unweighted = sum(a["value"] for a in usable) / len(usable)
    diff = att["value"] - unweighted
    share = sorted(({"agent_id": a["key"], "count": a["count"], "value": a["value"],
                     "volume_share": a["count"] / att["count"]} for a in usable),
                   key=lambda x: (-x["count"], x["agent_id"]))
    top = share[0]
    return {
        "formula": FORMULA,
        "contact_weighted": {"label": "Every contact counts", "formula": FORMULA,
                             "total_handling_seconds": att["total"], "handled_contacts": att["count"],
                             "value": att["value"]},
        "unweighted_agent_mean": {"label": "Average of agent averages", "formula": "sum of each agent's average / number of agents",
                                  "agents": len(usable), "value": unweighted},
        "difference_seconds": diff,
        "agents": share,
        "concentration": {"agent_id": top["agent_id"], "volume_share": top["volume_share"],
                          "top_quarter_share": sum(a["count"] for a in share[:max(1, len(share) // 4)]) / att["count"]},
        "population": {"attributed_contacts": att["count"], "attributed_seconds": att["total"],
                       "unattributed_contacts": un["count"], "unattributed_seconds": un["total"],
                       "scope_contacts": scoped["count"], "scope_seconds": scoped["total"],
                       "scope_aht_seconds": scoped["value"]},
        "narrative": _narrative(diff, top, len(usable)) + _unattributed_sentence(un),
    }


def _unattributed_sentence(un):
    if not un["count"]:
        return ""
    n = un["count"]
    return (f" {n:,} contact{'s' if n != 1 else ''} with no agent recorded {'are' if n != 1 else 'is'} counted in the average above "
            "but cannot be part of this comparison.")


def _narrative(diff, top, n_agents):
    if abs(diff) < 0.05:
        return ("Both ways of calculating give the same answer here, because contacts are spread evenly across the "
                f"{n_agents} agents in this selection.")
    d = abs(diff)
    direction = "lower" if diff > 0 else "higher"
    return (f"Averaging each agent's average would read {d:.1f} s {direction}. It gives every agent the same weight, "
            f"while {top['agent_id']} alone handled {top['volume_share'] * 100:.1f}% of the contacts in this selection. "
            "Counting every contact reflects the time actually spent.")


def coverage(non_eligible, lines_of_business, period, eligible_contacts, unattributed_contacts):
    """What was set aside, placed against the selected scope. Counts only; no thresholds."""
    q = set(lines_of_business); s, e = period
    c = {"quarantined": 0, "held": 0, "collapsed_copies": 0}; unplaced = 0; contacts_known = True; set_aside_contacts = 0
    for r in non_eligible or []:
        if r["role"] == "collapsed_copy":
            if r["line_of_business_id"] in q and r["date"] and s <= r["date"] <= e: c["collapsed_copies"] += 1
            continue
        if r["line_of_business_id"] is None or r["date"] is None:
            unplaced += 1
            continue
        if r["line_of_business_id"] in q and s <= r["date"] <= e:
            c[r["role"]] += 1
            if r["contacts"] is None: contacts_known = False
            else: set_aside_contacts += r["contacts"]
    return {"eligible_contacts": eligible_contacts, "set_aside_in_scope": {"quarantined": c["quarantined"], "held": c["held"]},
            "set_aside_contacts_in_scope": set_aside_contacts if contacts_known else None,
            "unplaced_set_aside": unplaced, "collapsed_copies_in_scope": c["collapsed_copies"], "unattributed_contacts": unattributed_contacts,
            "any_set_aside": bool(c["quarantined"] or c["held"] or unplaced)}


def _plural(n, one, many):
    return f"{n:,} {one if n == 1 else many}"


def population_statement(cov):
    """Plain statement of what a figure applies to. It never claims account-wide coverage."""
    n = cov["eligible_contacts"]; q = cov["set_aside_in_scope"]["quarantined"]; h = cov["set_aside_in_scope"]["held"]; u = cov["unplaced_set_aside"]
    text = f"This figure applies to the {_plural(n, 'eligible contact', 'eligible contacts')} in your selection."
    parts = []
    if q: parts.append(f"{_plural(q, 'record was', 'records were')} set aside as invalid")
    if h: parts.append(f"{_plural(h, 'record is', 'records are')} held because of a conflict")
    if u: parts.append(f"{_plural(u, 'more record', 'more records')} could not be placed in a Line of Business or date, so their effect on this selection is unknown")
    if parts: text += " " + "; ".join(parts) + "."
    text += " Athena cannot check that the file holds every contact the account handled."
    return {"applies_to": "eligible_records", "coverage_established": False, "text": text,
            "eligible_contacts": n, "set_aside_in_scope": dict(cov["set_aside_in_scope"]), "unplaced_set_aside": u,
            "collapsed_copies_in_scope": cov["collapsed_copies_in_scope"], "unattributed_contacts": cov["unattributed_contacts"],
            "partial": cov["any_set_aside"]}


def evidence(scoped, proof, scope, source, exclusions=None, coverage_=None, statement=None, assessment=None, provenance=None, target_kind=None, group_assessments=None):
    """One evidence record for this result, shaped to contracts/evidence.schema.json."""
    ok = scoped["count"] > 0
    n_excluded = (exclusions or {}).get("excluded_row_count", 0)
    limits = ["Describes the selected data only. It does not show why handle time differs from target."]
    if statement:
        limits.append(statement["text"])
        if statement["unattributed_contacts"]:
            limits.append(f"{statement['unattributed_contacts']:,} contacts with no agent recorded are counted in the average but excluded from any comparison that depends on the agent.")
    partial = bool(statement and statement["partial"])
    allowed = ["observed_scoped_contact_weighted_aht", "observed_descriptive_target_gap"]
    prohibited = ["causation", "statistical_significance", "forecast", "unweighted_agent_averaging"]
    if assessment is not None:
        if assessment["status"] == "published":
            allowed += ["observed_descriptive_target_comparison_by_period", "observed_descriptive_specification_conformance"]
            limits += assessment["limitations"]
            if assessment["multiple_targets"]: limits.append("The selection contains more than one applicable target, so each period is assessed against its own target and the overall figure is not.")
            if assessment["overall"] and not assessment["overall"]["classified"]: prohibited.append("target_attainment_for_a_period_spanning_a_target_change")
        else:
            limits.append(assessment["reason"]); partial = True
    if target_kind == "conditional_override":
        limits.append("A conditional comparison uses a target the user entered for this session. It is not official target compliance.")
        prohibited.append("official_target_compliance_from_a_user_entered_target")
    if n_excluded:
        limits.append(f"{n_excluded} rows were excluded under exclusion policy {exclusions['policy_version']} and are listed in the exclusion ledger.")
    diagnostics = [{"diagnostic_id": "POSITIVE-DENOMINATOR", "status": "pass" if ok else "fail",
                    "reason": "Handled contacts in scope is above zero." if ok else "No handled contacts in scope."}]
    if ok and not proof:
        diagnostics.append({"diagnostic_id": "AGENT-WEIGHTING-PROOF", "status": "not_applicable",
                            "reason": NO_ATTRIBUTED["reason"]})
    if proof:
        diagnostics.append({"diagnostic_id": "CONTACT-WEIGHTING", "status": "pass",
                            "reason": f"Recomputed from totals; differs from the unweighted agent mean by {proof['difference_seconds']:.1f} s."})
    return {
        "schema_version": "0.1.0", "evidence_id": f"EVIDENCE-{METHOD_ID}-{source['fingerprint']}",
        "run_id": source["run_id"], "snapshot_id": source["snapshot_id"],
        "method_id": METHOD_ID, "method_version": METHOD_VERSION,
        "result_status": ("ready_with_limitations" if (partial or (n_excluded and statement is None)) else "ready") if ok else "not_applicable",
        "estimand": "Contact-weighted average handle time for the selected account, Lines of Business and period.",
        "data_lineage": {
            "dataset_id": source["dataset_id"], "dataset_views": ["analytic_observation"], "grain": source["grain"],
            "population_definition": f"Rows for account {scope['account']}, Lines of Business {', '.join(scope['lines_of_business'])}, {scope['start']} to {scope['end']}.",
            "source_record_count": source["source_rows"], "valid_record_count": source["source_rows"] - n_excluded,
            "missing_record_count": 0, "excluded_record_count": n_excluded, "paired_count": None, "cluster_count": None,
            "handled_contacts": scoped["count"],
            "exclusion_reasons": [{"reason_code": e["code"], "record_count": e["row_count"]} for e in (exclusions or {}).get("entries", [])],
            "derivation_version": METHOD_VERSION,
            "count_accounting_note": "Duration totals divided by contact totals. Ratios are recomputed at every level and never averaged."
            + (f" Source rows = canonical eligible + collapsed copies ({exclusions.get('collapsed_copies', 0)}) + quarantined + held." if exclusions and "collapsed_copies" in exclusions else ""),
        },
        "method_selection": {
            "selected_method": "ratio_of_duration_totals_to_contact_totals",
            "rationale": "The contractual definition of handle time is a ratio of totals over the confirmed scope.",
            "eligibility_checks": [{"check_id": "POSITIVE-DENOMINATOR", "outcome": "pass" if ok else "fail",
                                    "reason": "Handled contacts in scope is above zero." if ok else "No handled contacts in scope."}],
            "policy_version": POLICY_VERSION,
        },
        "numerical_outputs": {"handled_contacts": scoped["count"], "total_handling_seconds": scoped["total"],
                              "aht_seconds": scoped["value"], "target_seconds": scoped["target_value"],
                              "target_gap_seconds": scoped["gap"], "weighting_proof": proof,
                              **({"target_assessment": assessment, "configuration_provenance": provenance} if assessment is not None else {}),
                              **({"group_target_assessments": group_assessments} if group_assessments else {}),
                              **({"target_kind": target_kind} if target_kind else {})},
        "diagnostics": diagnostics, "visual_ids": [],
        "allowed_claims": allowed,
        "prohibited_claims": prohibited,
        "limitations": limits,
    }


def result(aggregates, lines_of_business, period, target_value=None, group_by=None, scope=None, source=None, exclusions=None, quality=None,
           versions=None, ambiguity=None, layout=None, contact_types=None, provenance=None, target_kind=None,
           config=None, business_timezone=None, group_dimensions=None, dates_basis=None):
    s, e = period
    rows = [r for r in aggregates if r["line_of_business_id"] in set(lines_of_business) and s <= r["date"] <= e and (contact_types is None or r["contact_type"] in set(contact_types))]
    out = dict(_agg(rows), target_value=target_value)
    out["target_kind"] = (target_kind or "entered") if target_value is not None else None
    out["gap"] = _gap(out["value"], target_value)
    out["by_day"] = _grouped(rows, "date", target_value)
    out["by_group"] = _grouped(rows, FIELD[group_by], target_value) if group_by else None
    out["weighting_proof"] = weighting_proof(rows, out)
    out["weighting_proof_unavailable"] = None if out["weighting_proof"] or not out["count"] else dict(NO_ATTRIBUTED)
    if quality is not None:
        un = sum(r["count"] for r in rows if not r.get("attributed", True))
        out["coverage"] = coverage(quality.get("non_eligible"), lines_of_business, period, out["count"], un)
        out["population_statement"] = population_statement(out["coverage"])
    else:
        out["coverage"], out["population_statement"] = None, None
    out["target_assessment"] = (T.assess(rows, versions, lines_of_business, period, ambiguity, layout or "contact", business_timezone, dates_basis=dates_basis)
                                if versions and any(("target" in v or "upper_specification_limit" in v or "lower_specification_limit" in v) for v in versions) else None)
    out["group_assessments"] = (T.assess_groups(rows, group_by, config, lines_of_business, period, ambiguity, layout or "contact", business_timezone, dates_basis=dates_basis)
                                if (group_by and config is not None and S.has_scoped_targets(config)) else None)
    if group_dimensions:
        out["by_groups"] = {dim: _grouped(rows, FIELD[dim], None) for dim in group_dimensions}
        out["group_charts"] = {dim: _group_charts(rows, dim) for dim in group_dimensions}
        if FIELD.keys() <= set(group_dimensions):
            combinations = {}
            for row in rows:
                key = (row["line_of_business_id"], row["contact_type"])
                combinations.setdefault(key, []).append(row)
            out["combined_daily"] = [
                {"line_of_business": line, "contact_type": driver, "by_day": _grouped(members, "date", None)}
                for (line, driver), members in sorted(combinations.items())
            ]
        # Both dimensions are views of the same rows, never independent populations.
        scoped_rules = config is not None and any(m.get("applies_to") and any(k in m for k in ("target", "lower_specification_limit", "upper_specification_limit")) for m in config.get("metrics", []))
        out["group_assessments_by_dimension"] = {dim: T.assess_groups(rows, dim, config, lines_of_business, period, ambiguity, layout or "contact", business_timezone, dates_basis=dates_basis) for dim in group_dimensions} if scoped_rules else None
    out["conditional"] = ({"label": "Conditional comparison, not official target compliance", "target_value": target_value, "value": out["value"], "gap": out["gap"]}
                          if out["target_kind"] == "conditional_override" else None)
    if scope and source:
        out["evidence"] = [evidence(out, out["weighting_proof"], scope, source, exclusions, out["coverage"], out["population_statement"],
                                    out["target_assessment"], provenance, out["target_kind"], out["group_assessments"])]
        if group_dimensions:
            numbers = out["evidence"][0]["numerical_outputs"]
            numbers["group_breakdowns"] = out["by_groups"]
            if out["group_assessments_by_dimension"] is not None:
                numbers["group_target_assessments_by_dimension"] = out["group_assessments_by_dimension"]
                numbers["configuration_provenance"] = provenance
    return out
