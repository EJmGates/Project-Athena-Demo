"""Fixed, versioned, data-driven questionnaire: answers (+ facts detected in the upload) -> plan.

The plan lists the analyses to attempt, the assumptions to confirm, the limits to state and the datasets to request.
It never asks for a method or statistical setting, and it never preselects an answer. Method eligibility is still
decided later by the trusted engine from the data; the questionnaire only narrows what is attempted.
"""
import json
from calendar import monthrange
from datetime import date, timedelta
from pathlib import Path

from athena.upload_checks import REQUIRED

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "config"


def load(path=None):
    return json.loads((Path(path) if path else CONFIG / "questionnaire.json").read_text(encoding="utf-8"))


def registry():
    d = json.loads((ROOT / "vendor/handoff/catalogs/analysis_registry.json").read_text(encoding="utf-8"))
    return {m["method_id"]: m for m in d["methods"]}


def implemented():
    return set(json.loads((CONFIG / "capabilities.json").read_text(encoding="utf-8"))["implemented_methods"])


def _distinct(detected, field):
    return (detected or {}).get("distinct", {}).get(field, [])


def _shown(q, answers, ctx=None):
    if q.get("availability") != "available":
        return False
    ctx = ctx or {}
    for c in q.get("show_when", []):
        if "context" in c and not ctx.get(c["context"]): return False
        if "context_absent" in c and ctx.get(c["context_absent"]): return False
        v = answers.get(c["answer"])
        if "includes" in c and not (isinstance(v, list) and c["includes"] in v): return False
        if "equals" in c and v != c["equals"]: return False
    return True


def _options(q, detected, profile=None):
    """Options a user may pick now. Derived options come from facts in the upload.

    A saved configuration that lists Lines of Business restricts the Line of Business choices to those. This holds with or
    without an organization module: the restriction is the user's own explicit configuration."""
    if "options_from" in q:
        vals = _distinct(detected, q["options_from"])
        if q["options_from"] == "line_of_business_id" and profile and profile.get("line_of_business_ids"):
            vals = [v for v in vals if v in set(profile["line_of_business_ids"])]
        if q["options_from"] == "contact_type" and profile and profile.get("contact_types"):
            vals = [v for v in vals if v in set(profile["contact_types"])]
        return [{"id": v, "label": v} for v in vals]
    out = []
    for o in q.get("options", []):
        if o.get("availability", "available") != "available": continue
        need = o.get("available_if", {}).get("distinct_gt")
        if need is not None and len(_distinct(detected, o["field"])) <= need: continue
        out.append({"id": o["id"], "label": o["label"]})
    return out


def _valid_date_range(answer, detected):
    try:
        start, end = date.fromisoformat(answer["start"]), date.fromisoformat(answer["end"])
    except (KeyError, TypeError, ValueError):
        return False
    if start > end:
        return False
    lo, hi = (detected or {}).get("date_min"), (detected or {}).get("date_max")
    return not (lo and hi and (answer["start"] < lo or answer["end"] > hi))


def _valid(q, a, opts, detected):
    t = q["type"]
    if t == "multi": return isinstance(a, list) and len(a) > 0 and len(set(a)) == len(a) and all(x in {o["id"] for o in opts} for x in a)
    if t == "single": return isinstance(a, str) and a in {o["id"] for o in opts}
    if t == "number_with_unit":
        return (isinstance(a, dict) and isinstance(a.get("value"), (int, float)) and not isinstance(a["value"], bool)
                and a["value"] > 0 and a.get("unit") in {u["id"] for u in q["units"]}
                and (not q.get("requires_confirmation") or a.get("confirmed") is True))
    if t == "date_range":
        return _valid_date_range(a, detected)
    return False


def target_seconds(cfg, answers, qid="target"):
    q = next(x for x in cfg["questions"] if x["id"] == qid)
    a = answers.get(qid)
    if not _valid(q, a, [], None): return None
    return a["value"] * next(u["to_seconds"] for u in q["units"] if u["id"] == a["unit"])


def date_bounds(detected, configuration):
    account = (configuration or {}).get("account", {})
    start, end = account.get("coverage_start"), account.get("coverage_end")
    if not detected or not (start or end):
        return detected, None
    last = (date.fromisoformat(end) - timedelta(days=1)).isoformat() if end else None
    file_min, file_max = detected["date_min"], detected["date_max"]
    lo = max(file_min, start) if start else file_min
    hi = min(file_max, last) if last else file_max
    return dict(detected, date_min=lo, date_max=hi), {
        "start": start, "last_day": last, "outside": (lo, hi) != (file_min, file_max), "overlap": lo <= hi
    }


def cockpit_period(answer, file_detected, bounds, eligible_dates=None):
    """Use the completed months at the end of the upload, clipped to the allowable dates."""
    if not bounds or bounds["date_min"] > bounds["date_max"]:
        return None
    if answer is not None:
        return answer if _valid_date_range(answer, bounds) else None
    lo, hi = bounds["date_min"], bounds["date_max"]
    if eligible_dates:
        lo, hi = max(lo, eligible_dates[0]), min(hi, eligible_dates[-1])
    dates = [day for day in eligible_dates if lo <= day <= hi] if eligible_dates is not None else [lo, hi]
    if not dates:
        return None
    file_end = date.fromisoformat(eligible_dates[-1] if eligible_dates else file_detected["date_max"])
    last_month_end = file_end.replace(day=monthrange(file_end.year, file_end.month)[1])
    if file_end != last_month_end and file_end.year == 1 and file_end.month == 1:
        return {"start": dates[0], "end": dates[-1]}
    if file_end != last_month_end:
        last_month_end = file_end.replace(day=1) - timedelta(days=1)
    month_index = max(0, (last_month_end.year - 1) * 12 + last_month_end.month - 6)
    year_index, month_index = divmod(month_index, 12)
    first_month_start = date(year_index + 1, month_index + 1, 1)
    start, end = max(lo, first_month_start.isoformat()), min(hi, last_month_end.isoformat())
    if start <= end and (eligible_dates is None or any(start <= day <= end for day in dates)):
        return {"start": start, "end": end}
    return {"start": dates[0], "end": dates[-1]}


def plan(answers, detected=None, cfg=None, profile=None, configuration=None, cockpit=False, *, eligible_dates=None):
    """profile: a stored account configuration matched to the upload, or None.

    A matched profile fills the target field, because a contractual target is a confirmed business fact
    rather than a guess. The plan says where it came from and the user can still change it."""
    cfg = cfg or load(); reg = registry(); impl = implemented()
    if cockpit:
        import copy
        cfg = copy.deepcopy(cfg)
        for question in cfg["questions"]:
            if question["id"] in ("target", "target_override"):
                question["availability"] = "mapped_in_cockpit"
            if question["id"] == "group_dimension": question["availability"] = "all_groups"
        cfg["questions"].insert(-1, {"id": "scope_contact_types", "phase": "after_upload", "type": "multi", "required": True,
            "availability": "available", "prompt": "Which contact types should be included?", "options_from": "contact_type", "bulk_select": True})
    answers = dict(answers or {}); detected = detected or None
    report_groups = cfg.get("cockpit_report_questions", []) if cockpit else []
    report_panels = None
    report_options = {option["id"]: option for group in report_groups for option in group["options"]}
    requested = answers.get("report_questions")
    if cockpit and "report_questions" in answers and isinstance(requested, list):
        selected = {key for key in requested if isinstance(key, str)}
        report_panels = list(dict.fromkeys(
            panel for key, option in report_options.items() if key in selected for panel in option["panels"]
        ))

    goal_def = next(x for x in cfg["questions"] if x["id"] == "goal")
    locked = goal_def.get("locked", [])
    chosen = [g for g in (answers.get("goal") or []) if isinstance(g, str) and g not in locked]
    answers["goal"] = locked + [g for g in dict.fromkeys(chosen)]      # locked questions are always chosen, first
    from athena import session_config as SC
    cstatus, used = None, None
    if configuration is not None and profile is None:
        acct = ((detected or {}).get("accounts") or [None])[0]
        if detected and acct and acct != configuration["account"]["account_id"] and not cockpit:
            cstatus = {"applied": False, "code": "CONFIG-ACCOUNT-MISMATCH", "configuration": f"{configuration['configuration_id']} {configuration['configuration_version']}",
                       "text": f"The active configuration is for account {configuration['account']['account_id']}, and this file is for account {acct}. It is not applied."}
        else:
            used = configuration; profile = SC.profile_view(used)
            cstatus = {"applied": True, "configuration": f"{used['configuration_id']} {used['configuration_version']}"}
            if cockpit and detected:
                profile = dict(profile, line_of_business_ids=_distinct(detected, "line_of_business_id"), contact_types=_distinct(detected, "contact_type"))
    versions = SC.metric_versions(used, SC.primary_metric(used)) if used else []
    file_detected = detected
    detected, date_cov = date_bounds(detected, used)
    ctx = {"target_versions": bool(used) and SC.has_target_versions(used)}
    prefilled = {}
    if profile and profile.get("target_seconds") is not None and answers.get("target") is None:
        answers["target"] = {"value": profile["target_seconds"], "unit": "seconds"}
        prefilled["target"] = {"profile_id": profile["profile_id"], "profile_version": profile["profile_version"]}
    questions, missing, invalid, derived = [], [], [], []
    clean = {}
    for q in cfg["questions"]:
        if not _shown(q, clean, ctx) or (q["phase"] == "after_upload" and not detected):
            continue
        opts = _options(q, detected, profile)
        auto = None
        if q.get("auto_when_single") and len(opts) == 1:
            auto = opts[0]["id"]; clean[q["id"]] = auto
            derived.append({"question": q["id"], "value": auto, "label": opts[0]["label"]})
        if auto is None and q["type"] in ("single", "multi") and not opts:
            questions.append(dict(id=q["id"], phase=q["phase"], type=q["type"], prompt=q["prompt"], options=[], answered=False, unavailable=True))
            continue
        a = answers.get(q["id"])
        if cockpit and detected:
            if q["id"] in ("scope_lines_of_business", "scope_contact_types") and a is None: a = [o["id"] for o in opts]
            if q["id"] == "scope_period" and a is None:
                a = cockpit_period(None, file_detected, detected, eligible_dates)
        ok = auto is not None or (a is not None and _valid(q, a, opts, detected))
        if a is not None and auto is None and not ok: invalid.append(q["id"])
        if ok and auto is None: clean[q["id"]] = a
        if q.get("required") and not ok and auto is None: missing.append(q["id"])
        item = dict(id=q["id"], phase=q["phase"], type=q["type"], prompt=q["prompt"], hint=q.get("hint"), options=opts,
                    answered=ok, auto=auto, required=q.get("required", False))
        if q.get("locked"): item["locked"] = list(q["locked"])
        if q["type"] == "number_with_unit": item["units"] = [{"id": u["id"], "label": u["label"]} for u in q["units"]]
        if q.get("requires_confirmation"): item["requires_confirmation"] = True; item["confirmation_label"] = q["confirmation_label"]
        if q["type"] == "date_range": item["bounds"] = {"min": (detected or {}).get("date_min"), "max": (detected or {}).get("date_max"), "file_min": (file_detected or {}).get("date_min"), "file_max": (file_detected or {}).get("date_max")}
        if q.get("bulk_select"): item["bulk_select"] = True
        questions.append(item)

    analyses, assumptions, restrictions, views, requests, sections = {}, [], [], [], {}, []
    goal_q = next(x for x in cfg["questions"] if x["id"] == "goal")
    for gid in (clean.get("goal") or []):
        eff = next(o for o in goal_q["options"] if o["id"] == gid)["effects"]
        for m in eff.get("methods", []):
            cur = analyses.setdefault(m["id"], {"method_id": m["id"], "title": reg[m["id"]]["title"], "why": [],
                                                 "admission_status": reg[m["id"]]["admission_status"], "available_now": m["id"] in impl})
            cur["why"].append(m["why"])
        assumptions += [x for x in eff.get("assumptions", []) if x not in assumptions]
        restrictions += [x for x in eff.get("restrictions", []) if x not in restrictions]
        views += [v for v in eff.get("views", []) if v not in views]
        sections += [s for s in eff.get("sections", []) if s not in sections]
        for r in eff.get("dataset_requests", []):
            cur = requests.setdefault(r["id"], {"prefer": None, "why": None})
            if r.get("prefer") and not cur["prefer"]: cur["prefer"], cur["why"] = r["prefer"], r.get("why")
    if report_panels is not None:
        clean["report_questions"] = [key for key in report_options if key in selected]
        sections = ["happened"]
        factor_panels = {"contact-performance", "driver-impact", "period-change", "constraints", "shortfalls", "relationships", "cart", "component-movement"}
        if factor_panels.intersection(report_panels):
            sections.append("factors")
        if "projection" in report_panels:
            sections.append("ahead")
        sections.append("help")
    secs, kind = target_seconds(cfg, clean), None
    if secs is not None:
        kind = "entered"
        tq = next(x for x in cfg["questions"] if x["id"] == "target")
        assumptions += [s.format(target_seconds=f"{secs:g}") for s in tq["effects_provided"]["assumptions"]]
    osecs = target_seconds(cfg, clean, "target_override") if ctx["target_versions"] else None
    if osecs is not None:
        secs, kind = osecs, "conditional_override"
        oq = next(x for x in cfg["questions"] if x["id"] == "target_override")
        assumptions += [s.format(target_seconds=f"{osecs:g}") for s in oq["effects_provided"]["assumptions"]]
    if ctx["target_versions"]:
        assumptions.append("Targets and limits use the mapping supplied for this analysis." if cockpit else f"Targets come from configuration {used['configuration_id']} {used['configuration_version']}. Each applies only to its own dates, and specification limits are stated separately from targets.")
    gd = next((x for x in questions if x["id"] == "group_dimension"), None)
    if gd and gd.get("unavailable"):
        restrictions += [r for r in next(x for x in cfg["questions"] if x["id"] == "group_dimension")["when_no_options"]["restrictions"]]
        views = [v for v in views if v != "group"]
    reqs = []
    for rid, r in requests.items():
        base = cfg["dataset_requests"][rid]
        reqs.append({"id": rid, "label": base["label"], "required": True, "preferred_grain": r["prefer"], "why": r["why"],
                     "accepted": [{"grain": g, "label": base["grain_labels"][g], "template": base["templates"][g], "columns": REQUIRED[g]} for g in base["accepted_grains"]]})
    scope_restrictions = None
    if profile and profile.get("line_of_business_ids") and detected:
        left_out = [v for v in _distinct(detected, "line_of_business_id") if v not in set(profile["line_of_business_ids"])]
        if left_out:
            scope_restrictions = {"configuration": f"{profile['profile_id']} {profile['profile_version']}", "lines_of_business_covered": [v for v in _distinct(detected, "line_of_business_id") if v in set(profile["line_of_business_ids"])], "lines_of_business_not_covered": left_out}
            restrictions.append({"view": "overview", "text": "Lines of Business in your file that your saved configuration does not cover are not analysed: " + ", ".join(left_out) + ". Add them to the configuration to include them."})
    allowed_types, coverage_dates = None, None
    if used and detected:
        allowed_types = _distinct(detected, "contact_type") if cockpit else list(used["account"].get("contact_types", []))
        types_left = [v for v in _distinct(detected, "contact_type") if v not in set(allowed_types)]
        if types_left:
            scope_restrictions = dict(scope_restrictions or {"configuration": f"{used['configuration_id']} {used['configuration_version']}", "lines_of_business_covered": _distinct(detected, "line_of_business_id"), "lines_of_business_not_covered": []},
                                      contact_types_not_covered=types_left)
            restrictions.append({"view": "overview", "text": "Contact types in your file that your configuration does not cover are not analysed: " + ", ".join(types_left) + ". Add them to the configuration to include them."})
        coverage_scope = clean.get("scope_period") if cockpit else {
            "start": detected.get("date_min"), "end": detected.get("date_max")
        }
        if ctx["target_versions"] and coverage_scope and coverage_scope["start"]:
            gaps = SC.uncovered_ranges(versions, coverage_scope["start"], coverage_scope["end"])
            coverage_dates = [{"from": a, "to": b} for a, b in gaps]
            for a, b in gaps:
                restrictions.append({"view": "overview", "text": f"No target applies from {a} to {b}. Those dates are in the average but have no target comparison."})
    if date_cov and date_cov["outside"]:
        span = (f"{date_cov['start'] or 'the start'} to {date_cov['last_day'] or 'the latest date'}")
        restrictions.append({"view": "overview", "text": f"Your configuration covers {span}. Dates in your file outside that are not analysed."})
    if profile and profile.get("confirmed_by"):
        for line in (f"Handle time is measured as: {profile['definition']}",
                     (f"Account definitions and coverage come from configuration {profile['profile_id']} {profile['profile_version']}, confirmed by {profile['confirmed_by']}." if cockpit else f"These facts come from configuration {profile['profile_id']} {profile['profile_version']}, confirmed by {profile['confirmed_by']}.") ):
            if line not in assumptions: assumptions.append(line)
    if cockpit and clean.get("scope_contact_types"):
        allowed_types = [t for t in clean["scope_contact_types"] if allowed_types is None or t in allowed_types]
    return {"version": cfg["version"], "questions": questions,
            **({"cockpit_report_questions": report_groups, "report_panels": report_panels} if cockpit else {}), "prefilled": prefilled, "scope_restrictions": scope_restrictions,
            "profile": profile, "missing": missing, "invalid": invalid, "derived": derived,
            "ready_for_upload": not any(x["phase"] == "before_upload" for x in questions if x["id"] in missing) and bool(clean.get("goal")),
            "complete": not missing and bool(clean.get("goal")),
            "analyses": list(analyses.values()), "assumptions": assumptions, "restrictions": restrictions, "views": views,
            "sections": sections, "dataset_requests": reqs, "target_value": secs, "target_kind": kind, "answers": clean,
            "configuration_status": cstatus, "target_mode": "versions" if ctx["target_versions"] else ("entered" if secs is not None else "none"),
            "target_versions": SC.summary(used)["targets"] if ctx["target_versions"] else [], "allowed_contact_types": allowed_types, "target_coverage": coverage_dates,
            "date_coverage": date_cov, "official_targets_apply": ctx["target_versions"], "scoped_targets_apply": bool(used) and SC.has_scoped_targets(used)}
