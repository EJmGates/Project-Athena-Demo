"""Run identity, idempotency, conflict and recovery rules (local, host-neutral).

Local reference of the proposed contract in contracts/api.openapi.json (submitRun).
It is stdlib + sqlite3 and proves the contract rules only, not any hosted behavior.
"""
import hashlib, json, sqlite3, uuid
from datetime import datetime, timezone

PIN_FIELDS = ("source_sha256", "mapping_version", "profile_id", "profile_version",
              "engine_version", "registry_version", "rules_version", "baseline_version")


class ResultConflict(Exception):
    """A different result was offered for an already-published run."""


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def fingerprint(intake, pins):
    missing = [f for f in PIN_FIELDS if not isinstance(pins.get(f), str) or not pins[f].strip()]
    if missing:
        raise ValueError("missing pins: " + ",".join(missing))
    return hashlib.sha256(canonical({"intake": intake, "pins": {f: pins[f] for f in PIN_FIELDS}})).hexdigest()


def iso(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def error(code, message, request_id, issues=None):
    e = {"error_code": code, "message": message, "request_id": request_id or "unknown"}
    if issues:
        e["field_issues"] = issues
    return e


class RunStore:
    def __init__(self, validator, path=":memory:", clock=None, id_factory=None):
        self.v = validator
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.new_id = id_factory or (lambda: "RUN-" + uuid.uuid4().hex[:16])
        self.db = sqlite3.connect(path, isolation_level=None)
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS runs(idem_key TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, run_id TEXT UNIQUE NOT NULL,
          job_state TEXT NOT NULL, stage TEXT NOT NULL, attempt INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL, reason_code TEXT, message TEXT);
        CREATE TABLE IF NOT EXISTS results(run_id TEXT PRIMARY KEY, payload BLOB NOT NULL, published_at TEXT NOT NULL);""")

    def _now(self):
        return iso(self.clock())

    def submit(self, key, intake, pins):
        rid = intake.get("request_id") if isinstance(intake, dict) else None
        if not isinstance(key, str) or not key.strip():
            return 400, error("IDEMPOTENCY-KEY-REQUIRED", "An idempotency key is required.", rid)
        errs = self.v.errors(intake, "intake.schema.json")
        if errs:
            return 400, error("INVALID-INTAKE", "The request does not meet the fixed intake contract.", rid,
                              [{"field": p, "reason_code": r.upper(), "message": "Invalid or missing value."} for p, r in errs])
        try:
            fp = fingerprint(intake, pins)
        except ValueError as ex:
            return 400, error("MISSING-VERSION-PIN", str(ex), rid)
        self.db.execute("BEGIN IMMEDIATE")
        try:
            row = self.db.execute("SELECT fingerprint, run_id FROM runs WHERE idem_key=?", (key,)).fetchone()
            if row and row[0] != fp:
                self.db.execute("COMMIT")
                return 409, error("IDEMPOTENCY-CONFLICT", "This key was already used with different inputs or versions.", rid)
            if not row:
                now = self._now()
                self.db.execute("INSERT INTO runs(idem_key,fingerprint,run_id,job_state,stage,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                                (key, fp, self.new_id(), "queued", "accepted", now, now))
            self.db.execute("COMMIT")
        except Exception:
            self.db.execute("ROLLBACK"); raise
        run_id = self.db.execute("SELECT run_id FROM runs WHERE idem_key=?", (key,)).fetchone()[0]
        return 202, self.status(run_id)

    def status(self, run_id):
        r = self.db.execute("SELECT run_id,job_state,stage,created_at,updated_at,reason_code,message FROM runs WHERE run_id=?", (run_id,)).fetchone()
        if not r:
            return None
        has = self.db.execute("SELECT 1 FROM results WHERE run_id=?", (run_id,)).fetchone() is not None
        return {"schema_version": "0.1.0", "run_id": r[0], "job_state": r[1], "stage": r[2], "created_at": r[3],
                "updated_at": r[4], "result_available": has, "reason_code": r[5], "message": r[6]}

    def claim_next(self):
        self.db.execute("BEGIN IMMEDIATE")
        row = self.db.execute("SELECT run_id FROM runs WHERE job_state='queued' ORDER BY created_at, run_id LIMIT 1").fetchone()
        if row:
            self.db.execute("UPDATE runs SET job_state='running', stage='started', attempt=attempt+1, updated_at=? WHERE run_id=?", (self._now(), row[0]))
        self.db.execute("COMMIT")
        return row[0] if row else None

    def checkpoint(self, run_id, stage):
        self.db.execute("UPDATE runs SET stage=?, updated_at=? WHERE run_id=? AND job_state='running'", (stage, self._now(), run_id))

    def publish_result(self, run_id, result):
        """Atomic publish. Replaying the identical result is a no-op; a different one is refused."""
        payload = canonical(result)
        self.db.execute("BEGIN IMMEDIATE")
        try:
            old = self.db.execute("SELECT payload FROM results WHERE run_id=?", (run_id,)).fetchone()
            if old:
                self.db.execute("COMMIT")
                if old[0] != payload:
                    raise ResultConflict(run_id)
                return False
            now = self._now()
            self.db.execute("INSERT INTO results(run_id,payload,published_at) VALUES(?,?,?)", (run_id, payload, now))
            self.db.execute("UPDATE runs SET job_state='completed', stage='published', updated_at=? WHERE run_id=?", (now, run_id))
            self.db.execute("COMMIT")
            return True
        except ResultConflict:
            raise
        except Exception:
            self.db.execute("ROLLBACK"); raise

    def fail(self, run_id, reason_code, message):
        self.db.execute("UPDATE runs SET job_state='failed', reason_code=?, message=?, updated_at=? WHERE run_id=? AND job_state='running'",
                        (reason_code, message, self._now(), run_id))

    def recover(self, stale_after_seconds):
        """Requeue runs stuck in 'running'. A run whose result is already published is completed, never rerun."""
        cutoff = iso(self.clock().fromtimestamp(self.clock().timestamp() - stale_after_seconds, timezone.utc))
        self.db.execute("BEGIN IMMEDIATE")
        stuck = [r[0] for r in self.db.execute("SELECT run_id FROM runs WHERE job_state='running' AND updated_at<=?", (cutoff,))]
        requeued = []
        for rid in stuck:
            if self.db.execute("SELECT 1 FROM results WHERE run_id=?", (rid,)).fetchone():
                self.db.execute("UPDATE runs SET job_state='completed', stage='published', updated_at=? WHERE run_id=?", (self._now(), rid))
            else:
                self.db.execute("UPDATE runs SET job_state='queued', stage='requeued', updated_at=? WHERE run_id=?", (self._now(), rid))
                requeued.append(rid)
        self.db.execute("COMMIT")
        return requeued

    def result(self, run_id):
        r = self.db.execute("SELECT payload FROM results WHERE run_id=?", (run_id,)).fetchone()
        return json.loads(r[0]) if r else None
