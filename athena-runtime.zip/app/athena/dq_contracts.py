"""Loading and checking of the versioned data-quality contracts (Increment 1, stage 1).

Contracts: config/data_quality_policy.json (dispositions), config/record_identity_rules.json (duplicate rules
and normalization), contracts/local/contact_record_optional_agent.schema.json (versioned schema variant).
The strict v0.1.0 schemas are never edited. A schema variant is chosen from the policy, per layout, never by a
record's own content.
"""
import hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
POLICY_PATH = ROOT / "config" / "data_quality_policy.json"
RULES_PATH = ROOT / "config" / "record_identity_rules.json"
DISPOSITIONS = {"valid", "quarantine", "hold", "flag", "block", "withhold"}
LEVELS = {"source_record", "record_group", "metric", "analysis", "run", "published_claim"}
POLICY_SCHEMA, RULES_SCHEMA = "athena_data_quality_policy", "athena_record_identity_rules"
FAULT_SECTIONS = ("record_faults", "group_faults", "group_resolutions", "flags", "run_blocks")
THRESHOLD_TOKENS = {"threshold", "thresholds", "percent", "percentage", "pct", "share", "ratio", "cutoff"}


def is_threshold_key(k):
    """A key that names a numeric cutoff. Whole words only, so a code such as BLANK-DURATION is not mistaken for one."""
    import re
    t = set(re.split(r"[_\-. ]+", k.lower()))
    return bool(t & THRESHOLD_TOKENS) or k.lower().startswith("max_excluded")


def canonical_json(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_of(obj):
    return hashlib.sha256(canonical_json(obj)).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_policy(path=None):
    return load_json(path or POLICY_PATH)


def load_identity_rules(path=None):
    return load_json(path or RULES_PATH)


def is_legacy(pol):
    """A policy that is not the disposition-aware contract is the strict-legacy (Build 01.00) policy."""
    return pol.get("schema") != POLICY_SCHEMA


def _walk_keys(x, path=""):
    if isinstance(x, dict):
        for k, v in x.items():
            yield f"{path}.{k}", k, v
            yield from _walk_keys(v, f"{path}.{k}")
    elif isinstance(x, list):
        for i, v in enumerate(x):
            yield from _walk_keys(v, f"{path}[{i}]")


def validate_policy(pol):
    errs = []
    if pol.get("schema") != POLICY_SCHEMA: errs.append("schema")
    if set(pol.get("dispositions", [])) != DISPOSITIONS: errs.append("dispositions must be exactly the six approved terms")
    if set(pol.get("levels", [])) != LEVELS: errs.append("levels must be exactly the six approved levels")
    for sec in FAULT_SECTIONS:
        for code, f in pol.get(sec, {}).items():
            if f.get("disposition") not in DISPOSITIONS: errs.append(f"{sec}.{code}.disposition")
            if f.get("level") not in LEVELS: errs.append(f"{sec}.{code}.level")
            for t in ("problem", "why", "remedy"):
                if not isinstance(f.get(t), str) or not f[t].strip(): errs.append(f"{sec}.{code}.{t}")
    for code, f in pol.get("analysis_conditions", {}).items():
        if f.get("disposition") not in DISPOSITIONS or f.get("level") != "analysis" or not f.get("reason"): errs.append(f"analysis_conditions.{code}")
    sv = pol.get("schema_variants", {})
    for layout in ("contact", "agent_day"):
        v = sv.get(layout)
        if not v or v.get("agent_attribution") not in ("optional", "required") or not all(v.get(k) for k in ("variant_contract", "schema_dir", "schema", "strict_schema")):
            errs.append(f"schema_variants.{layout}")
    if (pol.get("publication") or {}).get("universal_percentage_threshold") is not None: errs.append("publication.universal_percentage_threshold must be null")
    for path, k, v in _walk_keys(pol):
        if is_threshold_key(k) and k != "universal_percentage_threshold": errs.append(f"numeric threshold key not allowed: {path}")
    return errs


def validate_identity_rules(r):
    errs = []
    if r.get("schema") != RULES_SCHEMA: errs.append("schema")
    for k in ("rules_version", "normalization_version"):
        if not r.get(k): errs.append(k)
    if set(r.get("layouts", {})) != {"contact", "agent_day"}: errs.append("layouts must be contact and agent_day only; no universal rule")
    for name, lay in r.get("layouts", {}).items():
        if not lay.get("identity_fields"): errs.append(f"{name}.identity_fields")
        if lay.get("conflicting", {}).get("action") != "hold_all": errs.append(f"{name}.conflicting must hold all members")
        ident = lay.get("identical", {})
        if name == "contact" and (ident.get("action") != "collapse" or not ident.get("contract")): errs.append("contact identical collapse needs an identity contract")
        if name == "agent_day":
            if ident.get("action") != "hold_unless_declared": errs.append("agent_day identical rows must hold unless declared")
            if ident.get("required_declaration") != {"grain_unique": True, "identical_rows_are_repeated_copies": True}: errs.append("agent_day required_declaration")
    return errs


def schema_selection(pol, layout, strict=False):
    """The schema for a layout, chosen from the policy contract. Takes no record: content cannot select it."""
    sv = (pol.get("schema_variants") or {}).get(layout)
    if not sv: raise ValueError("policy has no schema_variants contract for " + layout)
    name = sv["strict_schema"] if strict else sv["schema"]
    d = ROOT / ("vendor/handoff/contracts" if strict else sv["schema_dir"])
    return {"variant_contract": "strict" if strict else sv["variant_contract"], "schema_dir": d, "schema": name,
            "agent_attribution": "required" if strict else sv["agent_attribution"]}


def duplicate_semantics_from_manifest(manifest, layout, rules=None):
    """Adapter: the optional per-file D02 declaration. Returns (declaration, reason). None means hold."""
    rules = rules or load_identity_rules()
    lay = rules["layouts"][layout]
    if layout != "agent_day": return None, "NOT-APPLICABLE"
    entries = [f for f in (manifest or {}).get("files", []) if f.get("module_id") == lay["module"]]
    if len(entries) != 1: return None, "NO-UNIQUE-FILE-ENTRY"
    d = entries[0].get("duplicate_semantics")
    if d is None: return None, "NOT-DECLARED"
    need = lay["identical"]["required_declaration"]
    if not isinstance(d, dict) or set(d) != set(need) or any(not isinstance(v, bool) for v in d.values()): return None, "MALFORMED"
    if d != need: return None, "NOT-CONFIRMED"
    return dict(d), None
