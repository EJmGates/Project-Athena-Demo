"""Shared priority cutoff for ranked nonnegative contributions."""


def within_priority_cutoff(before, share, total):
    """Include a positive row when its midpoint is at or below 80%."""
    return share > 0 and 5 * (2 * before + share) <= 8 * total
