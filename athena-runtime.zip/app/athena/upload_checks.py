"""Safe-file checks run before any parsing of an upload. Limits come from config/limits.json."""
import csv, io, json
from pathlib import Path

REQUIRED = {
    "contact": ["contact_id", "account_id", "line_of_business_id", "occurred_at", "agent_id", "contact_type", "handling_seconds"],
    "agent_day": ["account_id", "line_of_business_id", "agent_id", "work_date", "contact_type", "handled_contacts", "total_handling_seconds"],
}


def load_limits(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def check_file(name, data, limits):
    """Shared CSV file safety gate; record schemas remain with their existing owners."""
    issues = []
    def add(code, msg): issues.append({"field": "file", "reason_code": code, "message": msg})
    if Path(name).suffix.lower() not in limits["allowed_extensions"]:
        add("FILE-TYPE", "Only CSV files are supported."); return issues
    if len(data) > limits["max_upload_bytes"]:
        add("FILE-TOO-LARGE", "The file is larger than the supported size."); return issues
    if b"\x00" in data:
        add("FILE-NOT-TEXT", "The file is not a text CSV."); return issues
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        add("FILE-ENCODING", "The file must be UTF-8 text."); return issues
    if any(len(line) > limits["max_line_bytes"] for line in data.split(b"\n")):
        add("LINE-TOO-LONG", "A line is longer than the supported length."); return issues
    return issues


def check_upload(name, data, grain, limits):
    """Return a list of field_issues-style dicts; preserve the primary safety/schema order."""
    issues = check_file(name, data, limits)
    if issues: return issues
    text = data.decode("utf-8-sig")
    def add(code, msg): issues.append({"field": "file", "reason_code": code, "message": msg})
    rows = csv.reader(io.StringIO(text, newline=""))
    header = next(rows, None) or []
    for col in REQUIRED[grain]:
        if col not in header:
            issues.append({"field": col, "reason_code": "MISSING-COLUMN", "message": "A required column is missing."})
    if issues: return issues
    n = sum(1 for _ in rows)
    if n > limits["max_rows"]:
        add("TOO-MANY-ROWS", "The file has more rows than the supported maximum.")
    return issues
