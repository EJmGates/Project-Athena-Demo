"""How the survey (D03) and audit (D04) files match the main contact file.

Rows need not all match: a survey or audit may name an interaction that is not in the main file, and many contacts have none. What matters
is that the dates overlap the analysis period. The counts are disclosed, never used to drop rows. An agent-day main file has no interaction
IDs, so the match cannot be checked against it.
"""
FILES = {"D03": ("Customer outcomes", "surveyed_at"), "D04": ("Quality evaluations", "evaluated_at")}


def disclose(module_id, records, contact_ids, period):
    """records: the optional upload's records ({status, record}); contact_ids: set of the main file's contact IDs, or None for an agent-day file."""
    label, date_field = FILES[module_id]
    valid = [x["record"] for x in records if x.get("status") == "valid"]
    days = sorted(str(r.get(date_field, ""))[:10] for r in valid if r.get(date_field))
    out = {"module": module_id, "label": label, "rows": len(valid), "date_min": days[0] if days else None, "date_max": days[-1] if days else None,
           "checkable": contact_ids is not None, "matched": None, "not_in_main": None, "matched_in_period": None, "overlaps_period": None}
    if days:
        out["overlaps_period"] = days[0] <= period[1] and days[-1] >= period[0]
    if contact_ids is not None:
        hit = [r for r in valid if r.get("interaction_id") in contact_ids]
        out["matched"], out["not_in_main"] = len(hit), len(valid) - len(hit)
        out["matched_in_period"] = sum(1 for r in hit if period[0] <= str(r.get(date_field, ""))[:10] <= period[1])
    return out
