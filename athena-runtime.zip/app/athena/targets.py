"""Target and specification assessment by effective period.

Official assessment uses the target versions in an approved configuration. Each version applies only to the dates inside its
own effective period, and only to the scope it names: a version with no explicit scope applies to the whole account, never
to a line_of_business or contact type by assumption. A selection that spans more than one version is assessed per period and the
overall figure is never compared with a single target. Target attainment and specification conformance are separate
statements, and both specification limits are evaluated whenever they exist, whatever the metric's direction. No control
limit is produced here, and nothing relabels a target or a specification limit.

Current contact aggregates use the configured account business date. The UTC boundary safeguard still applies to callers
that supply UTC-derived aggregates.
"""
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from athena import metric_view, metrics
from athena import session_config as S

WITHHELD_TEXT = {
    "DATE-DERIVATION-AMBIGUOUS": "Target results are not shown for this selection. {n} contacts fall on a different date in the account's time zone ({tz}) than in UTC, and the date decides which target applies. They will be shown once account-local business dates are applied.",
    "DATE-DERIVATION-UNVERIFIED": "Target results are not shown for this selection, because the dates of the contacts cannot be checked against the account's time zone. They will be shown once account-local business dates are applied.",
    "UNIT-INCOMPATIBLE": "Target results are not shown, because a target is in a unit Athena does not compare directly. Athena does not convert units.",
    "NO-CONTACTS": "There are no contacts in this selection to compare with a target.",
}
QUARTER = 15


def assess_value(value, v):
    """One figure against one version: target attainment and specification conformance, stated separately."""
    tgt, rule = v.get("target"), S.rule_for(v)
    met = gap = None
    if value is not None and tgt is not None and rule in ("at_or_below", "at_or_above"):
        met = value <= tgt if rule == "at_or_below" else value >= tgt
        gap = value - tgt
    usl, lsl = v.get("upper_specification_limit"), v.get("lower_specification_limit")   # both are evaluated, independently of direction
    above = (value > usl) if (value is not None and usl is not None) else None
    below = (value < lsl) if (value is not None and lsl is not None) else None
    conforms = None if (value is None or (usl is None and lsl is None)) else not (above or below)
    return {"target": tgt, "target_rule": rule, "target_met": met, "gap": gap,
            "specification": {"upper": usl, "lower": lsl, "conforms": conforms, "above_upper": above, "below_lower": below}}


def _key(v): return None if v is None else (v["definition_version"], v["effective_start"])


def _agg(rows):
    c = sum(r["count"] for r in rows); t = sum(r["total"] for r in rows)
    return {"count": c, "total": t, "value": (t / c) if c else None}


def requirements_window(rows, versions, lines_of_business, baseline, ambiguity, layout, tz, dates_basis, selection=None,
                        *, metric_id="aht", scoring=None, supplied_fraction=False):
    """Use the report's KPI population and the existing effective-date assessment."""
    start, end = baseline
    versions = versions or []
    periods = []
    for version in versions:
        if not any(version.get(key) is not None for key in ("target", "lower_specification_limit", "upper_specification_limit")):
            continue
        first = max(start, version["effective_start"])
        exclusive = version.get("effective_end")
        if exclusive and exclusive <= first:
            continue
        last = min(end, (date.fromisoformat(exclusive) - timedelta(days=1)).isoformat()) if exclusive else end
        if first <= last:
            periods.append({"start": first, "end": last, "target": version.get("target")})
    periods.sort(key=lambda period: period["start"], reverse=True)
    if selection is None:
        current = next((period for period in periods if period["target"] is not None), periods[0] if periods else None)
        first, last = (current["start"], current["end"]) if current else baseline
        mode = current["start"] if current else "manual"
    else:
        if not isinstance(selection, dict):
            raise ValueError("Choose an effective period or enter dates within the analysis range.")
        first, last, mode = selection.get("start"), selection.get("end"), selection.get("mode")
        try:
            valid_dates = all(isinstance(day, str) and date.fromisoformat(day).isoformat() == day for day in (first, last))
        except ValueError:
            valid_dates = False
        if not valid_dates or not start <= first <= last <= end:
            raise ValueError("Choose ordered dates within the Cockpit analysis range.")
        if mode != "manual" and not any((mode, first, last) == (p["start"], p["start"], p["end"]) for p in periods):
            raise ValueError("Choose an effective period from this analysis.")
    selected = [row for row in rows if row["line_of_business_id"] in lines_of_business and first <= row["date"] <= last]
    assessment = (assess(selected, versions, lines_of_business, (first, last), ambiguity, layout, tz, dates_basis=dates_basis)
                  if periods or not selected else
                  {"periods": [], "reason": "No account target or specification limit applies in the Cockpit analysis range."})
    return {"selection": {"start": first, "end": last, "mode": mode}, "periods": periods,
            "weighted": _agg(selected), "assessment": assessment,
            "checks": _requirements_checks(selected, first, last, assessment, versions, metric_id, scoring, layout, supplied_fraction)}


def _requirements_checks(rows, first, last, assessment, versions, metric_id, scoring, layout, supplied_fraction):
    """Compute auxiliary checks from the same applied population without changing the official KPI."""
    source = [row for row in rows if row["count"] > 0]
    agents = defaultdict(list)
    unattributed = 0
    for row in source:
        if row.get("agent_id") and row.get("attributed", True):
            agents[row["agent_id"]].append(row)
        else:
            unattributed += row["count"]
    eligible, days = [], set()
    for agent_rows in agents.values():
        agent = _agg(agent_rows)
        if agent["count"] >= 5:
            eligible.append(agent["value"])
            days.update(row["date"] for row in agent_rows)
    history_days = (date.fromisoformat(max(days)) - date.fromisoformat(min(days))).days + 1 if days else 0
    coverage = {"eligible_agents": len(eligible), "below_agent_floor": len(agents) - len(eligible),
                "unattributed_weight": unattributed, "history_days": history_days}

    # D02 score/rate rows use contact weights; these do not establish the number of scores.
    unit = metric_view.engine_unit(metric_id, scoring)
    if unit == "points" or (layout == "agent_day" and unit == "percent"):
        reason = "DESCRIPTIVE-SCORE" if unit == "points" else "SCORE-COUNTS-UNAVAILABLE"
        return {"variation": {"value": None, "rating": None, "reason": reason},
                "capability": {"yield": None, **metrics.sigma(None), "reason": reason},
                "coverage": {**coverage, "eligible_agents": None, "below_agent_floor": None}}

    # Use agent readings whenever agents are identified. Daily readings are the supported fallback for VSF only.
    values, basis = eligible, "agent"
    if source and not agents:
        daily = defaultdict(list)
        for row in source:
            daily[row["date"]].append(row)
        values, basis = [_agg(group)["value"] for group in daily.values()], "day"
    # A pass-outcome rate has a meaningful zero. A supplied score in percent format does not establish that basis.
    variation = metrics.vsf(values) if unit == "percent" and not supplied_fraction else metrics.vsf_for_metric(metric_id, values)
    variation["basis"] = basis

    version = S.version_at(versions, first) if (assessment.get("overall") or {}).get("classified") else None
    reason = None
    if assessment.get("reason_code") in {"NO-CONTACTS", "UNIT-INCOMPATIBLE", "DATE-DERIVATION-UNVERIFIED", "DATE-DERIVATION-AMBIGUOUS"}:
        reason = assessment["reason_code"]
    elif not version or (version.get("effective_end") and last >= version["effective_end"]):
        reason = "SINGLE-REQUIREMENT-NEEDED"
    elif len(eligible) < 12:
        reason = "TOO-FEW-AGENTS"
    elif history_days < 7 * 12:
        reason = "SHORT-HISTORY"
    share = None
    comparison = None
    if reason is None:
        direction, target = version["direction"], version.get("target")
        lower, upper = version.get("lower_specification_limit"), version.get("upper_specification_limit")
        if (direction == "monitor_only" or (direction in {"lower_is_better", "higher_is_better"} and target is None)
                or metrics.check_setup(direction, target, lower, upper)):
            reason = "NO-CAPABILITY-COMPARISON"
        else:
            share = metrics.yield_share(eligible, direction, target, lower, upper)
            comparison = "specification" if direction == "within_bounds" else "target"
    capability = {"yield": share, "comparison": comparison, **metrics.sigma(share)}
    if reason:
        capability["reason"] = reason
    return {"variation": variation, "capability": capability, "coverage": coverage}


def ambiguity_from_buckets(buckets, tz_name):
    """Contacts whose date in UTC differs from their date in the configured business time zone.

    buckets: [{line_of_business_id, utc_date, quarter, contacts}] with the UTC instant held to 15 minutes, which is exact for every
    current IANA zone. The time zone comes from the configuration, never from the offset written in the file."""
    tz = ZoneInfo(tz_name); out = defaultdict(int)
    for b in buckets:
        start = datetime.fromisoformat(b["utc_date"]).replace(tzinfo=timezone.utc) + timedelta(minutes=QUARTER * b["quarter"])
        local = start.astimezone(tz).date().isoformat()
        if local != b["utc_date"]: out[(b["line_of_business_id"], b["utc_date"], local)] += b["contacts"]
    return [{"line_of_business_id": q, "utc_date": u, "local_date": l, "contacts": c} for (q, u, l), c in sorted(out.items())]


def _reference_issue(versions, lines_of_business, period, ambiguity, layout, tz, dates_basis):
    if any(v["canonical_unit"] != metric_view.engine_unit(v["metric_id"], v.get("scoring")) for v in versions):
        return {"status": "unavailable", "reason_code": "UNIT-INCOMPATIBLE", "reason": WITHHELD_TEXT["UNIT-INCOMPATIBLE"]}
    if dates_basis == "account_business_dates" or layout != "contact":
        return {}
    if ambiguity is None:
        return {"status": "withheld", "reason_code": "DATE-DERIVATION-UNVERIFIED", "reason": WITHHELD_TEXT["DATE-DERIVATION-UNVERIFIED"]}
    start, end = period
    lines = set(lines_of_business)
    contacts = sum(a["contacts"] for a in ambiguity if a["line_of_business_id"] in lines and start <= a["utc_date"] <= end
                   and _key(S.version_at(versions, a["utc_date"])) != _key(S.version_at(versions, a["local_date"])))
    if contacts:
        return {"status": "withheld", "reason_code": "DATE-DERIVATION-AMBIGUOUS",
                "reason": WITHHELD_TEXT["DATE-DERIVATION-AMBIGUOUS"].format(n=f"{contacts:,}", tz=tz or "not set"),
                "affected_contacts": contacts}
    return {}


def dated_references(config, versions, groups, lines, period, ambiguity, layout, tz, dates_basis):
    """Bind effective requirements independently of observed daily readings."""
    def project(candidates, selected_lines):
        if not candidates:
            return {"intervals": []}
        issue = _reference_issue(candidates, selected_lines, period, ambiguity, layout, tz, dates_basis)
        if issue:
            return {"intervals": [], **issue}
        start, end = period
        bounds = ("lower_specification_limit", "upper_specification_limit")
        intervals = []
        for version in candidates:
            first = version["effective_start"]
            exclusive = version.get("effective_end")
            if first > end or (exclusive is not None and exclusive <= start):
                continue
            values = {field: version[field] for field in bounds if version.get(field) is not None}
            rule = S.rule_for(version)
            if version.get("target") is not None and rule in ("at_or_below", "at_or_above"):
                values.update(target=version["target"], target_rule=rule)
            if values:
                intervals.append({"effective_start": first, "effective_end": exclusive, **values})
        return {"intervals": intervals}

    return {
        "account": project(versions, lines),
        **{dimension: {group["key"]: project(S.scoped_versions(config, dimension, group["key"]),
                                             [group["key"]] if dimension == "line_of_business" else lines)
                       for group in groups[dimension]}
           for dimension in ("line_of_business", "contact_type")}
    }


def assess(rows, versions, lines_of_business, period, ambiguity, layout, tz=None, *, dates_basis=None):
    """rows: aggregate rows already in scope. ambiguity: see ambiguity_from_buckets; None means it could not be checked."""
    out = {"status": "published", "reason_code": None, "reason": None, "periods": [], "multiple_targets": False, "overall": None,
           "dates_basis": dates_basis or ("declared_business_dates" if layout == "agent_day" else "utc_derived"), "limitations": [], "affected_contacts": 0}
    overall = _agg(rows)
    if not overall["count"]:
        out.update(status="unavailable", reason_code="NO-CONTACTS", reason=WITHHELD_TEXT["NO-CONTACTS"]); return out
    issue = _reference_issue(versions, lines_of_business, period, ambiguity, layout, tz, out["dates_basis"])
    if issue:
        out.update(issue)
        return out
    if out["dates_basis"] == "account_business_dates":
        out["limitations"].append(f"Contact dates use the configured account time zone, {tz}.")
    elif layout == "contact":
        out["limitations"].append("Dates are worked out in UTC until account-local business dates are applied."
                                  + (f" They were checked against the configured time zone, {tz}, and no contact falls on a different date there." if tz else ""))
    else:
        out["limitations"].append("Dates are the business dates declared in your file. Their time zone has not been verified against contact-level data.")
    groups, uncovered_by_date = {}, defaultdict(list)
    for r in rows:
        version = S.version_at(versions, r["date"])
        if version is None:
            uncovered_by_date[r["date"]].append(r)
        else:
            groups.setdefault(_key(version), {"version": version, "rows": []})["rows"].append(r)
    spans = [groups[key] for key in sorted(groups)]
    prior_day = None
    for day, daily_rows in sorted(uncovered_by_date.items()):
        current_day = date.fromisoformat(day)
        if prior_day is None or (current_day - prior_day).days != 1:
            spans.append({"version": None, "rows": []})
        spans[-1]["rows"].extend(daily_rows)
        prior_day = current_day
    for g in spans:
        a = _agg(g["rows"]); ds = sorted(r["date"] for r in g["rows"]); v = g["version"]
        p = {"definition_version": v["definition_version"] if v else None, "effective_start": v["effective_start"] if v else None, "effective_end": v.get("effective_end") if v else None,
             "first_date": ds[0], "last_date": ds[-1], "count": a["count"], "total": a["total"], "value": a["value"], "has_target": v is not None}
        p.update(assess_value(a["value"], v) if v else {"target": None, "target_rule": None, "target_met": None, "gap": None, "specification": {"upper": None, "lower": None, "conforms": None, "above_upper": None, "below_lower": None}})
        out["periods"].append(p)
    covered = [p for p in out["periods"] if p["has_target"]]
    out["multiple_targets"] = len(covered) > 1
    single = len(covered) == 1 and len(out["periods"]) == 1
    out["overall"] = {**overall, "classified": single, "compared_with_a_single_target": single,
                      "note": None if single else ("Contains multiple applicable targets. The overall figure is not compared with a single target." if out["multiple_targets"] else "Some dates have no target, so the overall figure is not compared with one.")}
    if single: out["overall"].update({k: out["periods"][0][k] for k in ("target", "target_met", "gap", "specification")})
    if not covered: out.update(status="unavailable", reason_code="NO-TARGET-IN-FORCE", reason="No target is in force on any date in this selection.")
    return out


def assess_groups(rows, group_by, config, lines_of_business, period, ambiguity, layout, tz, *, dates_basis=None):
    """A target applies to a line_of_business or contact type only when the configuration names it. Others are reported as having none."""
    key_field = "line_of_business_id" if group_by == "line_of_business" else "contact_type"
    by = defaultdict(list)
    for r in rows: by[r[key_field]].append(r)
    out = []
    for key in sorted(by):
        vs = S.scoped_versions(config, group_by, key, S.primary_metric(config))
        if not vs:
            out.append({"key": key, "status": "no_target_applies", "reason": "No target applies to this group unless the configuration names it.", "periods": [], "overall": None, "multiple_targets": False}); continue
        a = assess(by[key], vs, [key] if group_by == "line_of_business" else lines_of_business, period, ambiguity, layout, tz, dates_basis=dates_basis)
        a["key"] = key; out.append(a)
    return out


def reconcile_business_dates(buckets, aggregates_d02, tz_name):
    """Check declared agent-day business dates against contact-level instants, per line_of_business and day, when both are available.

    buckets: contact-level UTC buckets. aggregates_d02: agent-day aggregate rows. Returns the days that agree and those that do not."""
    tz = ZoneInfo(tz_name); d01 = defaultdict(int); d02 = defaultdict(int)
    for b in buckets:
        start = datetime.fromisoformat(b["utc_date"]).replace(tzinfo=timezone.utc) + timedelta(minutes=QUARTER * b["quarter"])
        d01[(b["line_of_business_id"], start.astimezone(tz).date().isoformat())] += b["contacts"]
    for r in aggregates_d02: d02[(r["line_of_business_id"], r["date"])] += r["count"]
    keys = sorted(set(d01) | set(d02)); bad = [{"line_of_business_id": q, "date": d, "contact_level": d01.get((q, d), 0), "declared": d02.get((q, d), 0)} for q, d in keys if d01.get((q, d), 0) != d02.get((q, d), 0)]
    return {"days": len(keys), "matched": len(keys) - len(bad), "mismatched": bad, "time_zone": tz_name}
