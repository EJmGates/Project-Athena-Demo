"""Constraint dataset (internal code D09; dataset 9 on screen) and the constraint-impact calculation (docs/55 section 2).

File columns: Constraint category level 1, Constraint category level 2, Controllable Y/N, Count. The file's Y/N is used exactly as given.
Sorting into the standard categories (config/constraint_categories.json) is automatic:
  1. normalise labels (case, spaces, underscores) and sum counts, keeping the original labels;
  2. Python keyword and synonym matching;
  3. an optional local model for leftovers, passed in as a function (none is bundled, so without it only step 2 runs);
  4. anything still unmatched stays as its own "Unclassified" line, which no card can claim.
A hidden confirm step is inactive and defaults to auto-approved; the result records which.

Impact per Level 2 = distribution % x % controllable x gap, where distribution % is the line's count over the sum of controllable counts
and % controllable is its controllable count over its own count (so the product is its controllable share of all controllable counts, times
the gap). Adoption applies only where a card is assigned. A Level 2's lift is split among its linked cards by weight (rating + 1).
Nothing here reaches a page or admits a method; a glidepath is always a conditional scenario, an allocation rule and not a measured effect.
"""
import json
import math
import re
from fractions import Fraction
from pathlib import Path

from athena.pareto import within_priority_cutoff

CATEGORIES = json.loads((Path(__file__).resolve().parent.parent / "config/constraint_categories.json").read_text(encoding="utf-8"))
STANDARD = [(x["level1"], l2) for x in CATEGORIES["levels"] for l2 in x["level2"]]
LEVEL1 = [x["level1"] for x in CATEGORIES["levels"]]
UNCLASSIFIED = "Unclassified"
DEFAULT_ADOPTION = 0.8
YES, NO = {"y", "yes", "true", "1"}, {"n", "no", "false", "0"}


def normalise(label):
    """Case, spaces and underscores only: 'Policy_interpretation ' and 'policy  interpretation' are the same label."""
    return re.sub(r"[\s_]+", " ", str(label if label is not None else "")).strip().casefold()


# Keywords and synonyms per standard Level 2. The standard name itself always matches. Longest keyword wins; ties go to table order.
SYNONYMS = {
    ("Human performance", "Communication and listening"): ["communication", "listening", "active listening", "interrupt", "clarity"],
    ("Human performance", "Language skills"): ["language", "accent", "grammar", "fluency", "vocabulary"],
    ("Human performance", "Attitude, empathy and professionalism"): ["attitude", "empathy", "professional", "courtesy", "tone", "rude"],
    ("Human performance", "Product and process knowledge"): ["product knowledge", "process knowledge", "lack of knowledge", "knowledge of"],
    ("Human performance", "Understanding the request and investigation"): ["understanding", "probing", "investigation", "misunderstood", "did not understand"],
    ("Human performance", "Resolution accuracy and completeness"): ["accuracy", "incorrect", "wrong information", "incomplete", "inaccurate", "completeness", "resolution accuracy"],
    ("Human performance", "Following procedure"): ["procedure", "did not follow", "sop", "protocol"],
    ("Human performance", "Logging and closure"): ["logging", "closure", "documentation", "notes", "case notes", "disposition"],
    ("Human performance", "Pace and efficiency"): ["pace", "efficiency", "long handle", "dead air", "slow"],
    ("Human performance", "Compliance"): ["compliance", "disclosure", "verification", "authentication"],
    ("Process and knowledge", "Process complexity or steps"): ["complex", "too many steps", "number of steps", "process steps", "complicated"],
    ("Process and knowledge", "Policy interpretation"): ["policy interpretation", "interpretation", "unclear policy", "policy clarity"],
    ("Process and knowledge", "Knowledge material gaps"): ["knowledge article", "knowledge base", "knowledge gap", "outdated article", "documentation gap", "job aid", "missing article"],
    ("Process and knowledge", "Training gaps"): ["training", "refresher", "coaching gap", "onboarding gap"],
    ("Process and knowledge", "Handoffs, transfers and escalation"): ["transfer", "handoff", "hand off", "escalat", "warm transfer"],
    ("Process and knowledge", "Follow-up and callbacks"): ["follow up", "follow-up", "callback", "call back", "repeat contact"],
    ("Process and knowledge", "Time to answer or resolve"): ["time to answer", "time to resolve", "resolution time", "turnaround", "wait to resolve"],
    ("Process and knowledge", "Data privacy process"): ["privacy", "gdpr", "consent", "data protection"],
    ("Technology and infrastructure", "Systems and tools"): ["system", "tools", "crm", "application", "software", "slow system", "outage"],
    ("Technology and infrastructure", "Telephony and channel quality"): ["telephony", "audio", "line quality", "connection", "dropped call", "latency", "voice quality", "channel quality"],
    ("Technology and infrastructure", "Self-service, web and app"): ["self service", "self-service", "website", "web site", "app", "portal", "chatbot", "ivr"],
# Keywords are matched against label text written by clients, who often say "queue"; both words are kept here on purpose.
    ("Technology and infrastructure", "Automation and integration gaps"): ["automation", "integration", "api", "no integration"],
    ("Workforce management", "Staffing and capacity"): ["staffing", "capacity", "headcount", "understaffed", "short staffed"],
    ("Workforce management", "Service reachability"): ["reachability", "abandon", "hold time", "wait time", "queue wait", "line of business wait", "long wait", "unreachable", "service level"],
    ("Workforce management", "Scheduling and adherence"): ["schedul", "adherence", "shift", "roster", "forecast"],
    ("Workforce management", "Absence and attrition"): ["absence", "absentee", "attrition", "turnover", "leave"],
    ("Workforce management", "New-hire ramp and tenure"): ["new hire", "ramp", "tenure", "nesting", "inexperienced"],
    ("Workforce management", "Routing, skills and Line of Business setup"): ["routing", "skill", "queue setup", "line of business setup", "misrouted", "wrong queue", "wrong line of business"],
    ("Client constraints", "Client policy and coverage"): ["client policy", "coverage", "warranty", "not covered", "terms and conditions"],
    ("Client constraints", "Pricing and cost"): ["pricing", "price", "cost", "fee", "charge", "billing amount"],
    ("Client constraints", "Product or service quality"): ["product quality", "service quality", "defect", "faulty", "damaged", "recall"],
    ("Client constraints", "Availability and supply"): ["availability", "supply", "out of stock", "stock", "backorder", "delivery delay", "lead time"],
    ("Client constraints", "Known issue awaiting a fix"): ["known issue", "awaiting fix", "pending fix", "bug", "fix pending"],
    ("Client constraints", "Partner or dealer network"): ["dealer", "partner", "network", "franchise", "retailer"],
    ("Client constraints", "Client SLAs"): ["sla", "service level agreement", "contractual"],
    ("Client constraints", "Unsupported or out-of-scope requests"): ["out of scope", "unsupported", "not supported", "outside scope"],
    ("Customer constraints", "Customer behaviour"): ["customer behaviour", "customer behavior", "customer error", "customer did not", "customer unreachable", "abusive", "unresponsive customer"],
    ("Customer constraints", "Survey misunderstanding"): ["survey misunderstanding", "misread survey", "survey error", "scale misunderstanding"],
    ("Customer constraints", "No usable reason given"): ["no reason", "no usable reason", "no comment", "not provided", "reason not given"],
}
def _has(keyword, text):
    """A keyword matches at the start of a word; a short one (four letters or fewer) must be the whole word, optionally plural, so that
    'sla' does not fire inside 'translation'. Both arguments are already normalised."""
    k = keyword.strip()
    if not k:
        return False
    tail = r"s?(?!\w)" if len(k) <= 4 else ""
    return re.search(r"(?<!\w)" + re.escape(k) + tail, text) is not None


_UNSPECIFIED = {"unspecified", "unknown", "other", "others", "n/a", "na", "not specified", "none", "misc", "miscellaneous", "general"}


def _level1(label):
    """A client Level 1 label resolved to a standard Level 1, or None."""
    n = normalise(label)
    for std in LEVEL1:
        if n == normalise(std):
            return std
    best = None
    for (l1, _), words in SYNONYMS.items():
        for w in words:
            if _has(normalise(w), n) and (best is None or len(w) > best[0]):
                best = (len(w), l1)
    return best[1] if best else None


def match_label(level1, level2):
    """Keyword and synonym matching to a standard (Level 1, Level 2). Returns (pair, method) or (None, None).
    Labels with embedded sub-levels ("People - Pace - Slow") are split on ' - ' and every part is tried, last part first."""
    parts = [p for p in re.split(r"\s+-\s+", str(level2 if level2 is not None else "")) if p.strip()][::-1] or [""]
    resolved = _level1(level1)
    pool = [pair for pair in STANDARD if resolved is None or pair[0] == resolved]
    for part in parts:
        n = normalise(part)
        for pair in pool:
            if n == normalise(pair[1]) and pair[1] != "Unspecified":
                return pair, "exact"
    for part in parts:
        n = normalise(part)
        best = None                                           # (keyword length, table order, pair)
        for order, pair in enumerate(STANDARD):
            if pair not in pool:
                continue
            for w in SYNONYMS.get(pair, []):
                k = normalise(w)
                if _has(k, n) and (best is None or (len(k), -order) > (best[0], -best[1])):
                    best = (len(k), order, pair)
        if best:
            return best[2], "keyword"
    if resolved and any(normalise(p) in _UNSPECIFIED or not normalise(p) for p in parts):
        return (resolved, "Unspecified"), "unspecified"
    return None, None


def _count(value, where):
    try:
        v = float(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        raise ValueError(f"{where}: count is not a number")
    if not math.isfinite(v) or v < 0:
        raise ValueError(f"{where}: count must be zero or more")
    return v


def aggregate(rows, *, exact=False):
    """rows: dicts with level1, level2, controllable, count. Returns (lines, problems). A line is a distinct normalised
    (level 1, level 2, controllable) with the counts summed and the first-seen labels kept. Rows that cannot be read are listed, not guessed."""
    lines, problems, order = {}, [], []
    for i, r in enumerate(rows, 1):
        where = f"row {i}"
        flag = str(r.get("controllable", "")).strip().casefold()
        try:
            n = Fraction(str(_count(r.get("count"), where)))
        except ValueError as e:
            problems.append(str(e))
            continue
        if flag not in YES | NO:
            problems.append(f"{where}: controllable must be Y or N")
            continue
        key = (normalise(r.get("level1")), normalise(r.get("level2")), flag in YES)
        if key not in lines:
            lines[key] = {"level1": str(r.get("level1", "")).strip(), "level2": str(r.get("level2", "")).strip(), "controllable": flag in YES, "count": Fraction(0)}
            order.append(key)
        lines[key]["count"] += n
    ordered = [lines[k] for k in order]
    if not exact:
        ordered = [{**line, "count": float(line["count"])} for line in ordered]
    return ordered, problems


def sort_lines(lines, model=None, threshold=0.7):
    """Assign each aggregated line a standard category. `model(label_level1, label_level2, candidates)` may return (pair, confidence) for
    leftovers; it is used only at or above the threshold. Returns lines with level1_std, level2_std, method (exact, keyword, unspecified, model, none)."""
    out = []
    for ln in lines:
        pair, method = match_label(ln["level1"], ln["level2"])
        if pair is None and model is not None:
            got = model(ln["level1"], ln["level2"], list(STANDARD))
            if got and got[0] in STANDARD and isinstance(got[1], (int, float)) and got[1] >= threshold:
                pair, method = got[0], "model"
        out.append({**ln, "level1_std": pair[0] if pair else UNCLASSIFIED, "level2_std": pair[1] if pair else UNCLASSIFIED,
                    "method": method or "none"})
    return out


def prepare(rows, model=None, threshold=0.7, confirmed=False, *, exact=False):
    """Whole intake: aggregate, sort, and record the hidden confirm flag (auto-approved unless confirmed)."""
    lines, problems = aggregate(rows, exact=exact)
    if not lines:
        return {"ok": False, "problems": problems or ["The file has no usable rows."]}
    sorted_lines = sort_lines(lines, model, threshold)
    return {"ok": True, "lines": sorted_lines, "problems": problems,
            "confirmation": "confirmed" if confirmed else "auto_approved",
            "methods": sorted({x["method"] for x in sorted_lines})}


def pools(lines):
    """Per standard Level 2 (and Unclassified): totals, controllable counts and the impact fractions, then the Pareto.
    Distribution % = count / sum of controllable counts; % controllable = controllable / count; their product is the line's controllable share."""
    acc = {}
    for ln in lines:
        key = (ln["level1_std"], ln["level2_std"])
        p = acc.setdefault(key, {"level1": key[0], "level2": key[1], "count": Fraction(0), "controllable": Fraction(0)})
        count = Fraction(str(ln["count"]))
        p["count"] += count
        if ln["controllable"]:
            p["controllable"] += count
    total_ctrl = sum(p["controllable"] for p in acc.values())
    rows = []
    cumulative = 0
    for p in sorted(acc.values(), key=lambda r: (-r["controllable"], r["level1"], r["level2"])):
        count = p["controllable"]
        vital_few = within_priority_cutoff(cumulative, count, total_ctrl)
        cumulative += count
        rows.append({
            **p, "count": float(p["count"]), "controllable": float(count),
            "distribution": float(p["count"] / total_ctrl) if total_ctrl else 0.0,
            "pct_controllable": float(count / p["count"]) if p["count"] else 0.0,
            "share": float(count / total_ctrl) if total_ctrl else 0.0,
            "cumulative": float(cumulative / total_ctrl) if total_ctrl else 0.0,
            "vital_few": vital_few, "unclassified": p["level1"] == UNCLASSIFIED,
        })
    return rows, float(total_ctrl)


def pareto(rows, model=None):
    """Return ranked Level 2 shares and flags for the 80% priority cutoff."""
    prep = prepare(rows, model, exact=True)
    if not prep["ok"]:
        return None
    pool, total = pools(prep["lines"])
    lines = [{**line, "count": float(line["count"])} for line in prep["lines"]]
    return {"pools": pool, "lines": lines, "total_controllable": total, "problems": prep["problems"], "methods": prep["methods"], "confirmation": prep["confirmation"]}


def pareto_finding(par, metric, direction, label, gap_value=None, contacts=None, unit="seconds"):
    """The leading classified constraint as a playbook finding. The category and Level 2 links come from the constraint itself.
    Impact (handling hours, handle time only) is its share of the improvement room; other metrics carry none."""
    if not par:
        return None
    top = next((p for p in par["pools"] if not p["unclassified"] and p["share"] > 0), None)
    if top is None:
        return None
    hours = (top["share"] * gap_value * contacts / 3600.0) if (unit == "seconds" and gap_value and contacts) else None
    percent = top["share"] * 100
    share_text = f"{percent:.2g}%" if percent < 0.05 else f"{percent:.1f}".rstrip("0").rstrip(".") + "%"
    return {"id": "constraint-%s" % normalise(top["level2"]).replace(" ", "-"), "pattern": "constraint_pareto", "metric": metric, "direction": direction, "support": "supported",
            "impact": {"value": hours, "unit": "hours"} if hours is not None else None,
            "fields": {"constraint_top": top["level2"], "share": share_text, "controllable": "yes" if top["pct_controllable"] >= 0.5 else "partly", "metric_label": label},
            "constraint": {"level1": top["level1"], "level2": [top["level2"]]}}


def gap(baseline, ceiling, direction):
    """Improvement room in the metric's units: ceiling minus baseline when higher is better, baseline minus ceiling when lower is better.
    Already at or past the ceiling gives zero. Other directions have no lift."""
    for v in (baseline, ceiling):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            raise ValueError("baseline and ceiling must be finite numbers")
    if direction == "higher_is_better":
        return max(ceiling - baseline, 0.0)
    if direction == "lower_is_better":
        return max(baseline - ceiling, 0.0)
    return None


def lift(lines, gap_value, cards, adoption=DEFAULT_ADOPTION, baseline_confirmed=False):
    """Cards link IDs to Level 2 pools. Returns pools with impact and lift, per-card allocations,
    totals per Level 1 and the unaddressed amount. Blocked until the baseline period is confirmed (the file carries no dates)."""
    if baseline_confirmed is not True:
        return {"ok": False, "blocked": [{"code": "BASELINE-NOT-CONFIRMED", "reason": "Confirm that the constraint file covers the baseline period."}]}
    if gap_value is None:
        return {"ok": False, "blocked": [{"code": "NO-LIFT", "reason": "This metric has no better or worse to lift toward."}]}
    if isinstance(adoption, bool) or not isinstance(adoption, (int, float)) or not 0 <= adoption <= 1:
        raise ValueError("adoption must be between 0 and 1")
    rows, total_ctrl = pools(lines)
    claims = {}
    for c in cards:
        for link in c["level2"]:
            claims.setdefault((link["level1"], link["level2"]), set()).add(c["id"])
    card_lift = {c["id"]: 0.0 for c in cards}
    card_room = dict(card_lift)
    matched_pools = {c["id"]: [] for c in cards}
    unaddressed = 0.0
    for r in rows:
        r["impact"] = r["share"] * gap_value
        linked = [] if r["unclassified"] else sorted(claims.get((r["level1"], r["level2"]), ()))
        if not linked:
            r["lift"] = 0.0
            r["addressed"] = False
            unaddressed += r["impact"]
            continue
        r["addressed"] = True
        r["lift"] = r["impact"] * adoption
        unaddressed += r["impact"] * (1 - adoption)
        for cid in linked:
            available = r["impact"] / len(linked)
            card_room[cid] += available
            card_lift[cid] += available * adoption
            matched_pools[cid].append({"level1": r["level1"], "level2": r["level2"], "actions": len(linked),
                                       "pool_id": ["D09", r["level1"], r["level2"]],
                                       "denominator": total_ctrl, "allocation_fraction": 1 / len(linked),
                                       "count": r["controllable"], "share": r["share"], "lift": available * adoption})
    by_level1 = {}
    for r in rows:
        d = by_level1.setdefault(r["level1"], {"impact": 0.0, "lift": 0.0})
        d["impact"] += r["impact"]
        d["lift"] += r["lift"]
    return {"ok": True, "pools": rows, "card_lift": card_lift, "card_room": card_room, "matched_pools": matched_pools,
            "by_level1": by_level1, "unaddressed": unaddressed,
            "total_impact": sum(r["impact"] for r in rows), "total_lift": sum(r["lift"] for r in rows), "adoption": adoption,
            "label": "Conditional scenario: an allocation rule, not a measured effect."}


def glidepath(baseline, total_lift, weeks, direction):
    """Equal weekly steps from the baseline over `weeks`, ending at the baseline moved by the lift in the better direction. Always labelled a
    conditional scenario."""
    if isinstance(weeks, bool) or not isinstance(weeks, int) or weeks < 1:
        raise ValueError("weeks must be a whole number of at least 1")
    if direction not in ("higher_is_better", "lower_is_better"):
        raise ValueError("no glidepath for direction: %r" % (direction,))
    sign = 1.0 if direction == "higher_is_better" else -1.0
    step = sign * total_lift / weeks
    return {"label": "Conditional scenario: an allocation rule, not a measured effect.",
            "weeks": [{"week": w, "value": baseline + step * w} for w in range(1, weeks + 1)]}
