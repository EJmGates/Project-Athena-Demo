"""Where points or ratings are lost: the components of a score (QA factors, survey ratings), read from the optional file's own columns.

A component's full value is the highest value seen in the file for that column (the file does not say it, and the setup for weights and
formulas is not built yet); the page says so. Shortfall = full value minus the value, summed over the in-scope valid rows; a component's share is its
shortfall over the total shortfall. This describes where points are lost, not why.
"""
import csv, io, math
from datetime import date, timedelta

import numpy as np

from athena import dates, forecast, match, metrics

QA_SUFFIX = "_points"
CSAT_PREFIX = "csat_"
CSAT_SKIP = {"csat_score", "csat_satisfied_flag"}
AHT_COMPONENTS = {"talk_seconds": "Talk time", "hold_seconds": "Hold time",
                  "after_call_work_seconds": "After-call work"}
MIN_COMMON_WEEKS = 8  # Reuse the common-week comparison floor in docs/48.


def label(column):
    if column.endswith(QA_SUFFIX):
        column = column[:-len(QA_SUFFIX)]
    elif column.startswith(CSAT_PREFIX):
        column = column[len(CSAT_PREFIX):]
    text = column.replace("_", " ").strip()
    return text[:1].upper() + text[1:]


def detect(header, kind):
    """The component columns of a file: QA factor points (`*_points`) or survey ratings (`csat_*` except the score and the flag)."""
    if kind == "qa":
        return [h for h in header if h.endswith(QA_SUFFIX)]
    return [h for h in header if h.startswith(CSAT_PREFIX) and h not in CSAT_SKIP]


def shortfall(raw, valid_rows, kind):
    """Calculate shortfalls for all valid rows when no analysis scope is supplied."""
    reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig", errors="replace"), newline=""))
    columns = detect(reader.fieldnames or [], kind)
    rows = ((row, True) for number, row in enumerate(reader, start=2) if number in valid_rows)
    return _shortfall(columns, rows, kind)


def _shortfall(cols, rows, kind):
    if not cols:
        return None
    vals = {c: [] for c in cols}
    highest = {}
    for row, in_scope in rows:
        for c in cols:
            try:
                x = float(row[c])
            except (TypeError, ValueError):
                continue
            if math.isfinite(x):
                highest[c] = max(highest.get(c, x), x)
                if in_scope:
                    vals[c].append(x)
    stats = []
    for c, v in vals.items():
        if not v:
            continue
        full = highest[c]
        stats.append({"column": c, "label": label(c), "full": full, "mean": sum(v) / len(v), "n": len(v), "lost": sum(full - x for x in v)})
    total = sum(s["lost"] for s in stats)
    if not stats or total <= 0:
        return None
    for s in stats:
        s["share"] = s["lost"] / total
    stats.sort(key=lambda s: (-s["share"], s["column"]))
    return {"rows": stats, "basis": "highest value seen in the file", "kind": kind}


def _weekly_links(rows, period, columns, source):
    """Rows supply a common count and the KPI/component totals, or None for an incomplete contact aggregate."""
    weekly = {w["start"]: [0, [0.0] * (len(columns) + 1)]
              for w in forecast.weekly_series([], period)}
    incomplete = set()
    for day, count, values in rows:
        d = date.fromisoformat(day)
        week = (d - timedelta(days=d.weekday())).isoformat()
        if week not in weekly:
            continue
        if values is None:
            incomplete.add(week)
            continue
        n, totals = weekly[week]
        weekly[week] = [n + count, [a + b for a, b in zip(totals, values)]]
    weeks, means = [], []
    for week, (count, totals) in weekly.items():
        if week not in incomplete and count and all(math.isfinite(t) for t in totals):
            weeks.append({"start": week, "count": count})
            means.append([t / count for t in totals])
    if len(weeks) < MIN_COMMON_WEEKS:
        return None

    values = np.asarray(means, dtype=float).T
    scales = np.max(np.abs(values), axis=1)
    scaled = values / np.where(scales == 0, 1, scales)[:, None]
    centered = scaled - scaled.mean(axis=1, keepdims=True)
    sums_sq = np.einsum("ij,ij->i", centered, centered)
    if not np.any(values[0] != values[0, 0]) or sums_sq[0] == 0:
        return None
    outcome_center = float(scaled[0].mean())
    comparisons = []
    for i, (column, name) in enumerate(columns.items(), start=1):
        if not np.any(values[i] != values[i, 0]) or sums_sq[i] == 0:
            continue
        cross = float(centered[i] @ centered[0])
        r = max(-1.0, min(1.0, cross / (math.sqrt(sums_sq[i]) * math.sqrt(sums_sq[0]))))
        scaled_slope = cross / float(sums_sq[i])
        slope = scaled_slope * float(scales[0]) / float(scales[i])
        if math.isfinite(slope):
            low, high = int(np.argmin(values[i])), int(np.argmax(values[i]))
            fit = [[float(values[i, j]), (outcome_center + scaled_slope * float(centered[i, j])) * float(scales[0])]
                   for j in (low, high)]
            comparisons.append({"column": column, "label": name, "r": r, "r_squared": r * r, "slope": slope,
                                "weekly_values": values[i].tolist(),
                                "fit": fit if all(math.isfinite(y) for _, y in fit) else None})
    comparisons.sort(key=lambda item: (-abs(item["r"]), item["column"]))
    if not comparisons:
        return None
    top = abs(comparisons[0]["r"])
    leaders = [item["label"] for item in comparisons if math.isclose(abs(item["r"]), top, abs_tol=1e-12)] if top > 1e-12 else []
    return {"source": source, "weeks": weeks, "outcome_values": values[0].tolist(), "rows": comparisons, "leaders": leaders}


def aht_links(aggregates, period):
    """Pair AHT and its components over the same handled contacts in each complete week."""
    return _weekly_links(((day, count, totals) for day, _, _, count, totals in _aht_observations(aggregates)),
                         period, AHT_COMPONENTS, "D01")


def _aht_observations(aggregates):
    for row in aggregates:
        measures = row.get("measures", {})
        parts = [measures.get(column) for column in AHT_COMPONENTS]
        count = row["count"]
        if count:
            totals = ([row["total"], *(p["weighted_sum"] for p in parts)]
                      if all(p and p["weight"] == count for p in parts) else None)
            yield row["date"], row.get("agent_id"), row.get("line_of_business_id"), count, totals


def scoped_sample_rows(reader, upload, module, scope, zone):
    """Yield valid rows with their business date only when they are in scope."""
    date_field = match.FILES[module][1]
    valid = {entry["source_row"]: entry["record"] for entry in upload["records"] if entry["status"] == "valid"}
    in_scope = set(scope["lines_of_business"])
    types = scope.get("contact_types")
    types = None if types is None else set(types)
    fmt = dates.FORMAT_NAMES.get((upload.get("date_settings") or {}).get("date_format"), "mdy")
    zone = dates.zone_for(zone)
    for number, row in enumerate(reader, start=2):
        record = valid.get(number)
        if record is None:
            continue
        day = None
        if (record["account_id"] == scope["account"] and (row.get("line_of_business_id") or "").strip() in in_scope
                and (types is None or (row.get("contact_type") or "").strip() in types)):
            reading = dates.read(record[date_field], fmt, zone)
            if reading.ok and scope["start"] <= reading.business_date <= scope["end"]:
                day = reading.business_date
        yield row, record, day


def sample_shortfall(upload, kind, scope, zone):
    """Use the full valid file for reference values and count only in-scope rows."""
    module = {"qa": "D04", "csat": "D03"}[kind]
    reader = csv.DictReader(io.StringIO(upload["raw"].decode("utf-8-sig"), newline=""))
    columns = detect(reader.fieldnames or [], kind)
    rows = ((row, day is not None) for row, _, day in scoped_sample_rows(reader, upload, module, scope, zone))
    return _shortfall(columns, rows, kind)


def sample_links(upload, kind, scope, zone, percent=False):
    """Pair supplied survey/audit outcomes and components on the same eligible source rows."""
    columns, module, observations = _sample_observations(upload, kind, scope, zone, percent)
    if not columns:
        return None
    result = _weekly_links(((day, count, values) for day, _, _, count, values in observations),
                           (scope["start"], scope["end"]), columns, module)
    if result and percent:
        result["outcome"] = "pass_rate"
    return result


def _sample_observations(upload, kind, scope, zone, percent=False, *, include_driver=False):
    module, metric = {"qa": ("D04", "qa_score"), "csat": ("D03", "csat")}[kind]
    columns_for_metric = metrics.get(metric)["columns"]["contact"]
    score = columns_for_metric["pass_flag" if percent else "score"]
    reader = csv.DictReader(io.StringIO(upload["raw"].decode("utf-8-sig"), newline=""))
    columns = {column: label(column) for column in detect(reader.fieldnames or [], kind)}
    if not columns or "line_of_business_id" not in reader.fieldnames:
        return {}, module, ()
    if percent and score not in reader.fieldnames:
        return {}, module, ()

    def observations():
        for row, rec, day in scoped_sample_rows(reader, upload, module, scope, zone):
            if day is None or (not percent and score not in rec):
                continue
            try:
                outcome = float(row[score]) if percent else rec[score]
                if percent and outcome not in (0, 1):
                    continue
                values = [outcome * 100 if percent else outcome, *(float(row[column]) for column in columns)]
            except (ValueError, TypeError):
                continue
            if all(math.isfinite(value) for value in values):
                key = (day, rec.get("agent_id"), (row.get("line_of_business_id") or "").strip())
                if include_driver:
                    key += ((row.get("contact_type") or "").strip(),)
                yield *key, 1, values

    return columns, module, observations()


def sample_component_cells(upload, module, scope, zone):
    """Peer component scores with the contact driver needed for exact work-cell alignment."""
    kind = {"D03": "csat", "D04": "qa"}[module]
    columns, _, observations = _sample_observations(upload, kind, scope, zone, include_driver=True)
    return columns, observations


def component_population(metric, grain, aggregates, optionals, scope, zone):
    """Return component columns and eligible observed rows for the selected KPI."""
    if metric == "aht" and grain == "contact":
        return AHT_COMPONENTS, "D01", _aht_observations(aggregates)
    kind, source = {"csat": ("csat", "D03"), "qa_score": ("qa", "D04")}.get(metric, (None, None))
    if source in optionals:
        return _sample_observations(optionals[source], kind, scope, zone)
    return {}, None, ()


def component_movement(metric, grain, aggregates, optionals, scope, zone, roster, selection=None):
    """Pool component values on the same eligible population in two inclusive date ranges."""
    start, end = scope["start"], scope["end"]
    if start == end:
        return None
    if selection is None:
        first, last = date.fromisoformat(start), date.fromisoformat(end)
        after = first + timedelta(days=((last - first).days + 1) // 2)
        selection = {"before_start": start, "before_end": (after - timedelta(days=1)).isoformat(),
                     "after_start": after.isoformat(), "after_end": end, "group": ""}
    if not isinstance(selection, dict):
        raise ValueError("Choose valid Before and After dates.")
    keys = ("before_start", "before_end", "after_start", "after_end")
    days = [selection.get(key) for key in keys]
    try:
        if any(date.fromisoformat(day).isoformat() != day for day in days):
            raise ValueError
    except (TypeError, ValueError):
        raise ValueError("Complete both date ranges.") from None
    b0, b1, a0, a1 = days
    if not start <= b0 <= b1 < a0 <= a1 <= end:
        raise ValueError("Choose non-overlapping ranges within the report period, with Before first.")
    group = selection.get("group", "")
    if not isinstance(group, str):
        raise ValueError("Choose a team lead from this report.")

    columns, source, observations = component_population(metric, grain, aggregates, optionals, scope, zone)
    if not columns:
        return None

    groups = set()
    counts = [0, 0]
    totals = [[0.0] * len(columns), [0.0] * len(columns)]
    for day, agent, _, count, values in observations:
        if values is None or not all(math.isfinite(value) for value in values):
            continue
        lead = (roster or {}).get(agent, {}).get("team_lead")
        if lead:
            groups.add(lead)
        if group and lead != group:
            continue
        for side, (lo, hi) in enumerate(((b0, b1), (a0, a1))):
            if lo <= day <= hi:
                counts[side] += count
                totals[side] = [total + value for total, value in zip(totals[side], values[1:])]
    if group and group not in groups:
        raise ValueError("Choose a team lead from this report.")
    rows = []
    reason = None
    for i, name in enumerate(columns.values()):
        before, after = [side[i] / count if count else None for side, count in zip(totals, counts)]
        change = after - before if before is not None and after is not None else None
        if any(value is not None and not math.isfinite(value) for value in (before, after, change)):
            reason = "Component totals or changes exceed the supported numeric range. Choose a different scope."
            before = after = change = None
        rows.append({"label": name, "before": before, "after": after, "change": change})
    return {"source": source, "groups": sorted(groups), "selection": dict(zip(keys, days)) | {"group": group},
            "counts": counts, "rows": rows, "reason": reason}


def finding(comp, metric, label_text):
    """The component with the largest share of the shortfall, as a playbook finding."""
    if not comp:
        return None
    top = comp["rows"][0]
    return {"id": "component-%s" % top["column"], "pattern": "component_gap", "metric": metric, "direction": "higher_is_better", "support": "supported", "impact": None,
            "fields": {"component": top["label"].lower(), "share": "%d%%" % round(top["share"] * 100), "metric_label": label_text}, "component_data": True}
